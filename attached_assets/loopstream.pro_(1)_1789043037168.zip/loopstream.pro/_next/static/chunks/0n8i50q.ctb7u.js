(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 154505, 157788, 476959, 766820, 463011, 265091, 22660, 279444, 569577, 130162, 83411, 864440, 965566, 19928, 260830, 846791, 287022, 921012, 763074, 133887, 570596, 794581, 260900, 414229, 779294, 960855, 756512, 997307, 368e3, 962118, 560140, 496173, 325791, 486427, 885983, 732525, 706840, 587576, 386579, 617218, 793787, 544947, 181261, 399951, 895051, 100706, 924463, 130789, 984049, 767926, 27677, 177777, 135636, 153689, 944966, t => {
    "use strict";
    let e, i = ["transformPerspective", "x", "y", "z", "translateX", "translateY", "translateZ", "scale", "scaleX", "scaleY", "rotate", "rotateX", "rotateY", "rotateZ", "skew", "skewX", "skewY"],
        s = new Set([...i, "pathRotation"]);
    t.s(["transformPropOrder", 0, i, "transformProps", 0, s], 157788);
    let n = (t, e, i) => i > e ? e : i < t ? t : i;
    t.s(["clamp", 0, n], 476959);
    let r = {
            test: t => "number" == typeof t,
            parse: parseFloat,
            transform: t => t
        },
        o = { ...r,
            transform: t => n(0, 1, t)
        },
        a = { ...r,
            default: 1
        },
        l = t => Math.round(1e5 * t) / 1e5,
        h = /-?(?:\d+(?:\.\d+)?|\.\d+)/gu,
        u = /^(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))$/iu,
        c = (t, e) => i => !!("string" == typeof i && u.test(i) && i.startsWith(t) || e && null != i && Object.prototype.hasOwnProperty.call(i, e)),
        d = (t, e, i) => s => {
            if ("string" != typeof s) return s;
            let [n, r, o, a] = s.match(h);
            return {
                [t]: parseFloat(n),
                [e]: parseFloat(r),
                [i]: parseFloat(o),
                alpha: void 0 !== a ? parseFloat(a) : 1
            }
        },
        m = { ...r,
            transform: t => Math.round(n(0, 255, t))
        },
        p = {
            test: c("rgb", "red"),
            parse: d("red", "green", "blue"),
            transform: ({
                red: t,
                green: e,
                blue: i,
                alpha: s = 1
            }) => "rgba(" + m.transform(t) + ", " + m.transform(e) + ", " + m.transform(i) + ", " + l(o.transform(s)) + ")"
        };
    t.s(["rgba", 0, p], 766820);
    let f = {
        test: c("#"),
        parse: function(t) {
            let e = "",
                i = "",
                s = "",
                n = "";
            return t.length > 5 ? (e = t.substring(1, 3), i = t.substring(3, 5), s = t.substring(5, 7), n = t.substring(7, 9)) : (e = t.substring(1, 2), i = t.substring(2, 3), s = t.substring(3, 4), n = t.substring(4, 5), e += e, i += i, s += s, n += n), {
                red: parseInt(e, 16),
                green: parseInt(i, 16),
                blue: parseInt(s, 16),
                alpha: n ? parseInt(n, 16) / 255 : 1
            }
        },
        transform: p.transform
    };
    t.s(["hex", 0, f], 463011);
    let g = t => ({
            test: e => "string" == typeof e && e.endsWith(t) && 1 === e.split(" ").length,
            parse: parseFloat,
            transform: e => `${e}${t}`
        }),
        v = g("deg"),
        y = g("%"),
        x = g("px"),
        T = g("vh"),
        w = g("vw"),
        b = { ...y,
            parse: t => y.parse(t) / 100,
            transform: t => y.transform(100 * t)
        };
    t.s(["degrees", 0, v, "percent", 0, y, "progressPercentage", 0, b, "px", 0, x, "vh", 0, T, "vw", 0, w], 265091);
    let S = {
        test: c("hsl", "hue"),
        parse: d("hue", "saturation", "lightness"),
        transform: ({
            hue: t,
            saturation: e,
            lightness: i,
            alpha: s = 1
        }) => "hsla(" + Math.round(t) + ", " + y.transform(l(e)) + ", " + y.transform(l(i)) + ", " + l(o.transform(s)) + ")"
    };
    t.s(["hsla", 0, S], 22660);
    let P = {
        test: t => p.test(t) || f.test(t) || S.test(t),
        parse: t => p.test(t) ? p.parse(t) : S.test(t) ? S.parse(t) : f.parse(t),
        transform: t => "string" == typeof t ? t : t.hasOwnProperty("red") ? p.transform(t) : S.transform(t),
        getAnimatableNone: t => {
            let e = P.parse(t);
            return e.alpha = 0, P.transform(e)
        }
    };
    t.s(["color", 0, P], 279444);
    let M = /(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))/giu,
        A = "number",
        V = "color",
        E = /var\s*\(\s*--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)|#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\)|-?(?:\d+(?:\.\d+)?|\.\d+)/giu;

    function C(t) {
        let e = t.toString(),
            i = [],
            s = {
                color: [],
                number: [],
                var: []
            },
            n = [],
            r = 0,
            o = e.replace(E, t => (P.test(t) ? (s.color.push(r), n.push(V), i.push(P.parse(t))) : t.startsWith("var(") ? (s.var.push(r), n.push("var"), i.push(t)) : (s.number.push(r), n.push(A), i.push(parseFloat(t))), ++r, "${}")).split("${}");
        return {
            values: i,
            split: o,
            indexes: s,
            types: n
        }
    }

    function D({
        split: t,
        types: e
    }) {
        let i = t.length;
        return s => {
            let n = "";
            for (let r = 0; r < i; r++)
                if (n += t[r], void 0 !== s[r]) {
                    let t = e[r];
                    t === A ? n += l(s[r]) : t === V ? n += P.transform(s[r]) : n += s[r]
                }
            return n
        }
    }
    let k = {
        test: function(t) {
            return isNaN(t) && "string" == typeof t && (t.match(h) ? .length || 0) + (t.match(M) ? .length || 0) > 0
        },
        parse: function(t) {
            return C(t).values
        },
        createTransformer: function(t) {
            return D(C(t))
        },
        getAnimatableNone: function(t) {
            let e = C(t);
            return D(e)(e.values.map((t, i) => ((t, e) => "number" == typeof t ? e ? .trim().endsWith("/") ? t : 0 : "number" == typeof t ? 0 : P.test(t) ? P.getAnimatableNone(t) : t)(t, e.split[i])))
        }
    };
    t.s(["analyseComplexValue", 0, C, "complex", 0, k], 569577);
    let R = new Set(["brightness", "contrast", "saturate", "opacity"]);

    function L(t) {
        let [e, i] = t.slice(0, -1).split("(");
        if ("drop-shadow" === e) return t;
        let [s] = i.match(h) || [];
        if (!s) return t;
        let n = i.replace(s, ""),
            r = +!!R.has(e);
        return s !== i && (r *= 100), e + "(" + r + n + ")"
    }
    let B = /\b([a-z-]*)\(.*?\)/gu,
        F = { ...k,
            getAnimatableNone: t => {
                let e = t.match(B);
                return e ? e.map(L).join(" ") : t
            }
        },
        j = { ...k,
            getAnimatableNone: t => {
                let e = k.parse(t);
                return k.createTransformer(t)(e.map(t => "number" == typeof t ? 0 : "object" == typeof t ? { ...t,
                    alpha: 1
                } : t))
            }
        },
        I = { ...r,
            transform: Math.round
        },
        O = {
            borderWidth: x,
            borderTopWidth: x,
            borderRightWidth: x,
            borderBottomWidth: x,
            borderLeftWidth: x,
            borderRadius: x,
            borderTopLeftRadius: x,
            borderTopRightRadius: x,
            borderBottomRightRadius: x,
            borderBottomLeftRadius: x,
            width: x,
            maxWidth: x,
            height: x,
            maxHeight: x,
            top: x,
            right: x,
            bottom: x,
            left: x,
            inset: x,
            insetBlock: x,
            insetBlockStart: x,
            insetBlockEnd: x,
            insetInline: x,
            insetInlineStart: x,
            insetInlineEnd: x,
            padding: x,
            paddingTop: x,
            paddingRight: x,
            paddingBottom: x,
            paddingLeft: x,
            paddingBlock: x,
            paddingBlockStart: x,
            paddingBlockEnd: x,
            paddingInline: x,
            paddingInlineStart: x,
            paddingInlineEnd: x,
            margin: x,
            marginTop: x,
            marginRight: x,
            marginBottom: x,
            marginLeft: x,
            marginBlock: x,
            marginBlockStart: x,
            marginBlockEnd: x,
            marginInline: x,
            marginInlineStart: x,
            marginInlineEnd: x,
            fontSize: x,
            backgroundPositionX: x,
            backgroundPositionY: x,
            rotate: v,
            pathRotation: v,
            rotateX: v,
            rotateY: v,
            rotateZ: v,
            scale: a,
            scaleX: a,
            scaleY: a,
            scaleZ: a,
            skew: v,
            skewX: v,
            skewY: v,
            distance: x,
            translateX: x,
            translateY: x,
            translateZ: x,
            x: x,
            y: x,
            z: x,
            perspective: x,
            transformPerspective: x,
            opacity: o,
            originX: b,
            originY: b,
            originZ: x,
            zIndex: I,
            fillOpacity: o,
            strokeOpacity: o,
            numOctaves: I
        },
        N = { ...O,
            color: P,
            backgroundColor: P,
            outlineColor: P,
            fill: P,
            stroke: P,
            borderColor: P,
            borderTopColor: P,
            borderRightColor: P,
            borderBottomColor: P,
            borderLeftColor: P,
            filter: F,
            WebkitFilter: F,
            mask: j,
            WebkitMask: j
        },
        U = t => N[t],
        W = () => ({
            translate: 0,
            scale: 1,
            origin: 0,
            originPoint: 0
        }),
        $ = () => ({
            min: 0,
            max: 0
        }),
        G = () => ({
            x: $(),
            y: $()
        });
    t.s(["createBox", 0, G, "createDelta", 0, () => ({
        x: W(),
        y: W()
    })], 130162);
    let z = t => !!(t && t.getVelocity);
    t.s(["isMotionValue", 0, z], 83411);
    let H = new Set(["width", "height", "top", "left", "right", "bottom", ...i]);
    t.s(["positionalKeys", 0, H], 864440);
    let K = t => e => e.test(t),
        Y = [r, x, y, v, w, T, {
            test: t => "auto" === t,
            parse: t => t
        }],
        X = t => Y.find(K(t));
    var q = t.i(247167);
    let _ = () => {};
    q.default, t.s(["invariant", 0, _, "warning", 0, () => {}], 965566);
    let Z = t => e => "string" == typeof e && e.startsWith(t),
        J = Z("--"),
        Q = Z("var(--"),
        tt = t => !!Q(t) && te.test(t.split("/*")[0].trim()),
        te = /var\(--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)$/iu;

    function ti(t) {
        return "string" == typeof t && t.split("/*")[0].includes("var(--")
    }
    t.s(["containsCSSVariable", 0, ti, "isCSSVariableName", 0, J, "isCSSVariableToken", 0, tt], 19928);
    let ts = /^var\(--(?:([\w-]+)|([\w-]+), ?([a-zA-Z\d ()%#.,-]+))\)/u,
        tn = t => 180 * t / Math.PI,
        tr = t => ta(tn(Math.atan2(t[1], t[0]))),
        to = {
            x: 4,
            y: 5,
            translateX: 4,
            translateY: 5,
            scaleX: 0,
            scaleY: 3,
            scale: t => (Math.abs(t[0]) + Math.abs(t[3])) / 2,
            rotate: tr,
            rotateZ: tr,
            skewX: t => tn(Math.atan(t[1])),
            skewY: t => tn(Math.atan(t[2])),
            skew: t => (Math.abs(t[1]) + Math.abs(t[2])) / 2
        },
        ta = t => ((t %= 360) < 0 && (t += 360), t),
        tl = t => Math.sqrt(t[0] * t[0] + t[1] * t[1]),
        th = t => Math.sqrt(t[4] * t[4] + t[5] * t[5]),
        tu = {
            x: 12,
            y: 13,
            z: 14,
            translateX: 12,
            translateY: 13,
            translateZ: 14,
            scaleX: tl,
            scaleY: th,
            scale: t => (tl(t) + th(t)) / 2,
            rotateX: t => ta(tn(Math.atan2(t[6], t[5]))),
            rotateY: t => ta(tn(Math.atan2(-t[2], t[0]))),
            rotateZ: tr,
            rotate: tr,
            skewX: t => tn(Math.atan(t[4])),
            skewY: t => tn(Math.atan(t[1])),
            skew: t => (Math.abs(t[1]) + Math.abs(t[4])) / 2
        };

    function tc(t) {
        return +!!t.includes("scale")
    }

    function td(t, e) {
        let i, s;
        if (!t || "none" === t) return tc(e);
        let n = t.match(/^matrix3d\(([-\d.e\s,]+)\)$/u);
        if (n) i = tu, s = n;
        else {
            let e = t.match(/^matrix\(([-\d.e\s,]+)\)$/u);
            i = to, s = e
        }
        if (!s) return tc(e);
        let r = i[e],
            o = s[1].split(",").map(tm);
        return "function" == typeof r ? r(o) : o[r]
    }

    function tm(t) {
        return parseFloat(t.trim())
    }
    let tp = t => t === r || t === x,
        tf = new Set(["x", "y", "z"]),
        tg = i.filter(t => !tf.has(t)),
        tv = {
            width: ({
                x: t
            }, {
                paddingLeft: e = "0",
                paddingRight: i = "0",
                boxSizing: s
            }) => {
                let n = t.max - t.min;
                return "border-box" === s ? n : n - parseFloat(e) - parseFloat(i)
            },
            height: ({
                y: t
            }, {
                paddingTop: e = "0",
                paddingBottom: i = "0",
                boxSizing: s
            }) => {
                let n = t.max - t.min;
                return "border-box" === s ? n : n - parseFloat(e) - parseFloat(i)
            },
            top: (t, {
                top: e
            }) => parseFloat(e),
            left: (t, {
                left: e
            }) => parseFloat(e),
            bottom: ({
                y: t
            }, {
                top: e
            }) => parseFloat(e) + (t.max - t.min),
            right: ({
                x: t
            }, {
                left: e
            }) => parseFloat(e) + (t.max - t.min),
            x: (t, {
                transform: e
            }) => td(e, "x"),
            y: (t, {
                transform: e
            }) => td(e, "y")
        };
    tv.translateX = tv.x, tv.translateY = tv.y;
    let ty = t => t;
    t.s(["noop", 0, ty], 260830);
    let tx = {};
    t.s(["MotionGlobalConfig", 0, tx], 846791);
    let tT = ["setup", "read", "resolveKeyframes", "preUpdate", "update", "preRender", "render", "postRender"];

    function tw(t, e) {
        let i = !1,
            s = !0,
            n = {
                delta: 0,
                timestamp: 0,
                isProcessing: !1
            },
            r = () => i = !0,
            o = tT.reduce((t, e) => (t[e] = function(t) {
                let e = new Set,
                    i = new Set,
                    s = !1,
                    n = !1,
                    r = new WeakSet,
                    o = {
                        delta: 0,
                        timestamp: 0,
                        isProcessing: !1
                    };

                function a(e) {
                    r.has(e) && (l.schedule(e), t()), e(o)
                }
                let l = {
                    schedule: (t, n = !1, o = !1) => {
                        let a = o && s ? e : i;
                        return n && r.add(t), a.add(t), t
                    },
                    cancel: t => {
                        i.delete(t), r.delete(t)
                    },
                    process: t => {
                        if (o = t, s) {
                            n = !0;
                            return
                        }
                        s = !0;
                        let r = e;
                        e = i, i = r, e.forEach(a), e.clear(), s = !1, n && (n = !1, l.process(t))
                    }
                };
                return l
            }(r), t), {}),
            {
                setup: a,
                read: l,
                resolveKeyframes: h,
                preUpdate: u,
                update: c,
                preRender: d,
                render: m,
                postRender: p
            } = o,
            f = () => {
                let r = tx.useManualTiming,
                    o = r ? n.timestamp : performance.now();
                i = !1, r || (n.delta = s ? 1e3 / 60 : Math.max(Math.min(o - n.timestamp, 40), 1)), n.timestamp = o, n.isProcessing = !0, a.process(n), l.process(n), h.process(n), u.process(n), c.process(n), d.process(n), m.process(n), p.process(n), n.isProcessing = !1, i && e && (s = !1, t(f))
            };
        return {
            schedule: tT.reduce((e, r) => {
                let a = o[r];
                return e[r] = (e, r = !1, o = !1) => (!i && (i = !0, s = !0, n.isProcessing || t(f)), a.schedule(e, r, o)), e
            }, {}),
            cancel: t => {
                for (let e = 0; e < tT.length; e++) o[tT[e]].cancel(t)
            },
            state: n,
            steps: o
        }
    }
    let {
        schedule: tb,
        cancel: tS,
        state: tP,
        steps: tM
    } = tw("u" > typeof requestAnimationFrame ? requestAnimationFrame : ty, !0);
    t.s(["cancelFrame", 0, tS, "frame", 0, tb, "frameData", 0, tP, "frameSteps", 0, tM], 287022);
    let tA = new Set,
        tV = !1,
        tE = !1,
        tC = !1;

    function tD() {
        if (tE) {
            let t = Array.from(tA).filter(t => t.needsMeasurement),
                e = new Set(t.map(t => t.element)),
                i = new Map;
            e.forEach(t => {
                let e, s = (e = [], tg.forEach(i => {
                    let s = t.getValue(i);
                    void 0 !== s && (e.push([i, s.get()]), s.set(+!!i.startsWith("scale")))
                }), e);
                s.length && (i.set(t, s), t.render())
            }), t.forEach(t => t.measureInitialState()), e.forEach(t => {
                t.render();
                let e = i.get(t);
                e && e.forEach(([e, i]) => {
                    t.getValue(e) ? .set(i)
                })
            }), t.forEach(t => t.measureEndState()), t.forEach(t => {
                void 0 !== t.suspendedScrollY && window.scrollTo(0, t.suspendedScrollY)
            })
        }
        tE = !1, tV = !1, tA.forEach(t => t.complete(tC)), tA.clear()
    }

    function tk() {
        tA.forEach(t => {
            t.readKeyframes(), t.needsMeasurement && (tE = !0)
        })
    }
    class tR {
        constructor(t, e, i, s, n, r = !1) {
            this.state = "pending", this.isAsync = !1, this.needsMeasurement = !1, this.unresolvedKeyframes = [...t], this.onComplete = e, this.name = i, this.motionValue = s, this.element = n, this.isAsync = r
        }
        scheduleResolve() {
            this.state = "scheduled", this.isAsync ? (tA.add(this), tV || (tV = !0, tb.read(tk), tb.resolveKeyframes(tD))) : (this.readKeyframes(), this.complete())
        }
        readKeyframes() {
            let {
                unresolvedKeyframes: t,
                name: e,
                element: i,
                motionValue: s
            } = this;
            if (null === t[0]) {
                let n = s ? .get(),
                    r = t[t.length - 1];
                if (void 0 !== n) t[0] = n;
                else if (i && e) {
                    let s = i.readValue(e, r);
                    null != s && (t[0] = s)
                }
                void 0 === t[0] && (t[0] = r), s && void 0 === n && s.set(t[0])
            }
            for (let e = 1; e < t.length; e++) t[e] ? ? (t[e] = t[e - 1])
        }
        setFinalKeyframe() {}
        measureInitialState() {}
        renderEndStyles() {}
        measureEndState() {}
        complete(t = !1) {
            this.state = "complete", this.onComplete(this.unresolvedKeyframes, this.finalKeyframe, t), tA.delete(this)
        }
        cancel() {
            "scheduled" === this.state && (tA.delete(this), this.state = "pending")
        }
        resume() {
            "pending" === this.state && this.scheduleResolve()
        }
    }
    t.s(["KeyframeResolver", 0, tR, "flushKeyframeResolvers", 0, function() {
        tC = !0, tk(), tD(), tC = !1
    }], 921012);
    let tL = new Set([F, j]);

    function tB(t, e) {
        let i = U(t);
        return tL.has(i) || (i = k), i.getAnimatableNone ? i.getAnimatableNone(e) : void 0
    }
    let tF = new Set(["auto", "none", "0"]);
    class tj extends tR {
        constructor(t, e, i, s, n) {
            super(t, e, i, s, n, !0)
        }
        readKeyframes() {
            let {
                unresolvedKeyframes: t,
                element: e,
                name: i
            } = this;
            if (!e || !e.current) return;
            super.readKeyframes();
            for (let i = 0; i < t.length; i++) {
                let s = t[i];
                if ("string" == typeof s && tt(s = s.trim())) {
                    let n = function t(e, i, s = 1) {
                        _(s <= 4, `Max CSS variable fallback depth detected in property "${e}". This may indicate a circular fallback dependency.`, "max-css-var-depth");
                        let [n, r] = function(t) {
                            let e = ts.exec(t);
                            if (!e) return [, ];
                            let [, i, s, n] = e;
                            return [`--${i??s}`, n]
                        }(e);
                        if (!n) return;
                        let o = window.getComputedStyle(i).getPropertyValue(n);
                        if (o) {
                            let t = o.trim();
                            return /^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(t) ? parseFloat(t) : t
                        }
                        return tt(r) ? t(r, i, s + 1) : r
                    }(s, e.current);
                    void 0 !== n && (t[i] = n), i === t.length - 1 && (this.finalKeyframe = s)
                }
            }
            if (this.resolveNoneKeyframes(), !H.has(i) || 2 !== t.length) return;
            let [s, n] = t, r = X(s), o = X(n);
            if (ti(s) !== ti(n) && tv[i]) {
                this.needsMeasurement = !0;
                return
            }
            if (r !== o)
                if (tp(r) && tp(o))
                    for (let e = 0; e < t.length; e++) {
                        let i = t[e];
                        "string" == typeof i && (t[e] = parseFloat(i))
                    } else tv[i] && (this.needsMeasurement = !0)
        }
        resolveNoneKeyframes() {
            let {
                unresolvedKeyframes: t,
                name: e
            } = this, i = [];
            for (let e = 0; e < t.length; e++)(null === t[e] || function(t) {
                if ("number" == typeof t) return 0 === t;
                if (null === t) return !0;
                return "none" === t || "0" === t || /^0[^.\s]+$/u.test(t)
            }(t[e])) && i.push(e);
            i.length && function(t, e, i) {
                let s, n = 0;
                for (; n < t.length && !s;) {
                    let e = t[n];
                    "string" == typeof e && !tF.has(e) && C(e).values.length && (s = t[n]), n++
                }
                if (s && i)
                    for (let n of e) t[n] = tB(i, s)
            }(t, i, e)
        }
        measureInitialState() {
            let {
                element: t,
                unresolvedKeyframes: e,
                name: i
            } = this;
            if (!t || !t.current) return;
            "height" === i && (this.suspendedScrollY = window.pageYOffset), this.measuredOrigin = tv[i](t.measureViewportBox(), window.getComputedStyle(t.current)), e[0] = this.measuredOrigin;
            let s = e[e.length - 1];
            void 0 !== s && t.getValue(i, s).jump(s, !1)
        }
        measureEndState() {
            let {
                element: t,
                name: e,
                unresolvedKeyframes: i
            } = this;
            if (!t || !t.current) return;
            let s = t.getValue(e);
            s && s.jump(this.measuredOrigin, !1);
            let n = i.length - 1,
                r = i[n];
            i[n] = tv[e](t.measureViewportBox(), window.getComputedStyle(t.current)), null !== r && void 0 === this.finalKeyframe && (this.finalKeyframe = r), this.removedTransforms ? .length && this.removedTransforms.forEach(([e, i]) => {
                t.getValue(e).set(i)
            }), this.resolveNoneKeyframes()
        }
    }
    let tI = t => 1e3 * t,
        tO = t => t / 1e3;

    function tN(t, e) {
        -1 === t.indexOf(e) && t.push(e)
    }

    function tU(t, e) {
        let i = t.indexOf(e);
        i > -1 && t.splice(i, 1)
    }
    t.s(["millisecondsToSeconds", 0, tO, "secondsToMilliseconds", 0, tI], 763074), t.s(["addUniqueItem", 0, tN, "removeItem", 0, tU], 133887);
    class tW {
        constructor() {
            this.subscriptions = []
        }
        add(t) {
            return tN(this.subscriptions, t), () => tU(this.subscriptions, t)
        }
        notify(t, e, i) {
            let s = this.subscriptions.length;
            if (s)
                if (1 === s) this.subscriptions[0](t, e, i);
                else
                    for (let n = 0; n < s; n++) {
                        let s = this.subscriptions[n];
                        s && s(t, e, i)
                    }
        }
        getSize() {
            return this.subscriptions.length
        }
        clear() {
            this.subscriptions.length = 0
        }
    }

    function t$(t, e, i) {
        e.startsWith("--") ? t.style.setProperty(e, i) : t.style[e] = i
    }

    function tG(t) {
        let e;
        return () => (void 0 === e && (e = t()), e)
    }
    t.s(["SubscriptionManager", 0, tW], 570596), t.s(["setStyle", 0, t$], 794581), t.s(["memo", 0, tG], 260900);
    let tz = {};

    function tH(t, e) {
        let i = tG(t);
        return () => tz[e] ? ? i()
    }
    let tK = tH(() => void 0 !== window.ScrollTimeline, "scrollTimeline"),
        tY = t => null !== t;

    function tX(t, {
        repeat: e,
        repeatType: i = "loop"
    }, s, n = 1) {
        let r = t.filter(tY),
            o = n < 0 || e && "loop" !== i && e % 2 == 1 ? 0 : r.length - 1;
        return o && void 0 !== s ? s : r[o]
    }
    t.s(["getFinalKeyframe", 0, tX], 414229);
    class tq {
        constructor() {
            this.updateFinished()
        }
        get finished() {
            return this._finished
        }
        updateFinished() {
            this._finished = new Promise(t => {
                this.resolve = t
            })
        }
        notifyFinished() {
            this.resolve()
        }
        then(t, e) {
            return this.finished.then(t, e)
        }
    }
    t.s(["WithPromise", 0, tq], 779294);
    let t_ = t => Array.isArray(t) && "number" == typeof t[0];
    t.s(["isBezierDefinition", 0, t_], 960855);
    let tZ = tH(() => {
            try {
                document.createElement("div").animate({
                    opacity: 0
                }, {
                    easing: "linear(0, 1)"
                })
            } catch (t) {
                return !1
            }
            return !0
        }, "linearEasing"),
        tJ = (t, e, i = 10) => {
            let s = "",
                n = Math.max(Math.round(e / i), 2);
            for (let e = 0; e < n; e++) s += Math.round(1e4 * t(e / (n - 1))) / 1e4 + ", ";
            return `linear(${s.substring(0,s.length-2)})`
        };
    t.s(["generateLinearEasing", 0, tJ], 756512);
    let tQ = ([t, e, i, s]) => `cubic-bezier(${t}, ${e}, ${i}, ${s})`,
        t0 = {
            linear: "linear",
            ease: "ease",
            easeIn: "ease-in",
            easeOut: "ease-out",
            easeInOut: "ease-in-out",
            circIn: tQ([0, .65, .55, 1]),
            circOut: tQ([.55, 0, 1, .45]),
            backIn: tQ([.31, .01, .66, -.59]),
            backOut: tQ([.33, 1.53, .69, .99])
        };

    function t1(t) {
        return "function" == typeof t && "applyToOptions" in t
    }
    t.s(["isGenerator", 0, t1], 997307);
    class t5 extends tq {
        constructor(t) {
            if (super(), this.finishedTime = null, this.isStopped = !1, this.manualStartTime = null, !t) return;
            const {
                element: e,
                name: i,
                keyframes: s,
                pseudoElement: n,
                allowFlatten: r = !1,
                finalKeyframe: o,
                onComplete: a
            } = t;
            this.isPseudoElement = !!n, this.allowFlatten = r, this.options = t, _("string" != typeof t.type, 'Mini animate() doesn\'t support "type" as a string.', "mini-spring");
            const l = function({
                type: t,
                ...e
            }) {
                return t1(t) && tZ() ? t.applyToOptions(e) : (e.duration ? ? (e.duration = 300), e.ease ? ? (e.ease = "easeOut"), e)
            }(t);
            this.animation = function(t, e, i, {
                delay: s = 0,
                duration: n = 300,
                repeat: r = 0,
                repeatType: o = "loop",
                ease: a = "easeOut",
                times: l
            } = {}, h) {
                let u = {
                    [e]: i
                };
                l && (u.offset = l);
                let c = function t(e, i) {
                    if (e) return "function" == typeof e ? tZ() ? tJ(e, i) : "ease-out" : t_(e) ? tQ(e) : Array.isArray(e) ? e.map(e => t(e, i) || t0.easeOut) : t0[e]
                }(a, n);
                Array.isArray(c) && (u.easing = c);
                let d = {
                    delay: s,
                    duration: n,
                    easing: Array.isArray(c) ? "linear" : c,
                    fill: "both",
                    iterations: r + 1,
                    direction: "reverse" === o ? "alternate" : "normal"
                };
                return h && (d.pseudoElement = h), t.animate(u, d)
            }(e, i, s, l, n), !1 === l.autoplay && this.animation.pause(), this.animation.onfinish = () => {
                if (this.finishedTime = this.time, !n) {
                    let t = tX(s, this.options, o, this.speed);
                    this.updateMotionValue && this.updateMotionValue(t), t$(e, i, t), this.animation.cancel()
                }
                a ? .(), this.notifyFinished()
            }
        }
        play() {
            this.isStopped || (this.manualStartTime = null, this.animation.play(), "finished" === this.state && this.updateFinished())
        }
        pause() {
            this.animation.pause()
        }
        complete() {
            this.animation.finish ? .()
        }
        cancel() {
            try {
                this.animation.cancel()
            } catch (t) {}
        }
        stop() {
            if (this.isStopped) return;
            this.isStopped = !0;
            let {
                state: t
            } = this;
            "idle" !== t && "finished" !== t && (this.updateMotionValue ? this.updateMotionValue() : this.commitStyles(), this.isPseudoElement || this.cancel())
        }
        commitStyles() {
            let t = this.options ? .element;
            !this.isPseudoElement && t ? .isConnected && this.animation.commitStyles ? .()
        }
        get duration() {
            return tO(Number(this.animation.effect ? .getComputedTiming ? .().duration || 0))
        }
        get iterationDuration() {
            let {
                delay: t = 0
            } = this.options || {};
            return this.duration + tO(t)
        }
        get time() {
            return tO(Number(this.animation.currentTime) || 0)
        }
        set time(t) {
            let e = null !== this.finishedTime;
            this.manualStartTime = null, this.finishedTime = null, this.animation.currentTime = tI(t), e && this.animation.pause()
        }
        get speed() {
            return this.animation.playbackRate
        }
        set speed(t) {
            t < 0 && (this.finishedTime = null), this.animation.playbackRate = t
        }
        get state() {
            return null !== this.finishedTime ? "finished" : this.animation.playState
        }
        get startTime() {
            return this.manualStartTime ? ? Number(this.animation.startTime)
        }
        set startTime(t) {
            this.manualStartTime = this.animation.startTime = t
        }
        attachTimeline({
            timeline: t,
            rangeStart: e,
            rangeEnd: i,
            observe: s
        }) {
            return (this.allowFlatten && this.animation.effect ? .updateTiming({
                easing: "linear"
            }), this.animation.onfinish = null, t && tK()) ? (this.animation.timeline = t, e && (this.animation.rangeStart = e), i && (this.animation.rangeEnd = i), ty) : s(this)
        }
    }
    t.s(["NativeAnimation", 0, t5], 368e3);
    let t7 = new Set(["opacity", "clipPath", "filter", "transform"]);
    t.s(["acceleratedValues", 0, t7], 962118);
    let {
        schedule: t6
    } = tw(queueMicrotask, !1);

    function t2() {
        e = void 0
    }
    t.s(["microtask", 0, t6], 560140);
    let t9 = {
        now: () => (void 0 === e && t9.set(tP.isProcessing || tx.useManualTiming ? tP.timestamp : performance.now()), e),
        set: t => {
            e = t, queueMicrotask(t2)
        }
    };
    t.s(["time", 0, t9], 496173);
    let t3 = (t, e) => e ? 1e3 / e * t : 0;
    t.s(["velocityPerSecond", 0, t3], 325791);
    let t8 = {
        current: void 0
    };
    class t4 {
        constructor(t, e = {}) {
            this.canTrackVelocity = null, this.events = {}, this.updateAndNotify = t => {
                let e = t9.now();
                if (this.updatedAt !== e && this.setPrevFrameValue(), this.prev = this.current, this.setCurrent(t), this.current !== this.prev && (this.events.change ? .notify(this.current), this.dependents))
                    for (let t of this.dependents) t.dirty()
            }, this.hasAnimated = !1, this.setCurrent(t), this.owner = e.owner
        }
        setCurrent(t) {
            this.current = t, this.updatedAt = t9.now(), null === this.canTrackVelocity && void 0 !== t && (this.canTrackVelocity = !isNaN(parseFloat(this.current)))
        }
        setPrevFrameValue(t = this.current) {
            this.prevFrameValue = t, this.prevUpdatedAt = this.updatedAt
        }
        onChange(t) {
            return this.on("change", t)
        }
        on(t, e) {
            this.events[t] || (this.events[t] = new tW);
            let i = this.events[t].add(e);
            return "change" === t ? () => {
                i(), tb.read(() => {
                    this.events.change.getSize() || this.stop()
                })
            } : i
        }
        clearListeners() {
            for (let t in this.events) this.events[t].clear()
        }
        attach(t, e) {
            this.passiveEffect = t, this.stopPassiveEffect = e
        }
        set(t) {
            this.passiveEffect ? this.passiveEffect(t, this.updateAndNotify) : this.updateAndNotify(t)
        }
        setWithVelocity(t, e, i) {
            this.set(e), this.prev = void 0, this.prevFrameValue = t, this.prevUpdatedAt = this.updatedAt - i
        }
        jump(t, e = !0) {
            this.updateAndNotify(t), this.prev = t, this.prevUpdatedAt = this.prevFrameValue = void 0, e && this.stop(), this.stopPassiveEffect && this.stopPassiveEffect()
        }
        dirty() {
            this.events.change ? .notify(this.current)
        }
        addDependent(t) {
            this.dependents || (this.dependents = new Set), this.dependents.add(t)
        }
        removeDependent(t) {
            this.dependents && this.dependents.delete(t)
        }
        get() {
            return t8.current && t8.current.push(this), this.current
        }
        getPrevious() {
            return this.prev
        }
        getVelocity() {
            let t = t9.now();
            if (!this.canTrackVelocity || void 0 === this.prevFrameValue || t - this.updatedAt > 30) return 0;
            let e = Math.min(this.updatedAt - this.prevUpdatedAt, 30);
            return t3(parseFloat(this.current) - parseFloat(this.prevFrameValue), e)
        }
        start(t) {
            return this.stop(), new Promise(e => {
                this.hasAnimated = !0, this.animation = t(e), this.events.animationStart && this.events.animationStart.notify()
            }).then(() => {
                this.events.animationComplete && this.events.animationComplete.notify(), this.clearAnimation()
            })
        }
        stop() {
            this.animation && (this.animation.stop(), this.events.animationCancel && this.events.animationCancel.notify()), this.clearAnimation()
        }
        isAnimating() {
            return !!this.animation
        }
        clearAnimation() {
            delete this.animation
        }
        destroy() {
            this.dependents ? .clear(), this.events.destroy ? .notify(), this.clearListeners(), this.stop(), this.stopPassiveEffect && this.stopPassiveEffect()
        }
    }

    function et(t, e) {
        return new t4(t, e)
    }
    t.s(["collectMotionValues", 0, t8, "motionValue", 0, et], 486427);
    let ee = [...Y, P, k],
        ei = new WeakMap;

    function es(t) {
        return null !== t && "object" == typeof t && "function" == typeof t.start
    }

    function en(t) {
        return "string" == typeof t || Array.isArray(t)
    }
    t.s(["isAnimationControls", 0, es], 885983), t.s(["isVariantLabel", 0, en], 732525);
    let er = ["animate", "whileInView", "whileFocus", "whileHover", "whileTap", "whileDrag", "exit"],
        eo = ["initial", ...er];

    function ea(t) {
        return es(t.animate) || eo.some(e => en(t[e]))
    }

    function el(t) {
        return !!(ea(t) || t.variants)
    }
    t.s(["variantPriorityOrder", 0, er, "variantProps", 0, eo], 706840), t.s(["isControllingVariants", 0, ea, "isVariantNode", 0, el], 587576);
    let eh = {
            current: null
        },
        eu = {
            current: !1
        },
        ec = "u" > typeof window;

    function ed(t) {
        let e = [{}, {}];
        return t ? .values.forEach((t, i) => {
            e[0][i] = t.get(), e[1][i] = t.getVelocity()
        }), e
    }

    function em(t, e, i, s) {
        if ("function" == typeof e) {
            let [n, r] = ed(s);
            e = e(void 0 !== i ? i : t.custom, n, r)
        }
        if ("string" == typeof e && (e = t.variants && t.variants[e]), "function" == typeof e) {
            let [n, r] = ed(s);
            e = e(void 0 !== i ? i : t.custom, n, r)
        }
        return e
    }
    t.s(["resolveVariantFromProps", 0, em], 386579);
    let ep = ["AnimationStart", "AnimationComplete", "Update", "BeforeLayoutMeasure", "LayoutMeasure", "LayoutAnimationStart", "LayoutAnimationComplete"],
        ef = {};
    class eg {
        scrapeMotionValuesFromProps(t, e, i) {
            return {}
        }
        constructor({
            parent: t,
            props: e,
            presenceContext: i,
            reducedMotionConfig: s,
            skipAnimations: n,
            blockInitialAnimation: r,
            visualState: o
        }, a = {}) {
            this.current = null, this.children = new Set, this.isVariantNode = !1, this.isControllingVariants = !1, this.shouldReduceMotion = null, this.shouldSkipAnimations = !1, this.values = new Map, this.KeyframeResolver = tR, this.features = {}, this.valueSubscriptions = new Map, this.prevMotionValues = {}, this.hasBeenMounted = !1, this.events = {}, this.propEventSubscriptions = {}, this.notifyUpdate = () => this.notify("Update", this.latestValues), this.render = () => {
                this.current && (this.triggerBuild(), this.renderInstance(this.current, this.renderState, this.props.style, this.projection))
            }, this.renderScheduledAt = 0, this.scheduleRender = () => {
                let t = t9.now();
                this.renderScheduledAt < t && (this.renderScheduledAt = t, tb.render(this.render, !1, !0))
            };
            const {
                latestValues: l,
                renderState: h
            } = o;
            this.latestValues = l, this.baseTarget = { ...l
            }, this.initialValues = e.initial ? { ...l
            } : {}, this.renderState = h, this.parent = t, this.props = e, this.presenceContext = i, this.depth = t ? t.depth + 1 : 0, this.reducedMotionConfig = s, this.skipAnimationsConfig = n, this.options = a, this.blockInitialAnimation = !!r, this.isControllingVariants = ea(e), this.isVariantNode = el(e), this.isVariantNode && (this.variantChildren = new Set), this.manuallyAnimateOnMount = !!(t && t.current);
            const {
                willChange: u,
                ...c
            } = this.scrapeMotionValuesFromProps(e, {}, this);
            for (const t in c) {
                const e = c[t];
                void 0 !== l[t] && z(e) && e.set(l[t])
            }
        }
        mount(t) {
            if (this.hasBeenMounted)
                for (let t in this.initialValues) this.values.get(t) ? .jump(this.initialValues[t]), this.latestValues[t] = this.initialValues[t];
            this.current = t, ei.set(t, this), this.projection && !this.projection.instance && this.projection.mount(t), this.parent && this.isVariantNode && !this.isControllingVariants && (this.removeFromVariantTree = this.parent.addVariantChild(this)), this.values.forEach((t, e) => this.bindToMotionValue(e, t)), "never" === this.reducedMotionConfig ? this.shouldReduceMotion = !1 : "always" === this.reducedMotionConfig ? this.shouldReduceMotion = !0 : (eu.current || function() {
                if (eu.current = !0, ec)
                    if (window.matchMedia) {
                        let t = window.matchMedia("(prefers-reduced-motion)"),
                            e = () => eh.current = t.matches;
                        t.addEventListener("change", e), e()
                    } else eh.current = !1
            }(), this.shouldReduceMotion = eh.current), this.shouldSkipAnimations = this.skipAnimationsConfig ? ? !1, this.parent ? .addChild(this), this.update(this.props, this.presenceContext), this.hasBeenMounted = !0
        }
        unmount() {
            for (let t in this.projection && this.projection.unmount(), tS(this.notifyUpdate), tS(this.render), this.valueSubscriptions.forEach(t => t()), this.valueSubscriptions.clear(), this.removeFromVariantTree && this.removeFromVariantTree(), this.parent ? .removeChild(this), this.events) this.events[t].clear();
            for (let t in this.features) {
                let e = this.features[t];
                e && (e.unmount(), e.isMounted = !1)
            }
            this.current = null
        }
        addChild(t) {
            this.children.add(t), this.enteringChildren ? ? (this.enteringChildren = new Set), this.enteringChildren.add(t)
        }
        removeChild(t) {
            this.children.delete(t), this.enteringChildren && this.enteringChildren.delete(t)
        }
        bindToMotionValue(t, e) {
            let i;
            if (this.valueSubscriptions.has(t) && this.valueSubscriptions.get(t)(), e.accelerate && t7.has(t) && this.current instanceof HTMLElement) {
                let {
                    factory: i,
                    keyframes: s,
                    times: n,
                    ease: r,
                    duration: o
                } = e.accelerate, a = new t5({
                    element: this.current,
                    name: t,
                    keyframes: s,
                    times: n,
                    ease: r,
                    duration: tI(o)
                }), l = i(a);
                this.valueSubscriptions.set(t, () => {
                    l(), a.cancel()
                });
                return
            }
            let n = s.has(t);
            n && this.onBindTransform && this.onBindTransform();
            let r = e.on("change", e => {
                this.latestValues[t] = e, this.props.onUpdate && tb.preRender(this.notifyUpdate), n && this.projection && (this.projection.isTransformDirty = !0), this.scheduleRender()
            });
            "u" > typeof window && window.MotionCheckAppearSync && (i = window.MotionCheckAppearSync(this, t, e)), this.valueSubscriptions.set(t, () => {
                r(), i && i()
            })
        }
        sortNodePosition(t) {
            return this.current && this.sortInstanceNodePosition && this.type === t.type ? this.sortInstanceNodePosition(this.current, t.current) : 0
        }
        updateFeatures() {
            let t = "animation";
            for (t in ef) {
                let e = ef[t];
                if (!e) continue;
                let {
                    isEnabled: i,
                    Feature: s
                } = e;
                if (!this.features[t] && s && i(this.props) && (this.features[t] = new s(this)), this.features[t]) {
                    let e = this.features[t];
                    e.isMounted ? e.update() : (e.mount(), e.isMounted = !0)
                }
            }
        }
        triggerBuild() {
            this.build(this.renderState, this.latestValues, this.props)
        }
        measureViewportBox() {
            return this.current ? this.measureInstanceViewportBox(this.current, this.props) : G()
        }
        getStaticValue(t) {
            return this.latestValues[t]
        }
        setStaticValue(t, e) {
            this.latestValues[t] = e
        }
        update(t, e) {
            (t.transformTemplate || this.props.transformTemplate) && this.scheduleRender(), this.prevProps = this.props, this.props = t, this.prevPresenceContext = this.presenceContext, this.presenceContext = e;
            for (let e = 0; e < ep.length; e++) {
                let i = ep[e];
                this.propEventSubscriptions[i] && (this.propEventSubscriptions[i](), delete this.propEventSubscriptions[i]);
                let s = t["on" + i];
                s && (this.propEventSubscriptions[i] = this.on(i, s))
            }
            this.prevMotionValues = function(t, e, i) {
                for (let s in e) {
                    let n = e[s],
                        r = i[s];
                    if (z(n)) t.addValue(s, n);
                    else if (z(r)) t.addValue(s, et(n, {
                        owner: t
                    }));
                    else if (r !== n)
                        if (t.hasValue(s)) {
                            let e = t.getValue(s);
                            !0 === e.liveStyle ? e.jump(n) : e.hasAnimated || e.set(n)
                        } else {
                            let e = t.getStaticValue(s);
                            t.addValue(s, et(void 0 !== e ? e : n, {
                                owner: t
                            }))
                        }
                }
                for (let s in i) void 0 === e[s] && t.removeValue(s);
                return e
            }(this, this.scrapeMotionValuesFromProps(t, this.prevProps || {}, this), this.prevMotionValues), this.handleChildMotionValue && this.handleChildMotionValue()
        }
        getProps() {
            return this.props
        }
        getVariant(t) {
            return this.props.variants ? this.props.variants[t] : void 0
        }
        getDefaultTransition() {
            return this.props.transition
        }
        getTransformPagePoint() {
            return this.props.transformPagePoint
        }
        getClosestVariantNode() {
            return this.isVariantNode ? this : this.parent ? this.parent.getClosestVariantNode() : void 0
        }
        addVariantChild(t) {
            let e = this.getClosestVariantNode();
            if (e) return e.variantChildren && e.variantChildren.add(t), () => e.variantChildren.delete(t)
        }
        addValue(t, e) {
            let i = this.values.get(t);
            e !== i && (i && this.removeValue(t), this.bindToMotionValue(t, e), this.values.set(t, e), this.latestValues[t] = e.get())
        }
        removeValue(t) {
            this.values.delete(t);
            let e = this.valueSubscriptions.get(t);
            e && (e(), this.valueSubscriptions.delete(t)), delete this.latestValues[t], this.removeValueFromRenderState(t, this.renderState)
        }
        hasValue(t) {
            return this.values.has(t)
        }
        getValue(t, e) {
            if (this.props.values && this.props.values[t]) return this.props.values[t];
            let i = this.values.get(t);
            return void 0 === i && void 0 !== e && (i = et(null === e ? void 0 : e, {
                owner: this
            }), this.addValue(t, i)), i
        }
        readValue(t, e) {
            let i = void 0 === this.latestValues[t] && this.current ? this.getBaseTargetFromProps(this.props, t) ? ? this.readValueFromInstance(this.current, t, this.options) : this.latestValues[t];
            if (null != i) {
                let s, n;
                if ("string" == typeof i && (s = i, /^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(s) || (n = i, /^0[^.\s]+$/u.test(n)))) i = parseFloat(i);
                else {
                    let s;
                    s = i, !ee.find(K(s)) && k.test(e) && (i = tB(t, e))
                }
                this.setBaseTarget(t, z(i) ? i.get() : i)
            }
            return z(i) ? i.get() : i
        }
        setBaseTarget(t, e) {
            this.baseTarget[t] = e
        }
        getBaseTarget(t) {
            let e, {
                initial: i
            } = this.props;
            if ("string" == typeof i || "object" == typeof i) {
                let s = em(this.props, i, this.presenceContext ? .custom);
                s && (e = s[t])
            }
            if (i && void 0 !== e) return e;
            let s = this.getBaseTargetFromProps(this.props, t);
            return void 0 === s || z(s) ? void 0 !== this.initialValues[t] && void 0 === e ? void 0 : this.baseTarget[t] : s
        }
        on(t, e) {
            return this.events[t] || (this.events[t] = new tW), this.events[t].add(e)
        }
        notify(t, ...e) {
            this.events[t] && this.events[t].notify(...e)
        }
        scheduleRenderMicrotask() {
            t6.render(this.render)
        }
    }
    t.s(["VisualElement", 0, eg, "getFeatureDefinitions", 0, function() {
        return ef
    }, "setFeatureDefinitions", 0, function(t) {
        ef = t
    }], 617218);
    class ev extends eg {
        constructor() {
            super(...arguments), this.KeyframeResolver = tj
        }
        sortInstanceNodePosition(t, e) {
            return 2 & t.compareDocumentPosition(e) ? 1 : -1
        }
        getBaseTargetFromProps(t, e) {
            let i = t.style;
            return i ? i[e] : void 0
        }
        removeValueFromRenderState(t, {
            vars: e,
            style: i
        }) {
            delete e[t], delete i[t]
        }
        handleChildMotionValue() {
            this.childSubscription && (this.childSubscription(), delete this.childSubscription);
            let {
                children: t
            } = this.props;
            z(t) && (this.childSubscription = t.on("change", t => {
                this.current && (this.current.textContent = `${t}`)
            }))
        }
    }

    function ey(t) {
        return t.replace(/([A-Z])/g, t => `-${t.toLowerCase()}`)
    }
    t.s(["camelToDash", 0, ey], 793787);
    let ex = (t, e) => e && "number" == typeof t ? e.transform(t) : t,
        eT = {
            x: "translateX",
            y: "translateY",
            z: "translateZ",
            transformPerspective: "perspective"
        },
        ew = i.length;

    function eb(t, e, n) {
        let {
            style: r,
            vars: o,
            transformOrigin: a
        } = t, l = !1, h = !1;
        for (let t in e) {
            let i = e[t];
            if (s.has(t)) {
                l = !0;
                continue
            }
            if (J(t)) {
                o[t] = i;
                continue
            } {
                let e = ex(i, O[t]);
                t.startsWith("origin") ? (h = !0, a[t] = e) : r[t] = e
            }
        }
        if (!e.transform && (l || n ? r.transform = function(t, e, s) {
                let n = "",
                    r = !0;
                for (let o = 0; o < ew; o++) {
                    let a = i[o],
                        l = t[a];
                    if (void 0 === l) continue;
                    let h = !0;
                    if ("number" == typeof l) h = l === +!!a.startsWith("scale");
                    else {
                        let t = parseFloat(l);
                        h = a.startsWith("scale") ? 1 === t : 0 === t
                    }
                    if (!h || s) {
                        let t = ex(l, O[a]);
                        if (!h) {
                            r = !1;
                            let e = eT[a] || a;
                            n += `${e}(${t}) `
                        }
                        s && (e[a] = t)
                    }
                }
                let o = t.pathRotation;
                return o && (r = !1, n += `rotate(${ex(o,O.pathRotation)}) `), n = n.trim(), s ? n = s(e, r ? "" : n) : r && (n = "none"), n
            }(e, t.transform, n) : r.transform && (r.transform = "none")), h) {
            let {
                originX: t = "50%",
                originY: e = "50%",
                originZ: i = 0
            } = a;
            r.transformOrigin = `${t} ${e} ${i}`
        }
    }
    t.s(["buildHTMLStyles", 0, eb], 544947);
    let eS = {
            offset: "stroke-dashoffset",
            array: "stroke-dasharray"
        },
        eP = {
            offset: "strokeDashoffset",
            array: "strokeDasharray"
        },
        eM = ["offsetDistance", "offsetPath", "offsetRotate", "offsetAnchor"];

    function eA(t, {
        attrX: e,
        attrY: i,
        attrScale: s,
        pathLength: n,
        pathSpacing: r = 1,
        pathOffset: o = 0,
        ...a
    }, l, h, u) {
        if (eb(t, a, h), l) {
            t.style.viewBox && (t.attrs.viewBox = t.style.viewBox);
            return
        }
        t.attrs = t.style, t.style = {};
        let {
            attrs: c,
            style: d
        } = t;
        for (let t of (c.transform && (d.transform = c.transform, delete c.transform), (d.transform || c.transformOrigin) && (d.transformOrigin = c.transformOrigin ? ? "50% 50%", delete c.transformOrigin), d.transform && (d.transformBox = u ? .transformBox ? ? "fill-box", delete c.transformBox), eM)) void 0 !== c[t] && (d[t] = c[t], delete c[t]);
        void 0 !== e && (c.x = e), void 0 !== i && (c.y = i), void 0 !== s && (c.scale = s), void 0 !== n && function(t, e, i = 1, s = 0, n = !0) {
            t.pathLength = 1;
            let r = n ? eS : eP;
            t[r.offset] = `${-s}`, t[r.array] = `${e} ${i}`
        }(c, n, r, o, !1)
    }
    t.s(["buildSVGAttrs", 0, eA], 181261);
    let eV = new Set(["baseFrequency", "diffuseConstant", "kernelMatrix", "kernelUnitLength", "keySplines", "keyTimes", "limitingConeAngle", "markerHeight", "markerWidth", "numOctaves", "targetX", "targetY", "surfaceScale", "specularConstant", "specularExponent", "stdDeviation", "tableValues", "viewBox", "gradientTransform", "pathLength", "startOffset", "textLength", "lengthAdjust"]),
        eE = t => "string" == typeof t && "svg" === t.toLowerCase();

    function eC(t, {
        style: e,
        vars: i
    }, s, n) {
        let r, o = t.style;
        for (r in e) o[r] = e[r];
        for (r in n ? .applyProjectionStyles(o, s), i) o.setProperty(r, i[r])
    }
    t.s(["isSVGTag", 0, eE], 399951);
    let eD = ["borderTopLeftRadius", "borderTopRightRadius", "borderBottomRightRadius", "borderBottomLeftRadius"];

    function ek(t, e) {
        return e.max === e.min ? 0 : t / (e.max - e.min) * 100
    }
    t.s(["cornerRadiusProps", 0, eD], 895051);
    let eR = {
            correct: (t, e) => {
                if (!e.target) return t;
                if ("string" == typeof t)
                    if (!x.test(t)) return t;
                    else t = parseFloat(t);
                let i = ek(t, e.target.x),
                    s = ek(t, e.target.y);
                return `${i}% ${s}%`
            }
        },
        eL = (t, e, i) => t + (e - t) * i;
    t.s(["mixNumber", 0, eL], 100706);
    let eB = {
        borderRadius: { ...eR,
            applyTo: [...eD]
        },
        borderTopLeftRadius: eR,
        borderTopRightRadius: eR,
        borderBottomLeftRadius: eR,
        borderBottomRightRadius: eR,
        boxShadow: {
            correct: (t, {
                treeScale: e,
                projectionDelta: i
            }) => {
                let s = k.parse(t);
                if (s.length > 5) return t;
                let n = k.createTransformer(t),
                    r = +("number" != typeof s[0]),
                    o = i.x.scale * e.x,
                    a = i.y.scale * e.y;
                s[0 + r] /= o, s[1 + r] /= a;
                let l = eL(o, a, .5);
                return "number" == typeof s[2 + r] && (s[2 + r] /= l), "number" == typeof s[3 + r] && (s[3 + r] /= l), n(s)
            }
        }
    };

    function eF(t, {
        layout: e,
        layoutId: i
    }) {
        return s.has(t) || t.startsWith("origin") || (e || void 0 !== i) && (!!eB[t] || "opacity" === t)
    }

    function ej(t, e, i) {
        let s = t.style,
            n = e ? .style,
            r = {};
        if (!s) return r;
        for (let e in s)(z(s[e]) || n && z(n[e]) || eF(e, t) || i ? .getValue(e) ? .liveStyle !== void 0) && (r[e] = s[e]);
        return r
    }

    function eI(t, e, s) {
        let n = ej(t, e, s);
        for (let s in t)(z(t[s]) || z(e[s])) && (n[-1 !== i.indexOf(s) ? "attr" + s.charAt(0).toUpperCase() + s.substring(1) : s] = t[s]);
        return n
    }
    t.s(["scaleCorrectors", 0, eB], 924463), t.s(["isForcedMotionValue", 0, eF], 130789), t.s(["scrapeMotionValuesFromProps", 0, ej], 984049), t.s(["scrapeMotionValuesFromProps", 0, eI], 767926);
    class eO extends ev {
        constructor() {
            super(...arguments), this.type = "svg", this.isSVGTag = !1, this.measureInstanceViewportBox = G
        }
        getBaseTargetFromProps(t, e) {
            return t[e]
        }
        readValueFromInstance(t, e) {
            if (s.has(e)) {
                let t = U(e);
                return t && t.default || 0
            }
            return e = eV.has(e) ? e : ey(e), t.getAttribute(e)
        }
        scrapeMotionValuesFromProps(t, e, i) {
            return eI(t, e, i)
        }
        build(t, e, i) {
            eA(t, e, this.isSVGTag, i.transformTemplate, i.style)
        }
        renderInstance(t, e, i, s) {
            for (let i in eC(t, e, void 0, s), e.attrs) t.setAttribute(eV.has(i) ? i : ey(i), e.attrs[i])
        }
        mount(t) {
            this.isSVGTag = eE(t.tagName), super.mount(t)
        }
    }

    function eN({
        top: t,
        left: e,
        right: i,
        bottom: s
    }) {
        return {
            x: {
                min: e,
                max: i
            },
            y: {
                min: t,
                max: s
            }
        }
    }

    function eU(t, e) {
        if (!e) return t;
        let i = e({
                x: t.left,
                y: t.top
            }),
            s = e({
                x: t.right,
                y: t.bottom
            });
        return {
            top: i.y,
            left: i.x,
            bottom: s.y,
            right: s.x
        }
    }

    function eW(t) {
        return void 0 === t || 1 === t
    }

    function e$({
        scale: t,
        scaleX: e,
        scaleY: i
    }) {
        return !eW(t) || !eW(e) || !eW(i)
    }

    function eG(t) {
        return e$(t) || ez(t) || t.z || t.rotate || t.rotateX || t.rotateY || t.skewX || t.skewY
    }

    function ez(t) {
        var e, i;
        return (e = t.x) && "0%" !== e || (i = t.y) && "0%" !== i
    }

    function eH(t, e, i) {
        return i + e * (t - i)
    }

    function eK(t, e, i, s, n) {
        return void 0 !== n && (t = eH(t, n, s)), eH(t, i, s) + e
    }

    function eY(t, e = 0, i = 1, s, n) {
        t.min = eK(t.min, e, i, s, n), t.max = eK(t.max, e, i, s, n)
    }

    function eX(t, {
        x: e,
        y: i
    }) {
        eY(t.x, e.translate, e.scale, e.originPoint), eY(t.y, i.translate, i.scale, i.originPoint)
    }

    function eq(t, e) {
        t.min += e, t.max += e
    }

    function e_(t, e, i, s, n = .5) {
        let r = eL(t.min, t.max, n);
        eY(t, e, i, r, s)
    }

    function eZ(t, e) {
        return "string" == typeof t ? parseFloat(t) / 100 * (e.max - e.min) : t
    }

    function eJ(t, e, i) {
        let s = i ? ? t;
        e_(t.x, eZ(e.x, s.x), e.scaleX, e.scale, e.originX), e_(t.y, eZ(e.y, s.y), e.scaleY, e.scale, e.originY)
    }

    function eQ(t, e) {
        return eN(eU(t.getBoundingClientRect(), e))
    }
    t.s(["convertBoundingBoxToBox", 0, eN, "convertBoxToBoundingBox", 0, function({
        x: t,
        y: e
    }) {
        return {
            top: e.min,
            right: t.max,
            bottom: e.max,
            left: t.min
        }
    }, "transformBoxPoints", 0, eU], 27677), t.s(["has2DTranslate", 0, ez, "hasScale", 0, e$, "hasTransform", 0, eG], 177777), t.s(["applyBoxDelta", 0, eX, "applyTreeDeltas", 0, function(t, e, i, s = !1) {
        let n, r, o = i.length;
        if (o) {
            e.x = e.y = 1;
            for (let a = 0; a < o; a++) {
                r = (n = i[a]).projectionDelta;
                let {
                    visualElement: o
                } = n.options;
                (!o || !o.props.style || "contents" !== o.props.style.display) && (s && n.options.layoutScroll && n.scroll && n !== n.root && (eq(t.x, -n.scroll.offset.x), eq(t.y, -n.scroll.offset.y)), r && (e.x *= r.x.scale, e.y *= r.y.scale, eX(t, r)), s && eG(n.latestValues) && eJ(t, n.latestValues, n.layout ? .layoutBox))
            }
            e.x < 1.0000000000001 && e.x > .999999999999 && (e.x = 1), e.y < 1.0000000000001 && e.y > .999999999999 && (e.y = 1)
        }
    }, "scalePoint", 0, eH, "transformBox", 0, eJ, "translateAxis", 0, eq], 135636), t.s(["measurePageBox", 0, function(t, e, i) {
        let s = eQ(t, i),
            {
                scroll: n
            } = e;
        return n && (eq(s.x, n.offset.x), eq(s.y, n.offset.y)), s
    }, "measureViewportBox", 0, eQ], 153689);
    class e0 extends ev {
        constructor() {
            super(...arguments), this.type = "html", this.renderInstance = eC
        }
        readValueFromInstance(t, e) {
            if (s.has(e)) return this.projection ? .isProjecting ? tc(e) : ((t, e) => {
                let {
                    transform: i = "none"
                } = getComputedStyle(t);
                return td(i, e)
            })(t, e); {
                let i = window.getComputedStyle(t),
                    s = (J(e) ? i.getPropertyValue(e) : i[e]) || 0;
                return "string" == typeof s ? s.trim() : s
            }
        }
        measureInstanceViewportBox(t, {
            transformPagePoint: e
        }) {
            return eQ(t, e)
        }
        build(t, e, i) {
            eb(t, e, i.transformTemplate)
        }
        scrapeMotionValuesFromProps(t, e, i) {
            return ej(t, e, i)
        }
    }
    var e1 = t.i(271645);
    let e5 = ["animate", "circle", "defs", "desc", "ellipse", "g", "image", "line", "filter", "marker", "mask", "metadata", "path", "pattern", "polygon", "polyline", "rect", "stop", "switch", "symbol", "svg", "text", "tspan", "use", "view"];

    function e7(t) {
        if ("string" != typeof t || t.includes("-"));
        else if (e5.indexOf(t) > -1 || /[A-Z]/u.test(t)) return !0;
        return !1
    }
    t.s(["isSVGComponent", 0, e7], 944966), t.s(["createDomVisualElement", 0, (t, e) => e.isSVG ? ? e7(t) ? new eO(e) : new e0(e, {
        allowProjection: t !== e1.Fragment
    })], 154505)
}, 231178, t => {
    "use strict";
    let e = (0, t.i(271645).createContext)({});
    t.s(["LayoutGroupContext", 0, e])
}, 648070, t => {
    "use strict";
    let e = (0, t.i(271645).createContext)({
        strict: !1
    });
    t.s(["LazyContext", 0, e])
}, 737806, t => {
    "use strict";
    let e = (0, t.i(271645).createContext)({
        transformPagePoint: t => t,
        isStatic: !1,
        reducedMotion: "never"
    });
    t.s(["MotionConfigContext", 0, e])
}, 688291, 582474, 886549, 911587, 308576, 830665, 733871, t => {
    "use strict";
    var e, i = t.i(271645);
    let s = (0, i.createContext)({});
    t.s(["MotionContext", 0, s], 688291);
    var n = t.i(587576),
        r = t.i(732525);

    function o(t) {
        return Array.isArray(t) ? t.join(" ") : t
    }
    t.s(["useCreateMotionContext", 0, function(t) {
        let {
            initial: e,
            animate: a
        } = function(t, e) {
            if ((0, n.isControllingVariants)(t)) {
                let {
                    initial: e,
                    animate: i
                } = t;
                return {
                    initial: !1 === e || (0, r.isVariantLabel)(e) ? e : void 0,
                    animate: (0, r.isVariantLabel)(i) ? i : void 0
                }
            }
            return !1 !== t.inherit ? e : {}
        }(t, (0, i.useContext)(s));
        return (0, i.useMemo)(() => ({
            initial: e,
            animate: a
        }), [o(e), o(a)])
    }], 582474);
    var a = t.i(83411),
        l = t.i(130789),
        h = t.i(544947);
    let u = () => ({
        style: {},
        transform: {},
        transformOrigin: {},
        vars: {}
    });

    function c(t, e, i) {
        for (let s in e)(0, a.isMotionValue)(e[s]) || (0, l.isForcedMotionValue)(s, i) || (t[s] = e[s])
    }
    t.s(["createHtmlRenderState", 0, u], 886549);
    var d = t.i(181261),
        m = t.i(399951);
    let p = () => ({ ...u(),
        attrs: {}
    });
    t.s(["createSvgRenderState", 0, p], 911587);
    let f = new Set(["animate", "exit", "variants", "initial", "style", "values", "variants", "transition", "transformTemplate", "custom", "inherit", "onBeforeLayoutMeasure", "onAnimationStart", "onAnimationComplete", "onUpdate", "onDragStart", "onDrag", "onDragEnd", "onMeasureDragConstraints", "onDirectionLock", "onDragTransitionEnd", "_dragX", "_dragY", "onHoverStart", "onHoverEnd", "onViewportEnter", "onViewportLeave", "globalTapTarget", "propagate", "ignoreStrict", "viewport"]);

    function g(t) {
        return t.startsWith("while") || t.startsWith("drag") && "draggable" !== t || t.startsWith("layout") || t.startsWith("onTap") || t.startsWith("onPan") || t.startsWith("onLayout") || f.has(t)
    }
    let v = t => !g(t);
    try {
        e = (() => {
            let t = Error("Cannot find module '@emotion/is-prop-valid'");
            throw t.code = "MODULE_NOT_FOUND", t
        })().default, "function" == typeof e && (v = t => t.startsWith("on") ? !g(t) : e(t))
    } catch {}
    var y = t.i(944966);
    t.s(["useRender", 0, function(t, e, s, {
        latestValues: n
    }, r, o = !1, l) {
        let f = (l ? ? (0, y.isSVGComponent)(t) ? function(t, e, s, n) {
                let r = (0, i.useMemo)(() => {
                    let i = p();
                    return (0, d.buildSVGAttrs)(i, e, (0, m.isSVGTag)(n), t.transformTemplate, t.style), { ...i.attrs,
                        style: { ...i.style
                        }
                    }
                }, [e]);
                if (t.style) {
                    let e = {};
                    c(e, t.style, t), r.style = { ...e,
                        ...r.style
                    }
                }
                return r
            } : function(t, e) {
                let s, n, r = {},
                    o = (s = t.style || {}, c(n = {}, s, t), Object.assign(n, function({
                        transformTemplate: t
                    }, e) {
                        return (0, i.useMemo)(() => {
                            let i = u();
                            return (0, h.buildHTMLStyles)(i, e, t), Object.assign({}, i.vars, i.style)
                        }, [e])
                    }(t, e)), n);
                return t.drag && !1 !== t.dragListener && (r.draggable = !1, o.userSelect = o.WebkitUserSelect = o.WebkitTouchCallout = "none", o.touchAction = !0 === t.drag ? "none" : `pan-${"x"===t.drag?"y":"x"}`), void 0 === t.tabIndex && (t.onTap || t.onTapStart || t.whileTap) && (r.tabIndex = 0), r.style = o, r
            })(e, n, r, t),
            x = function(t, e, i) {
                let s = {};
                for (let n in t)("values" !== n || "object" != typeof t.values) && !(0, a.isMotionValue)(t[n]) && (v(n) || !0 === i && g(n) || !e && !g(n) || t.draggable && n.startsWith("onDrag")) && (s[n] = t[n]);
                return s
            }(e, "string" == typeof t, o),
            T = t !== i.Fragment ? { ...x,
                ...f,
                ref: s
            } : {},
            {
                children: w
            } = e,
            b = (0, i.useMemo)(() => (0, a.isMotionValue)(w) ? w.get() : w, [w]);
        return (0, i.createElement)(t, { ...T,
            children: b
        })
    }], 308576);
    var x = t.i(984049);
    t.s(["scrapeHTMLMotionValuesFromProps", () => x.scrapeMotionValuesFromProps], 830665), t.s(["resolveMotionValue", 0, function(t) {
        return (0, a.isMotionValue)(t) ? t.get() : t
    }], 733871)
}, 821476, t => {
    "use strict";
    let e = (0, t.i(271645).createContext)(null);
    t.s(["PresenceContext", 0, e])
}, 947414, t => {
    "use strict";
    var e = t.i(271645);
    t.s(["useConstant", 0, function(t) {
        let i = (0, e.useRef)(null);
        return null === i.current && (i.current = t()), i.current
    }])
}, 711805, 501664, 476948, 513565, 321967, 683640, 535043, 104035, 325522, t => {
    "use strict";
    var e = t.i(830665),
        i = t.i(733871),
        s = t.i(587576),
        n = t.i(885983),
        r = t.i(386579),
        o = t.i(271645),
        a = t.i(688291),
        l = t.i(821476),
        h = t.i(947414);
    let u = t => (e, u) => {
        let c = (0, o.useContext)(a.MotionContext),
            d = (0, o.useContext)(l.PresenceContext),
            m = () => (function({
                scrapeMotionValuesFromProps: t,
                createRenderState: e
            }, o, a, l) {
                return {
                    latestValues: function(t, e, o, a) {
                        let l = {},
                            h = a(t, {});
                        for (let t in h) l[t] = (0, i.resolveMotionValue)(h[t]);
                        let {
                            initial: u,
                            animate: c
                        } = t, d = (0, s.isControllingVariants)(t), m = (0, s.isVariantNode)(t);
                        e && m && !d && !1 !== t.inherit && (void 0 === u && (u = e.initial), void 0 === c && (c = e.animate));
                        let p = !!o && !1 === o.initial,
                            f = (p = p || !1 === u) ? c : u;
                        if (f && "boolean" != typeof f && !(0, n.isAnimationControls)(f)) {
                            let e = Array.isArray(f) ? f : [f];
                            for (let i = 0; i < e.length; i++) {
                                let s = (0, r.resolveVariantFromProps)(t, e[i]);
                                if (s) {
                                    let {
                                        transitionEnd: t,
                                        transition: e,
                                        ...i
                                    } = s;
                                    for (let t in i) {
                                        let e = i[t];
                                        if (Array.isArray(e)) {
                                            let t = p ? e.length - 1 : 0;
                                            e = e[t]
                                        }
                                        null !== e && (l[t] = e)
                                    }
                                    for (let e in t) l[e] = t[e]
                                }
                            }
                        }
                        return l
                    }(o, a, l, t),
                    renderState: e()
                }
            })(t, e, c, d);
        return u ? m() : (0, h.useConstant)(m)
    };
    var c = t.i(886549);
    let d = u({
        scrapeMotionValuesFromProps: e.scrapeHTMLMotionValuesFromProps,
        createRenderState: c.createHtmlRenderState
    });
    t.s(["useHTMLVisualState", 0, d], 711805);
    var m = t.i(767926),
        m = m,
        p = t.i(911587);
    let f = u({
        scrapeMotionValuesFromProps: m.scrapeMotionValuesFromProps,
        createRenderState: p.createSvgRenderState
    });
    t.s(["useSVGVisualState", 0, f], 501664);
    var g = t.i(617218);
    let v = {
            animation: ["animate", "variants", "whileHover", "whileTap", "exit", "whileInView", "whileFocus", "whileDrag"],
            exit: ["exit"],
            drag: ["drag", "dragControls"],
            focus: ["whileFocus"],
            hover: ["whileHover", "onHoverStart", "onHoverEnd"],
            tap: ["whileTap", "onTap", "onTapStart", "onTapCancel"],
            pan: ["onPan", "onPanStart", "onPanSessionStart", "onPanEnd"],
            inView: ["whileInView", "onViewportEnter", "onViewportLeave"],
            layout: ["layout", "layoutId"]
        },
        y = !1;

    function x() {
        return ! function() {
            if (y) return;
            let t = {};
            for (let e in v) t[e] = {
                isEnabled: t => v[e].some(e => !!t[e])
            };
            (0, g.setFeatureDefinitions)(t), y = !0
        }(), (0, g.getFeatureDefinitions)()
    }
    t.s(["getInitializedFeatureDefinitions", 0, x], 476948), t.s(["loadFeatures", 0, function(t) {
        let e = x();
        for (let i in t) e[i] = { ...e[i],
            ...t[i]
        };
        (0, g.setFeatureDefinitions)(e)
    }], 513565);
    let T = Symbol.for("motionComponentSymbol");
    t.s(["motionComponentSymbol", 0, T], 321967), t.s(["useMotionRef", 0, function(t, e, i) {
        let s = (0, o.useRef)(i);
        (0, o.useInsertionEffect)(() => {
            s.current = i
        });
        let n = (0, o.useRef)(null);
        return (0, o.useCallback)(i => {
            i && t.onMount ? .(i), e && (i ? e.mount(i) : e.unmount());
            let r = s.current;
            if ("function" == typeof r)
                if (i) {
                    let t = r(i);
                    "function" == typeof t && (n.current = t)
                } else n.current ? (n.current(), n.current = null) : r(i);
            else r && (r.current = i)
        }, [e])
    }], 683640);
    let w = "data-" + (0, t.i(793787).camelToDash)("framerAppearId");
    t.s(["optimizedAppearDataAttribute", 0, w], 535043);
    let b = (0, o.createContext)({});
    t.s(["SwitchLayoutGroupContext", 0, b], 104035), t.s(["isRefObject", 0, function(t) {
        return t && "object" == typeof t && Object.prototype.hasOwnProperty.call(t, "current")
    }], 325522)
}, 674008, t => {
    "use strict";
    var e = t.i(271645);
    let i = "u" > typeof window ? e.useLayoutEffect : e.useEffect;
    t.s(["useIsomorphicLayoutEffect", 0, i], 674008)
}, 907051, 142098, 987333, 980538, 716896, 738638, 791559, 783920, 344230, 83352, 939011, 223070, 655559, 282774, 439676, 137541, 652101, t => {
    "use strict";
    t.i(247167);
    var e = t.i(843476),
        i = t.i(271645),
        s = t.i(231178),
        n = t.i(648070),
        r = t.i(737806),
        o = t.i(688291),
        a = t.i(582474),
        l = t.i(308576),
        h = t.i(944966),
        u = t.i(711805),
        c = t.i(501664),
        d = t.i(476948),
        m = t.i(513565),
        p = t.i(321967),
        f = t.i(683640),
        g = t.i(535043),
        v = t.i(821476),
        y = t.i(104035),
        x = t.i(325522),
        T = t.i(674008);

    function w(t, {
        forwardMotionProps: b = !1,
        type: S
    } = {}, P, M) {
        P && (0, m.loadFeatures)(P);
        let A = S ? "svg" === S : (0, h.isSVGComponent)(t),
            V = A ? c.useSVGVisualState : u.useHTMLVisualState;

        function E(h, u) {
            let c, m = { ...(0, i.useContext)(r.MotionConfigContext),
                    ...h,
                    layoutId: function({
                        layoutId: t
                    }) {
                        let e = (0, i.useContext)(s.LayoutGroupContext).id;
                        return e && void 0 !== t ? e + "-" + t : t
                    }(h)
                },
                {
                    isStatic: p
                } = m,
                w = (0, a.useCreateMotionContext)(h),
                S = V(h, p);
            if (!p && "u" > typeof window) {
                (0, i.useContext)(n.LazyContext).strict;
                let e = function(t) {
                    let {
                        drag: e,
                        layout: i
                    } = (0, d.getInitializedFeatureDefinitions)();
                    if (!e && !i) return {};
                    let s = { ...e,
                        ...i
                    };
                    return {
                        MeasureLayout: e ? .isEnabled(t) || i ? .isEnabled(t) ? s.MeasureLayout : void 0,
                        ProjectionNode: s.ProjectionNode
                    }
                }(m);
                c = e.MeasureLayout, w.visualElement = function(t, e, s, a, l, h) {
                    let {
                        visualElement: u
                    } = (0, i.useContext)(o.MotionContext), c = (0, i.useContext)(n.LazyContext), d = (0, i.useContext)(v.PresenceContext), m = (0, i.useContext)(r.MotionConfigContext), p = m.reducedMotion, f = m.skipAnimations, w = (0, i.useRef)(null), b = (0, i.useRef)(!1);
                    a = a || c.renderer, !w.current && a && (w.current = a(t, {
                        visualState: e,
                        parent: u,
                        props: s,
                        presenceContext: d,
                        blockInitialAnimation: !!d && !1 === d.initial,
                        reducedMotionConfig: p,
                        skipAnimations: f,
                        isSVG: h
                    }), b.current && w.current && (w.current.manuallyAnimateOnMount = !0));
                    let S = w.current,
                        P = (0, i.useContext)(y.SwitchLayoutGroupContext);
                    S && !S.projection && l && ("html" === S.type || "svg" === S.type) && function(t, e, i, s) {
                        let {
                            layoutId: n,
                            layout: r,
                            drag: o,
                            dragConstraints: a,
                            layoutScroll: l,
                            layoutRoot: h,
                            layoutAnchor: u,
                            layoutCrossfade: c
                        } = e;
                        t.projection = new i(t.latestValues, e["data-framer-portal-id"] ? void 0 : function t(e) {
                            if (e) return !1 !== e.options.allowProjection ? e.projection : t(e.parent)
                        }(t.parent)), t.projection.setOptions({
                            layoutId: n,
                            layout: r,
                            alwaysMeasureLayout: !!o || a && (0, x.isRefObject)(a),
                            visualElement: t,
                            animationType: "string" == typeof r ? r : "both",
                            initialPromotionConfig: s,
                            crossfade: c,
                            layoutScroll: l,
                            layoutRoot: h,
                            layoutAnchor: u
                        })
                    }(w.current, s, l, P);
                    let M = (0, i.useRef)(!1);
                    (0, i.useInsertionEffect)(() => {
                        S && M.current && S.update(s, d)
                    });
                    let A = s[g.optimizedAppearDataAttribute],
                        V = (0, i.useRef)(!!A && "u" > typeof window && !window.MotionHandoffIsComplete ? .(A) && window.MotionHasOptimisedAnimation ? .(A));
                    return (0, T.useIsomorphicLayoutEffect)(() => {
                        b.current = !0, S && (M.current = !0, window.MotionIsMounted = !0, S.updateFeatures(), S.scheduleRenderMicrotask(), V.current && S.animationState && S.animationState.animateChanges())
                    }), (0, i.useEffect)(() => {
                        S && (!V.current && S.animationState && S.animationState.animateChanges(), V.current && (queueMicrotask(() => {
                            window.MotionHandoffMarkAsComplete ? .(A)
                        }), V.current = !1), S.enteringChildren = void 0)
                    }), S
                }(t, S, m, M, e.ProjectionNode, A)
            }
            return (0, e.jsxs)(o.MotionContext.Provider, {
                value: w,
                children: [c && w.visualElement ? (0, e.jsx)(c, {
                    visualElement: w.visualElement,
                    ...m
                }) : null, (0, l.useRender)(t, h, (0, f.useMotionRef)(S, w.visualElement, u), S, p, b, A)]
            })
        }
        E.displayName = `motion.${"string"==typeof t?t:`create(${t.displayName??t.name??""})`}`;
        let C = (0, i.forwardRef)(E);
        return C[p.motionComponentSymbol] = t, C
    }
    t.s(["createMotionProxy", 0, function(t, e) {
        if ("u" < typeof Proxy) return w;
        let i = new Map,
            s = (i, s) => w(i, s, t, e);
        return new Proxy((t, e) => s(t, e), {
            get: (n, r) => "create" === r ? s : (i.has(r) || i.set(r, w(r, void 0, t, e)), i.get(r))
        })
    }], 907051);
    class b {
        constructor(t) {
            this.isMounted = !1, this.node = t
        }
        update() {}
    }
    t.s(["Feature", 0, b], 142098);
    var S = t.i(386579);

    function P(t, e, i) {
        let s = t.getProps();
        return (0, S.resolveVariantFromProps)(s, e, void 0 !== i ? i : s.custom, t)
    }

    function M(t, e) {
        if (t ? .inherit && e) {
            let {
                inherit: i,
                ...s
            } = t;
            return { ...e,
                ...s
            }
        }
        return t
    }

    function A(t, e) {
        let i = t ? .[e] ? ? t ? .default ? ? t;
        return i !== t ? M(i, t) : i
    }
    t.s(["getValueTransition", 0, A], 987333);
    var V = t.i(864440),
        E = t.i(486427);
    let C = t => Array.isArray(t);
    var D = t.i(846791),
        k = t.i(83411);

    function R(t, e) {
        let i = t.getValue("willChange");
        if ((0, k.isMotionValue)(i) && i.add) return i.add(e);
        if (!i && D.MotionGlobalConfig.WillChange) {
            let i = new D.MotionGlobalConfig.WillChange("auto");
            t.addValue("willChange", i), i.add(e)
        }
    }

    function L(t) {
        return t.props[g.optimizedAppearDataAttribute]
    }
    t.s(["addValueToWillChange", 0, R], 980538), t.s(["getOptimisedAppearId", 0, L], 716896);
    var B = t.i(763074),
        F = t.i(260830),
        j = t.i(496173);
    let I = (...t) => t.reduce((t, e) => i => e(t(i)));
    t.s(["pipe", 0, I], 738638);
    var O = t.i(476959),
        N = t.i(965566),
        U = t.i(19928),
        W = t.i(279444),
        $ = t.i(569577),
        G = t.i(463011),
        z = t.i(22660);

    function H(t, e, i) {
        return (i < 0 && (i += 1), i > 1 && (i -= 1), i < 1 / 6) ? t + (e - t) * 6 * i : i < .5 ? e : i < 2 / 3 ? t + (e - t) * (2 / 3 - i) * 6 : t
    }
    var K = t.i(766820);

    function Y(t, e) {
        return i => i > 0 ? e : t
    }
    var X = t.i(100706);
    let q = (t, e, i) => {
            let s = t * t,
                n = i * (e * e - s) + s;
            return n < 0 ? 0 : Math.sqrt(n)
        },
        _ = [G.hex, K.rgba, z.hsla];

    function Z(t) {
        let e = _.find(e => e.test(t));
        if ((0, N.warning)(!!e, `'${t}' is not an animatable color. Use the equivalent color code instead.`, "color-not-animatable"), !e) return !1;
        let i = e.parse(t);
        return e === z.hsla && (i = function({
            hue: t,
            saturation: e,
            lightness: i,
            alpha: s
        }) {
            t /= 360, i /= 100;
            let n = 0,
                r = 0,
                o = 0;
            if (e /= 100) {
                let s = i < .5 ? i * (1 + e) : i + e - i * e,
                    a = 2 * i - s;
                n = H(a, s, t + 1 / 3), r = H(a, s, t), o = H(a, s, t - 1 / 3)
            } else n = r = o = i;
            return {
                red: Math.round(255 * n),
                green: Math.round(255 * r),
                blue: Math.round(255 * o),
                alpha: s
            }
        }(i)), i
    }
    let J = (t, e) => {
            let i = Z(t),
                s = Z(e);
            if (!i || !s) return Y(t, e);
            let n = { ...i
            };
            return t => (n.red = q(i.red, s.red, t), n.green = q(i.green, s.green, t), n.blue = q(i.blue, s.blue, t), n.alpha = (0, X.mixNumber)(i.alpha, s.alpha, t), K.rgba.transform(n))
        },
        Q = new Set(["none", "hidden"]);

    function tt(t, e) {
        return i => (0, X.mixNumber)(t, e, i)
    }

    function te(t) {
        return "number" == typeof t ? tt : "string" == typeof t ? (0, U.isCSSVariableToken)(t) ? Y : W.color.test(t) ? J : tn : Array.isArray(t) ? ti : "object" == typeof t ? W.color.test(t) ? J : ts : Y
    }

    function ti(t, e) {
        let i = [...t],
            s = i.length,
            n = t.map((t, i) => te(t)(t, e[i]));
        return t => {
            for (let e = 0; e < s; e++) i[e] = n[e](t);
            return i
        }
    }

    function ts(t, e) {
        let i = { ...t,
                ...e
            },
            s = {};
        for (let n in i) void 0 !== t[n] && void 0 !== e[n] && (s[n] = te(t[n])(t[n], e[n]));
        return t => {
            for (let e in s) i[e] = s[e](t);
            return i
        }
    }
    let tn = (t, e) => {
        let i = $.complex.createTransformer(e),
            s = (0, $.analyseComplexValue)(t),
            n = (0, $.analyseComplexValue)(e);
        if (!(s.indexes.var.length === n.indexes.var.length && s.indexes.color.length === n.indexes.color.length && s.indexes.number.length >= n.indexes.number.length)) return (0, N.warning)(!0, `Complex values '${t}' and '${e}' too different to mix. Ensure all colors are of the same type, and that each contains the same quantity of number and color values. Falling back to instant transition.`, "complex-values-different"), Y(t, e);
        if (Q.has(t) && !n.values.length || Q.has(e) && !s.values.length) return Q.has(t) ? i => i <= 0 ? t : e : i => i >= 1 ? e : t;
        return I(ti(function(t, e) {
            let i = [],
                s = {
                    color: 0,
                    var: 0,
                    number: 0
                };
            for (let n = 0; n < e.values.length; n++) {
                let r = e.types[n],
                    o = t.indexes[r][s[r]],
                    a = t.values[o] ? ? 0;
                i[n] = a, s[r]++
            }
            return i
        }(s, n), n.values), i)
    };

    function tr(t, e, i) {
        return "number" == typeof t && "number" == typeof e && "number" == typeof i ? (0, X.mixNumber)(t, e, i) : te(t)(t, e)
    }
    var to = t.i(287022);
    let ta = t => {
        let e = ({
            timestamp: e
        }) => t(e);
        return {
            start: (t = !0) => to.frame.update(e, t),
            stop: () => (0, to.cancelFrame)(e),
            now: () => to.frameData.isProcessing ? to.frameData.timestamp : j.time.now()
        }
    };
    var tl = t.i(756512);

    function th(t) {
        let e = 0,
            i = t.next(e);
        for (; !i.done && e < 2e4;) e += 50, i = t.next(e);
        return e >= 2e4 ? 1 / 0 : e
    }
    let tu = .01,
        tc = 2,
        td = .005,
        tm = .5;

    function tp(t, e) {
        return t * Math.sqrt(1 - e * e)
    }
    let tf = ["duration", "bounce"],
        tg = ["stiffness", "damping", "mass"];

    function tv(t, e) {
        return e.some(e => void 0 !== t[e])
    }

    function ty(t = .3, e = .3) {
        let i, s, n, r, o, a, l = "object" != typeof t ? {
                visualDuration: t,
                keyframes: [0, 1],
                bounce: e
            } : t,
            {
                restSpeed: h,
                restDelta: u
            } = l,
            c = l.keyframes[0],
            d = l.keyframes[l.keyframes.length - 1],
            m = {
                done: !1,
                value: c
            },
            {
                stiffness: p,
                damping: f,
                mass: g,
                duration: v,
                velocity: y,
                isResolvedFromDuration: x
            } = function(t) {
                let e = {
                    velocity: 0,
                    stiffness: 100,
                    damping: 10,
                    mass: 1,
                    isResolvedFromDuration: !1,
                    ...t
                };
                if (!tv(t, tg) && tv(t, tf))
                    if (e.velocity = 0, t.visualDuration) {
                        let i = 2 * Math.PI / (1.2 * t.visualDuration),
                            s = i * i,
                            n = 2 * (0, O.clamp)(.05, 1, 1 - (t.bounce || 0)) * Math.sqrt(s);
                        e = { ...e,
                            mass: 1,
                            stiffness: s,
                            damping: n
                        }
                    } else {
                        let i = function({
                            duration: t = 800,
                            bounce: e = .3,
                            velocity: i = 0,
                            mass: s = 1
                        }) {
                            let n, r;
                            (0, N.warning)(t <= (0, B.secondsToMilliseconds)(10), "Spring duration must be 10 seconds or less", "spring-duration-limit");
                            let o = 1 - e;
                            o = (0, O.clamp)(.05, 1, o), t = (0, O.clamp)(.01, 10, (0, B.millisecondsToSeconds)(t)), o < 1 ? (n = e => {
                                let s = e * o,
                                    n = s * t;
                                return .001 - (s - i) / tp(e, o) * Math.exp(-n)
                            }, r = e => {
                                let s = e * o * t,
                                    r = Math.pow(o, 2) * Math.pow(e, 2) * t,
                                    a = Math.exp(-s),
                                    l = tp(Math.pow(e, 2), o);
                                return (s * i + i - r) * a * (-n(e) + .001 > 0 ? -1 : 1) / l
                            }) : (n = e => -.001 + Math.exp(-e * t) * ((e - i) * t + 1), r = e => t * t * (i - e) * Math.exp(-e * t));
                            let a = function(t, e, i) {
                                let s = i;
                                for (let i = 1; i < 12; i++) s -= t(s) / e(s);
                                return s
                            }(n, r, 5 / t);
                            if (t = (0, B.secondsToMilliseconds)(t), isNaN(a)) return {
                                stiffness: 100,
                                damping: 10,
                                duration: t
                            }; {
                                let e = Math.pow(a, 2) * s;
                                return {
                                    stiffness: e,
                                    damping: 2 * o * Math.sqrt(s * e),
                                    duration: t
                                }
                            }
                        }({ ...t,
                            velocity: 0
                        });
                        (e = { ...e,
                            ...i,
                            mass: 1
                        }).isResolvedFromDuration = !0
                    }
                return e
            }({ ...l,
                velocity: -(0, B.millisecondsToSeconds)(l.velocity || 0)
            }),
            T = y || 0,
            w = f / (2 * Math.sqrt(p * g)),
            b = d - c,
            S = (0, B.millisecondsToSeconds)(Math.sqrt(p / g)),
            P = 5 > Math.abs(b);
        if (h || (h = P ? tu : tc), u || (u = P ? td : tm), w < 1) n = tp(S, w), r = (T + w * S * b) / n, i = t => d - Math.exp(-w * S * t) * (r * Math.sin(n * t) + b * Math.cos(n * t)), o = w * S * r + b * n, a = w * S * b - r * n, s = t => Math.exp(-w * S * t) * (o * Math.sin(n * t) + a * Math.cos(n * t));
        else if (1 === w) {
            i = t => d - Math.exp(-S * t) * (b + (T + S * b) * t);
            let t = T + S * b;
            s = e => Math.exp(-S * e) * (S * t * e - T)
        } else {
            let t = S * Math.sqrt(w * w - 1);
            i = e => {
                let i = Math.exp(-w * S * e),
                    s = Math.min(t * e, 300);
                return d - i * ((T + w * S * b) * Math.sinh(s) + t * b * Math.cosh(s)) / t
            };
            let e = (T + w * S * b) / t,
                n = w * S * e - b * t,
                r = w * S * b - e * t;
            s = e => {
                let i = Math.exp(-w * S * e),
                    s = Math.min(t * e, 300);
                return i * (n * Math.sinh(s) + r * Math.cosh(s))
            }
        }
        let M = {
            calculatedDuration: x && v || null,
            velocity: t => (0, B.secondsToMilliseconds)(s(t)),
            next: t => {
                if (!x && w < 1) {
                    let e = Math.exp(-w * S * t),
                        i = Math.sin(n * t),
                        s = Math.cos(n * t),
                        l = d - e * (r * i + b * s);
                    return m.done = Math.abs((0, B.secondsToMilliseconds)(e * (o * i + a * s))) <= h && Math.abs(d - l) <= u, m.value = m.done ? d : l, m
                }
                let e = i(t);
                return x ? m.done = t >= v : m.done = Math.abs((0, B.secondsToMilliseconds)(s(t))) <= h && Math.abs(d - e) <= u, m.value = m.done ? d : e, m
            },
            toString: () => {
                let t = Math.min(th(M), 2e4),
                    e = (0, tl.generateLinearEasing)(e => M.next(t * e).value, t, 30);
                return t + "ms " + e
            },
            toTransition: () => {}
        };
        return M
    }
    ty.applyToOptions = t => {
        let e = function(t, e = 100, i) {
            let s = i({ ...t,
                    keyframes: [0, e]
                }),
                n = Math.min(th(s), 2e4);
            return {
                type: "keyframes",
                ease: t => s.next(n * t).value / e,
                duration: (0, B.millisecondsToSeconds)(n)
            }
        }(t, 100, ty);
        return t.ease = e.ease, t.duration = (0, B.secondsToMilliseconds)(e.duration), t.type = "keyframes", t
    };
    var tx = t.i(325791);

    function tT(t, e, i) {
        let s = Math.max(e - 5, 0);
        return (0, tx.velocityPerSecond)(i - t(s), e - s)
    }

    function tw({
        keyframes: t,
        velocity: e = 0,
        power: i = .8,
        timeConstant: s = 325,
        bounceDamping: n = 10,
        bounceStiffness: r = 500,
        modifyTarget: o,
        min: a,
        max: l,
        restDelta: h = .5,
        restSpeed: u
    }) {
        let c, d, m = t[0],
            p = {
                done: !1,
                value: m
            },
            f = i * e,
            g = m + f,
            v = void 0 === o ? g : o(g);
        v !== g && (f = v - m);
        let y = t => -f * Math.exp(-t / s),
            x = t => v + y(t),
            T = t => {
                let e = y(t),
                    i = x(t);
                p.done = Math.abs(e) <= h, p.value = p.done ? v : i
            },
            w = t => {
                let e;
                if (e = p.value, void 0 !== a && e < a || void 0 !== l && e > l) {
                    var i;
                    c = t, d = ty({
                        keyframes: [p.value, (i = p.value, void 0 === a ? l : void 0 === l || Math.abs(a - i) < Math.abs(l - i) ? a : l)],
                        velocity: tT(x, t, p.value),
                        damping: n,
                        stiffness: r,
                        restDelta: h,
                        restSpeed: u
                    })
                }
            };
        return w(0), {
            calculatedDuration: null,
            next: t => {
                let e = !1;
                return (d || void 0 !== c || (e = !0, T(t), w(t)), void 0 !== c && t >= c) ? d.next(t - c) : (e || T(t), p)
            }
        }
    }
    let tb = (t, e, i) => (((1 - 3 * i + 3 * e) * t + (3 * i - 6 * e)) * t + 3 * e) * t;

    function tS(t, e, i, s) {
        return t === e && i === s ? F.noop : n => 0 === n || 1 === n ? n : tb(function(t, e, i, s, n) {
            let r, o, a = 0;
            do(r = tb(o = e + (i - e) / 2, s, n) - t) > 0 ? i = o : e = o; while (Math.abs(r) > 1e-7 && ++a < 12) return o
        }(n, 0, 1, t, i), e, s)
    }
    let tP = tS(.42, 0, 1, 1),
        tM = tS(0, 0, .58, 1),
        tA = tS(.42, 0, .58, 1),
        tV = t => e => e <= .5 ? t(2 * e) / 2 : (2 - t(2 * (1 - e))) / 2,
        tE = t => e => 1 - t(1 - e),
        tC = tS(.33, 1.53, .69, .99),
        tD = tE(tC),
        tk = tV(tD),
        tR = t => t >= 1 ? 1 : (t *= 2) < 1 ? .5 * tD(t) : .5 * (2 - Math.pow(2, -10 * (t - 1))),
        tL = t => 1 - Math.sin(Math.acos(t)),
        tB = tE(tL),
        tF = tV(tL);
    t.s(["circIn", 0, tL, "circInOut", 0, tF, "circOut", 0, tB], 791559);
    var tj = t.i(960855);
    let tI = {
            linear: F.noop,
            easeIn: tP,
            easeInOut: tA,
            easeOut: tM,
            circIn: tL,
            circInOut: tF,
            circOut: tB,
            backIn: tD,
            backInOut: tk,
            backOut: tC,
            anticipate: tR
        },
        tO = t => {
            if ((0, tj.isBezierDefinition)(t)) {
                (0, N.invariant)(4 === t.length, "Cubic bezier arrays must contain four numerical values.", "cubic-bezier-length");
                let [e, i, s, n] = t;
                return tS(e, i, s, n)
            }
            return "string" == typeof t ? ((0, N.invariant)(void 0 !== tI[t], `Invalid easing type '${t}'`, "invalid-easing-type"), tI[t]) : t
        },
        tN = (t, e, i) => {
            let s = e - t;
            return s ? (i - t) / s : 1
        };

    function tU(t, e, {
        clamp: i = !0,
        ease: s,
        mixer: n
    } = {}) {
        let r = t.length;
        if ((0, N.invariant)(r === e.length, "Both input and output ranges must be the same length", "range-length"), 1 === r) return () => e[0];
        if (2 === r && e[0] === e[1]) return () => e[1];
        let o = t[0] === t[1];
        t[0] > t[r - 1] && (t = [...t].reverse(), e = [...e].reverse());
        let a = function(t, e, i) {
                let s = [],
                    n = i || D.MotionGlobalConfig.mix || tr,
                    r = t.length - 1;
                for (let i = 0; i < r; i++) {
                    let r = n(t[i], t[i + 1]);
                    e && (r = I(Array.isArray(e) ? e[i] || F.noop : e, r)), s.push(r)
                }
                return s
            }(e, s, n),
            l = a.length,
            h = i => {
                if (o && i < t[0]) return e[0];
                let s = 0;
                if (l > 1)
                    for (; s < t.length - 2 && !(i < t[s + 1]); s++);
                let n = tN(t[s], t[s + 1], i);
                return a[s](n)
            };
        return i ? e => h((0, O.clamp)(t[0], t[r - 1], e)) : h
    }

    function tW({
        duration: t = 300,
        keyframes: e,
        times: i,
        ease: s = "easeInOut"
    }) {
        var n;
        let r, o = Array.isArray(s) && "number" != typeof s[0] ? s.map(tO) : tO(s),
            a = {
                done: !1,
                value: e[0]
            },
            l = tU((n = i && i.length === e.length ? i : (! function(t, e) {
                let i = t[t.length - 1];
                for (let s = 1; s <= e; s++) {
                    let n = tN(0, e, s);
                    t.push((0, X.mixNumber)(i, 1, n))
                }
            }(r = [0], e.length - 1), r), n.map(e => e * t)), e, {
                ease: Array.isArray(o) ? o : e.map(() => o || tA).splice(0, e.length - 1)
            });
        return {
            calculatedDuration: t,
            next: e => (a.value = l(e), a.done = e >= t, a)
        }
    }
    t.s(["progress", 0, tN], 783920), t.s(["interpolate", 0, tU], 344230);
    var t$ = t.i(414229);
    let tG = {
        decay: tw,
        inertia: tw,
        tween: tW,
        keyframes: tW,
        spring: ty
    };

    function tz(t) {
        "string" == typeof t.type && (t.type = tG[t.type])
    }
    var tH = t.i(779294);
    let tK = t => t / 100;
    class tY extends tH.WithPromise {
        constructor(t) {
            super(), this.state = "idle", this.startTime = null, this.isStopped = !1, this.currentTime = 0, this.holdTime = null, this.playbackSpeed = 1, this.delayState = {
                done: !1,
                value: void 0
            }, this.stop = () => {
                let {
                    motionValue: t
                } = this.options;
                t && t.updatedAt !== j.time.now() && this.tick(j.time.now()), this.isStopped = !0, "idle" !== this.state && (this.teardown(), this.options.onStop ? .())
            }, this.options = t, this.initAnimation(), this.play(), !1 === t.autoplay && this.pause()
        }
        initAnimation() {
            let {
                options: t
            } = this;
            tz(t);
            let {
                type: e = tW,
                repeat: i = 0,
                repeatDelay: s = 0,
                repeatType: n,
                velocity: r = 0
            } = t, {
                keyframes: o
            } = t, a = e || tW;
            a !== tW && "number" != typeof o[0] && (this.mixKeyframes = I(tK, tr(o[0], o[1])), o = [0, 100]);
            let l = a({ ...t,
                keyframes: o
            });
            "mirror" === n && (this.mirroredGenerator = a({ ...t,
                keyframes: [...o].reverse(),
                velocity: -r
            })), null === l.calculatedDuration && (l.calculatedDuration = th(l));
            let {
                calculatedDuration: h
            } = l;
            this.calculatedDuration = h, this.resolvedDuration = h + s, this.totalDuration = this.resolvedDuration * (i + 1) - s, this.generator = l
        }
        updateTime(t) {
            let e = Math.round(t - this.startTime) * this.playbackSpeed;
            null !== this.holdTime ? this.currentTime = this.holdTime : this.currentTime = e
        }
        tick(t, e = !1) {
            let i, {
                generator: s,
                totalDuration: n,
                mixKeyframes: r,
                mirroredGenerator: o,
                resolvedDuration: a,
                calculatedDuration: l
            } = this;
            if (null === this.startTime) return s.next(0);
            let {
                delay: h = 0,
                keyframes: u,
                repeat: c,
                repeatType: d,
                repeatDelay: m,
                type: p,
                onUpdate: f,
                finalKeyframe: g
            } = this.options;
            this.speed > 0 ? this.startTime = Math.min(this.startTime, t) : this.speed < 0 && (this.startTime = Math.min(t - n / this.speed, this.startTime)), e ? this.currentTime = t : this.updateTime(t);
            let v = this.currentTime - h * (this.playbackSpeed >= 0 ? 1 : -1),
                y = this.playbackSpeed >= 0 ? v < 0 : v > n;
            this.currentTime = Math.max(v, 0), "finished" === this.state && null === this.holdTime && (this.currentTime = n);
            let x = this.currentTime,
                T = s;
            if (c) {
                let t = Math.min(this.currentTime, n) / a,
                    e = Math.floor(t),
                    i = t % 1;
                !i && t >= 1 && (i = 1), 1 === i && e--, (e = Math.min(e, c + 1)) % 2 && ("reverse" === d ? (i = 1 - i, m && (i -= m / a)) : "mirror" === d && (T = o)), x = (0, O.clamp)(0, 1, i) * a
            }
            y ? (this.delayState.value = u[0], i = this.delayState) : i = T.next(x), r && !y && (i.value = r(i.value));
            let {
                done: w
            } = i;
            y || null === l || (w = this.playbackSpeed >= 0 ? this.currentTime >= n : this.currentTime <= 0);
            let b = null === this.holdTime && ("finished" === this.state || "running" === this.state && w);
            return b && p !== tw && (i.value = (0, t$.getFinalKeyframe)(u, this.options, g, this.speed)), f && f(i.value), b && this.finish(), i
        }
        then(t, e) {
            return this.finished.then(t, e)
        }
        get duration() {
            return (0, B.millisecondsToSeconds)(this.calculatedDuration)
        }
        get iterationDuration() {
            let {
                delay: t = 0
            } = this.options || {};
            return this.duration + (0, B.millisecondsToSeconds)(t)
        }
        get time() {
            return (0, B.millisecondsToSeconds)(this.currentTime)
        }
        set time(t) {
            t = (0, B.secondsToMilliseconds)(t), this.currentTime = t, null === this.startTime || null !== this.holdTime || 0 === this.playbackSpeed ? this.holdTime = t : this.driver && (this.startTime = this.driver.now() - t / this.playbackSpeed), this.driver ? this.driver.start(!1) : (this.startTime = 0, this.state = "paused", this.holdTime = t, this.tick(t))
        }
        getGeneratorVelocity() {
            let t = this.currentTime;
            if (t <= 0) return this.options.velocity || 0;
            if (this.generator.velocity) return this.generator.velocity(t);
            let e = this.generator.next(t).value;
            return tT(t => this.generator.next(t).value, t, e)
        }
        get speed() {
            return this.playbackSpeed
        }
        set speed(t) {
            let e = this.playbackSpeed !== t;
            e && this.driver && this.updateTime(j.time.now()), this.playbackSpeed = t, e && this.driver && (this.time = (0, B.millisecondsToSeconds)(this.currentTime))
        }
        play() {
            if (this.isStopped) return;
            let {
                driver: t = ta,
                startTime: e
            } = this.options;
            this.driver || (this.driver = t(t => this.tick(t))), this.options.onPlay ? .();
            let i = this.driver.now();
            "finished" === this.state ? (this.updateFinished(), this.startTime = i) : null !== this.holdTime ? this.startTime = i - this.holdTime : this.startTime || (this.startTime = e ? ? i), "finished" === this.state && this.speed < 0 && (this.startTime += this.calculatedDuration), this.holdTime = null, this.state = "running", this.driver.start()
        }
        pause() {
            this.state = "paused", this.updateTime(j.time.now()), this.holdTime = this.currentTime
        }
        complete() {
            "running" !== this.state && this.play(), this.state = "finished", this.holdTime = null
        }
        finish() {
            this.notifyFinished(), this.teardown(), this.state = "finished", this.options.onComplete ? .()
        }
        cancel() {
            this.holdTime = null, this.startTime = 0, this.tick(0), this.teardown(), this.options.onCancel ? .()
        }
        teardown() {
            this.state = "idle", this.stopDriver(), this.startTime = this.holdTime = null
        }
        stopDriver() {
            this.driver && (this.driver.stop(), this.driver = void 0)
        }
        sample(t) {
            return this.startTime = 0, this.tick(t, !0)
        }
        attachTimeline(t) {
            return this.options.allowFlatten && (this.options.type = "keyframes", this.options.ease = "linear", this.initAnimation()), this.driver ? .stop(), t.observe(this)
        }
    }
    t.s(["JSAnimation", 0, tY], 83352);
    var tX = t.i(921012),
        tq = t.i(794581),
        t_ = t.i(368e3);
    let tZ = {
        anticipate: tR,
        backInOut: tk,
        circInOut: tF
    };
    class tJ extends t_.NativeAnimation {
        constructor(t) {
            ! function(t) {
                "string" == typeof t.ease && t.ease in tZ && (t.ease = tZ[t.ease])
            }(t), tz(t), super(t), void 0 !== t.startTime && !1 !== t.autoplay && (this.startTime = t.startTime), this.options = t
        }
        updateMotionValue(t) {
            let {
                motionValue: e,
                onUpdate: i,
                onComplete: s,
                element: n,
                ...r
            } = this.options;
            if (!e) return;
            if (void 0 !== t) return void e.set(t);
            let o = new tY({ ...r,
                    autoplay: !1
                }),
                a = Math.max(10, j.time.now() - this.startTime),
                l = (0, O.clamp)(0, 10, a - 10),
                h = o.sample(a).value,
                {
                    name: u
                } = this.options;
            n && u && (0, tq.setStyle)(n, u, h), e.setWithVelocity(o.sample(Math.max(0, a - l)).value, h, l), o.stop()
        }
    }
    var tQ = t.i(997307);
    let t0 = (t, e) => "zIndex" !== e && !!("number" == typeof t || Array.isArray(t) || "string" == typeof t && ($.complex.test(t) || "0" === t) && !t.startsWith("url("));

    function t1(t) {
        t.duration = 0, t.type = "keyframes"
    }
    var t5 = tH,
        t7 = t.i(260900),
        t6 = t.i(962118);
    let t2 = /^(?:oklch|oklab|lab|lch|color|color-mix|light-dark)\(/,
        t9 = new Set(["color", "backgroundColor", "outlineColor", "fill", "stroke", "borderColor", "borderTopColor", "borderRightColor", "borderBottomColor", "borderLeftColor"]),
        t3 = (0, t7.memo)(() => Object.hasOwnProperty.call(Element.prototype, "animate"));
    class t8 extends t5.WithPromise {
        constructor({
            autoplay: t = !0,
            delay: e = 0,
            type: i = "keyframes",
            repeat: s = 0,
            repeatDelay: n = 0,
            repeatType: r = "loop",
            keyframes: o,
            name: a,
            motionValue: l,
            element: h,
            ...u
        }) {
            super(), this.stop = () => {
                this._animation && (this._animation.stop(), this.stopTimeline ? .()), this.keyframeResolver ? .cancel()
            }, this.createdAt = j.time.now();
            const c = {
                    autoplay: t,
                    delay: e,
                    type: i,
                    repeat: s,
                    repeatDelay: n,
                    repeatType: r,
                    name: a,
                    motionValue: l,
                    element: h,
                    ...u
                },
                d = h ? .KeyframeResolver || tX.KeyframeResolver;
            this.keyframeResolver = new d(o, (t, e, i) => this.onKeyframesResolved(t, e, c, !i), a, l, h), this.keyframeResolver ? .scheduleResolve()
        }
        onKeyframesResolved(t, e, i, s) {
            let n;
            this.keyframeResolver = void 0;
            let {
                name: r,
                type: o,
                velocity: a,
                delay: l,
                isHandoff: h,
                onUpdate: u
            } = i;
            this.resolvedAt = j.time.now();
            let c = !0;
            ! function(t, e, i, s) {
                let n = t[0];
                if (null === n) return !1;
                if ("display" === e || "visibility" === e) return !0;
                let r = t[t.length - 1],
                    o = t0(n, e),
                    a = t0(r, e);
                return (0, N.warning)(o === a, `You are trying to animate ${e} from "${n}" to "${r}". "${o?r:n}" is not an animatable value.`, "value-not-animatable"), !!o && !!a && (function(t) {
                    let e = t[0];
                    if (1 === t.length) return !0;
                    for (let i = 0; i < t.length; i++)
                        if (t[i] !== e) return !0
                }(t) || ("spring" === i || (0, tQ.isGenerator)(i)) && s)
            }(t, r, o, a) && (c = !1, (D.MotionGlobalConfig.instantAnimations || !l) && u ? .((0, t$.getFinalKeyframe)(t, i, e)), t[0] = t[t.length - 1], t1(i), i.repeat = 0);
            let d = {
                    startTime: s ? this.resolvedAt && this.resolvedAt - this.createdAt > 40 ? this.resolvedAt : this.createdAt : void 0,
                    finalKeyframe: e,
                    ...i,
                    keyframes: t
                },
                m = c && !h && function(t) {
                    let {
                        motionValue: e,
                        name: i,
                        repeatDelay: s,
                        repeatType: n,
                        damping: r,
                        type: o,
                        keyframes: a
                    } = t;
                    if (!(e ? .owner ? .current instanceof HTMLElement)) return !1;
                    let {
                        onUpdate: l,
                        transformTemplate: h
                    } = e.owner.getProps();
                    return t3() && i && (t6.acceleratedValues.has(i) || t9.has(i) && function(t) {
                        for (let e = 0; e < t.length; e++)
                            if ("string" == typeof t[e] && t2.test(t[e])) return !0;
                        return !1
                    }(a)) && ("transform" !== i || !h) && !l && !s && "mirror" !== n && 0 !== r && "inertia" !== o
                }(d),
                p = d.motionValue ? .owner ? .current;
            if (m) try {
                n = new tJ({ ...d,
                    element: p
                })
            } catch {
                n = new tY(d)
            } else n = new tY(d);
            n.finished.then(() => {
                this.notifyFinished()
            }).catch(F.noop), this.pendingTimeline && (this.stopTimeline = n.attachTimeline(this.pendingTimeline), this.pendingTimeline = void 0), this._animation = n
        }
        get finished() {
            return this._animation ? this.animation.finished : this._finished
        }
        then(t, e) {
            return this.finished.finally(t).then(() => {})
        }
        get animation() {
            return this._animation || (this.keyframeResolver ? .resume(), (0, tX.flushKeyframeResolvers)()), this._animation
        }
        get duration() {
            return this.animation.duration
        }
        get iterationDuration() {
            return this.animation.iterationDuration
        }
        get time() {
            return this.animation.time
        }
        set time(t) {
            this.animation.time = t
        }
        get speed() {
            return this.animation.speed
        }
        get state() {
            return this.animation.state
        }
        set speed(t) {
            this.animation.speed = t
        }
        get startTime() {
            return this.animation.startTime
        }
        attachTimeline(t) {
            return this._animation ? this.stopTimeline = this.animation.attachTimeline(t) : this.pendingTimeline = t, () => this.stop()
        }
        play() {
            this.animation.play()
        }
        pause() {
            this.animation.pause()
        }
        complete() {
            this.animation.complete()
        }
        cancel() {
            this._animation && this.animation.cancel(), this.keyframeResolver ? .cancel()
        }
    }
    var t4 = t.i(157788);
    let et = {
            type: "spring",
            stiffness: 500,
            damping: 25,
            restSpeed: 10
        },
        ee = {
            type: "keyframes",
            duration: .8
        },
        ei = {
            type: "keyframes",
            ease: [.25, .1, .35, 1],
            duration: .3
        },
        es = new Set(["when", "delay", "delayChildren", "staggerChildren", "staggerDirection", "repeat", "repeatType", "repeatDelay", "from", "elapsed"]),
        en = (t, e, i, s = {}, n, r) => o => {
            let a = A(s, t) || {},
                l = a.delay || s.delay || 0,
                {
                    elapsed: h = 0
                } = s;
            h -= (0, B.secondsToMilliseconds)(l);
            let u = {
                keyframes: Array.isArray(i) ? i : [null, i],
                ease: "easeOut",
                velocity: e.getVelocity(),
                ...a,
                delay: -h,
                onUpdate: t => {
                    e.set(t), a.onUpdate && a.onUpdate(t)
                },
                onComplete: () => {
                    o(), a.onComplete && a.onComplete()
                },
                name: t,
                motionValue: e,
                element: r ? void 0 : n
            };
            ! function(t) {
                for (let e in t)
                    if (!es.has(e)) return !0;
                return !1
            }(a) && Object.assign(u, ((t, {
                keyframes: e
            }) => e.length > 2 ? ee : t4.transformProps.has(t) ? t.startsWith("scale") ? {
                type: "spring",
                stiffness: 550,
                damping: 0 === e[1] ? 2 * Math.sqrt(550) : 30,
                restSpeed: 10
            } : et : ei)(t, u)), u.duration && (u.duration = (0, B.secondsToMilliseconds)(u.duration)), u.repeatDelay && (u.repeatDelay = (0, B.secondsToMilliseconds)(u.repeatDelay)), void 0 !== u.from && (u.keyframes[0] = u.from);
            let c = !1;
            if (!1 !== u.type && (0 !== u.duration || u.repeatDelay) || (t1(u), 0 === u.delay && (c = !0)), (D.MotionGlobalConfig.instantAnimations || D.MotionGlobalConfig.skipAnimations || n ? .shouldSkipAnimations || a.skipAnimations) && (c = !0, t1(u), u.delay = 0), u.allowFlatten = !a.type && !a.ease, c && !r && void 0 !== e.get()) {
                let t = (0, t$.getFinalKeyframe)(u.keyframes, a);
                if (void 0 !== t) return void to.frame.update(() => {
                    u.onUpdate(t), u.onComplete()
                })
            }
            return a.isSync ? new tY(u) : new t8(u)
        };

    function er(t, e, {
        delay: i = 0,
        transitionOverride: s,
        type: n
    } = {}) {
        let {
            transition: r,
            transitionEnd: o,
            ...a
        } = e, l = t.getDefaultTransition();
        r = r ? M(r, l) : l;
        let h = r ? .reduceMotion,
            u = r ? .skipAnimations;
        s && (r = s);
        let c = [],
            d = n && t.animationState && t.animationState.getState()[n],
            m = r ? .path;
        for (let e in m && m.animateVisualElement(t, a, r, i, c), a) {
            let s = t.getValue(e, t.latestValues[e] ? ? null),
                n = a[e];
            if (void 0 === n || d && function({
                    protectedKeys: t,
                    needsAnimating: e
                }, i) {
                    let s = t.hasOwnProperty(i) && !0 !== e[i];
                    return e[i] = !1, s
                }(d, e)) continue;
            let o = {
                delay: i,
                ...A(r || {}, e)
            };
            u && (o.skipAnimations = !0);
            let l = s.get();
            if (void 0 !== l && !s.isAnimating() && !Array.isArray(n) && n === l && !o.velocity) {
                to.frame.update(() => s.set(n));
                continue
            }
            let m = !1;
            if (window.MotionHandoffAnimation) {
                let i = L(t);
                if (i) {
                    let t = window.MotionHandoffAnimation(i, e, to.frame);
                    null !== t && (o.startTime = t, m = !0)
                }
            }
            R(t, e);
            let p = h ? ? t.shouldReduceMotion;
            s.start(en(e, s, n, p && V.positionalKeys.has(e) ? {
                type: !1
            } : o, t, m));
            let f = s.animation;
            f && c.push(f)
        }
        if (o) {
            let e = () => to.frame.update(() => {
                o && function(t, e) {
                    let {
                        transitionEnd: i = {},
                        transition: s = {},
                        ...n
                    } = P(t, e) || {};
                    for (let e in n = { ...n,
                            ...i
                        }) {
                        var r;
                        let i = C(r = n[e]) ? r[r.length - 1] || 0 : r;
                        t.hasValue(e) ? t.getValue(e).set(i) : t.addValue(e, (0, E.motionValue)(i))
                    }
                }(t, o)
            });
            c.length ? Promise.all(c).then(e) : e()
        }
        return c
    }

    function eo(t, e, i, s = 0, n = 1) {
        let r = Array.from(t).sort((t, e) => t.sortNodePosition(e)).indexOf(e),
            o = t.size,
            a = (o - 1) * s;
        return "function" == typeof i ? i(r, o) : 1 === n ? r * s : a - r * s
    }

    function ea(t, e, i = {}) {
        let s = P(t, e, "exit" === i.type ? t.presenceContext ? .custom : void 0),
            {
                transition: n = t.getDefaultTransition() || {}
            } = s || {};
        i.transitionOverride && (n = i.transitionOverride);
        let r = s ? () => Promise.all(er(t, s, i)) : () => Promise.resolve(),
            o = t.variantChildren && t.variantChildren.size ? (s = 0) => {
                let {
                    delayChildren: r = 0,
                    staggerChildren: o,
                    staggerDirection: a
                } = n;
                return function(t, e, i = 0, s = 0, n = 0, r = 1, o) {
                    let a = [];
                    for (let l of t.variantChildren) l.notify("AnimationStart", e), a.push(ea(l, e, { ...o,
                        delay: i + ("function" == typeof s ? 0 : s) + eo(t.variantChildren, l, s, n, r)
                    }).then(() => l.notify("AnimationComplete", e)));
                    return Promise.all(a)
                }(t, e, s, r, o, a, i)
            } : () => Promise.resolve(),
            {
                when: a
            } = n;
        if (!a) return Promise.all([r(), o(i.delay)]); {
            let [t, e] = "beforeChildren" === a ? [r, o] : [o, r];
            return t().then(() => e())
        }
    }
    t.s(["animateMotionValue", 0, en], 939011);
    var el = t.i(732525),
        eh = t.i(706840);
    let eu = eh.variantProps.length;
    var ec = t.i(885983);

    function ed(t, e) {
        if (!Array.isArray(e)) return !1;
        let i = e.length;
        if (i !== t.length) return !1;
        for (let s = 0; s < i; s++)
            if (e[s] !== t[s]) return !1;
        return !0
    }
    let em = [...eh.variantPriorityOrder].reverse(),
        ep = eh.variantPriorityOrder.length;

    function ef(t = !1) {
        return {
            isActive: t,
            protectedKeys: {},
            needsAnimating: {},
            prevResolvedValues: {}
        }
    }

    function eg() {
        return {
            animate: ef(!0),
            whileInView: ef(),
            whileHover: ef(),
            whileTap: ef(),
            whileDrag: ef(),
            whileFocus: ef(),
            exit: ef()
        }
    }
    let ev = 0;
    t.s(["animations", 0, {
        animation: {
            Feature: class extends b {
                constructor(t) {
                    super(t), t.animationState || (t.animationState = function(t) {
                        let e = e => Promise.all(e.map(({
                                animation: e,
                                options: i
                            }) => (function(t, e, i = {}) {
                                let s;
                                if (t.notify("AnimationStart", e), Array.isArray(e)) s = Promise.all(e.map(e => ea(t, e, i)));
                                else if ("string" == typeof e) s = ea(t, e, i);
                                else {
                                    let n = "function" == typeof e ? P(t, e, i.custom) : e;
                                    s = Promise.all(er(t, n, i))
                                }
                                return s.then(() => {
                                    t.notify("AnimationComplete", e)
                                })
                            })(t, e, i))),
                            i = eg(),
                            s = !0,
                            n = !1,
                            r = e => (i, s) => {
                                let n = P(t, s, "exit" === e ? t.presenceContext ? .custom : void 0);
                                if (n) {
                                    let {
                                        transition: t,
                                        transitionEnd: e,
                                        ...s
                                    } = n;
                                    i = { ...i,
                                        ...s,
                                        ...e
                                    }
                                }
                                return i
                            };

                        function o(o) {
                            let {
                                props: a
                            } = t, l = function t(e) {
                                if (!e) return;
                                if (!e.isControllingVariants) {
                                    let i = e.parent && t(e.parent) || {};
                                    return void 0 !== e.props.initial && (i.initial = e.props.initial), i
                                }
                                let i = {};
                                for (let t = 0; t < eu; t++) {
                                    let s = eh.variantProps[t],
                                        n = e.props[s];
                                    ((0, el.isVariantLabel)(n) || !1 === n) && (i[s] = n)
                                }
                                return i
                            }(t.parent) || {}, h = [], u = new Set, c = {}, d = 1 / 0;
                            for (let e = 0; e < ep; e++) {
                                var m, p;
                                let f = em[e],
                                    g = i[f],
                                    v = void 0 !== a[f] ? a[f] : l[f],
                                    y = (0, el.isVariantLabel)(v),
                                    x = f === o ? g.isActive : null;
                                !1 === x && (d = e);
                                let T = v === l[f] && v !== a[f] && y;
                                if (T && (s || n) && t.manuallyAnimateOnMount && (T = !1), g.protectedKeys = { ...c
                                    }, !g.isActive && null === x || !v && !g.prevProp || (0, ec.isAnimationControls)(v) || "boolean" == typeof v) continue;
                                if ("exit" === f && g.isActive && !0 !== x) {
                                    g.prevResolvedValues && (c = { ...c,
                                        ...g.prevResolvedValues
                                    });
                                    continue
                                }
                                let w = (m = g.prevProp, "string" == typeof(p = v) ? p !== m : !!Array.isArray(p) && !ed(p, m)),
                                    b = w || f === o && g.isActive && !T && y || e > d && y,
                                    S = !1,
                                    M = Array.isArray(v) ? v : [v],
                                    A = M.reduce(r(f), {});
                                !1 === x && (A = {});
                                let {
                                    prevResolvedValues: V = {}
                                } = g, E = { ...V,
                                    ...A
                                }, D = e => {
                                    b = !0, u.has(e) && (S = !0, u.delete(e)), g.needsAnimating[e] = !0;
                                    let i = t.getValue(e);
                                    i && (i.liveStyle = !1)
                                };
                                for (let t in E) {
                                    let e = A[t],
                                        i = V[t];
                                    if (!c.hasOwnProperty(t))(C(e) && C(i) ? !ed(e, i) || w : e !== i) ? null != e ? D(t) : u.add(t) : void 0 !== e && u.has(t) ? D(t) : g.protectedKeys[t] = !0
                                }
                                g.prevProp = v, g.prevResolvedValues = A, g.isActive && (c = { ...c,
                                    ...A
                                }), (s || n) && t.blockInitialAnimation && (b = !1);
                                let k = T && w,
                                    R = !k || S;
                                b && R && h.push(...M.map(e => {
                                    let i = {
                                        type: f
                                    };
                                    if ("string" == typeof e && (s || n) && !k && t.manuallyAnimateOnMount && t.parent) {
                                        let {
                                            parent: s
                                        } = t, n = P(s, e);
                                        if (s.enteringChildren && n) {
                                            let {
                                                delayChildren: e
                                            } = n.transition || {};
                                            i.delay = eo(s.enteringChildren, t, e)
                                        }
                                    }
                                    return {
                                        animation: e,
                                        options: i
                                    }
                                }))
                            }
                            if (u.size) {
                                let e = {};
                                if ("boolean" != typeof a.initial) {
                                    let i = P(t, Array.isArray(a.initial) ? a.initial[0] : a.initial);
                                    i && i.transition && (e.transition = i.transition)
                                }
                                u.forEach(i => {
                                    let s = t.getBaseTarget(i),
                                        n = t.getValue(i);
                                    n && (n.liveStyle = !0), e[i] = s ? ? null
                                }), h.push({
                                    animation: e
                                })
                            }
                            let f = !!h.length;
                            return s && (!1 === a.initial || a.initial === a.animate) && !t.manuallyAnimateOnMount && (f = !1), s = !1, n = !1, f ? e(h) : Promise.resolve()
                        }
                        return {
                            animateChanges: o,
                            setActive: function(e, s) {
                                if (i[e].isActive === s) return Promise.resolve();
                                t.variantChildren ? .forEach(t => t.animationState ? .setActive(e, s)), i[e].isActive = s;
                                let n = o(e);
                                for (let t in i) i[t].protectedKeys = {};
                                return n
                            },
                            setAnimateFunction: function(i) {
                                e = i(t)
                            },
                            getState: () => i,
                            reset: () => {
                                i = eg(), n = !0
                            }
                        }
                    }(t))
                }
                updateAnimationControlsSubscription() {
                    let {
                        animate: t
                    } = this.node.getProps();
                    (0, ec.isAnimationControls)(t) && (this.unmountControls = t.subscribe(this.node))
                }
                mount() {
                    this.updateAnimationControlsSubscription()
                }
                update() {
                    let {
                        animate: t
                    } = this.node.getProps(), {
                        animate: e
                    } = this.node.prevProps || {};
                    t !== e && this.updateAnimationControlsSubscription()
                }
                unmount() {
                    this.node.animationState.reset(), this.unmountControls ? .()
                }
            }
        },
        exit: {
            Feature: class extends b {
                constructor() {
                    super(...arguments), this.id = ev++, this.isExitComplete = !1
                }
                update() {
                    if (!this.node.presenceContext) return;
                    let {
                        isPresent: t,
                        onExitComplete: e
                    } = this.node.presenceContext, {
                        isPresent: i
                    } = this.node.prevPresenceContext || {};
                    if (!this.node.animationState || t === i) return;
                    if (t && !1 === i) {
                        if (this.isExitComplete) {
                            let {
                                initial: t,
                                custom: e
                            } = this.node.getProps();
                            if ("string" == typeof t || "object" == typeof t && null !== t && !Array.isArray(t)) {
                                let i = P(this.node, t, e);
                                if (i) {
                                    let {
                                        transition: t,
                                        transitionEnd: e,
                                        ...s
                                    } = i;
                                    for (let t in s) this.node.getValue(t) ? .jump(s[t])
                                }
                            }
                            this.node.animationState.reset(), this.node.animationState.animateChanges()
                        } else this.node.animationState.setActive("exit", !1);
                        this.isExitComplete = !1;
                        return
                    }
                    let s = this.node.animationState.setActive("exit", !t);
                    e && !t && s.then(() => {
                        this.isExitComplete = !0, e(this.id)
                    })
                }
                mount() {
                    let {
                        register: t,
                        onExitComplete: e
                    } = this.node.presenceContext || {};
                    e && e(this.id), t && (this.unmount = t(this.id))
                }
                unmount() {}
            }
        }
    }], 223070), t.s(["eachAxis", 0, function(t) {
        return [t("x"), t("y")]
    }], 655559), t.s(["addDomEvent", 0, function(t, e, i, s = {
        passive: !0
    }) {
        return t.addEventListener(e, i, s), () => t.removeEventListener(e, i, s)
    }], 282774);
    let ey = {
        x: !1,
        y: !1
    };
    t.s(["isDragActive", 0, function() {
        return ey.x || ey.y
    }, "isDragging", 0, ey], 439676), t.s(["setDragLock", 0, function(t) {
        if ("x" === t || "y" === t)
            if (ey[t]) return null;
            else return ey[t] = !0, () => {
                ey[t] = !1
            };
        return ey.x || ey.y ? null : (ey.x = ey.y = !0, () => {
            ey.x = ey.y = !1
        })
    }], 137541);

    function ex(t) {
        return t.max - t.min
    }

    function eT(t, e, i, s = .5) {
        t.origin = s, t.originPoint = (0, X.mixNumber)(e.min, e.max, t.origin), t.scale = ex(i) / ex(e), t.translate = (0, X.mixNumber)(i.min, i.max, t.origin) - t.originPoint, (t.scale >= .9999 && t.scale <= 1.0001 || isNaN(t.scale)) && (t.scale = 1), (t.translate >= -.01 && t.translate <= .01 || isNaN(t.translate)) && (t.translate = 0)
    }

    function ew(t, e, i, s = 0) {
        t.min = (s ? (0, X.mixNumber)(i.min, i.max, s) : i.min) + e.min, t.max = t.min + ex(e)
    }

    function eb(t, e, i, s = 0) {
        let n = s ? (0, X.mixNumber)(i.min, i.max, s) : i.min;
        t.min = e.min - n, t.max = t.min + ex(e)
    }
    t.s(["calcBoxDelta", 0, function(t, e, i, s) {
        eT(t.x, e.x, i.x, s ? s.originX : void 0), eT(t.y, e.y, i.y, s ? s.originY : void 0)
    }, "calcLength", 0, ex, "calcRelativeBox", 0, function(t, e, i, s) {
        ew(t.x, e.x, i.x, s ? .x), ew(t.y, e.y, i.y, s ? .y)
    }, "calcRelativePosition", 0, function(t, e, i, s) {
        eb(t.x, e.x, i.x, s ? .x), eb(t.y, e.y, i.y, s ? .y)
    }, "isNear", 0, function(t, e, i) {
        return Math.abs(t - e) <= i
    }], 652101)
}, 642824, t => {
    "use strict";
    t.s(["isObject", 0, t => "object" == typeof t && null !== t])
}, 733986, 889026, 749652, 919880, 341327, 665536, 485651, 107230, t => {
    "use strict";
    let e, i;
    var s = t.i(142098),
        n = t.i(260830),
        r = t.i(130162),
        o = t.i(287022),
        a = t.i(655559),
        l = t.i(153689),
        h = t.i(27677),
        u = t.i(980538),
        c = t.i(939011),
        d = t.i(100706),
        m = t.i(282774),
        p = t.i(137541),
        f = t.i(265091),
        g = t.i(652101),
        v = t.i(642824);

    function y(t) {
        return (0, v.isObject)(t) && "ownerSVGElement" in t
    }

    function x(t, e, i) {
        if (null == t) return [];
        if (t instanceof EventTarget) return [t];
        if ("string" == typeof t) {
            let s = document;
            e && (s = e.current);
            let n = i ? .[t] ? ? s.querySelectorAll(t);
            return n ? Array.from(n) : []
        }
        return Array.from(t).filter(t => null != t)
    }
    t.s(["isSVGElement", 0, y], 889026), t.s(["resolveElements", 0, x], 749652);
    let T = new WeakMap,
        w = (t, e, i) => (s, n) => n && n[0] ? n[0][t + "Size"] : y(s) && "getBBox" in s ? s.getBBox()[e] : s[i],
        b = w("inline", "width", "offsetWidth"),
        S = w("block", "height", "offsetHeight");

    function P({
        target: t,
        borderBoxSize: e
    }) {
        T.get(t) ? .forEach(i => {
            i(t, {
                get width() {
                    return b(t, e)
                },
                get height() {
                    return S(t, e)
                }
            })
        })
    }

    function M(t) {
        t.forEach(P)
    }
    let A = new Set;

    function V(t, s) {
        let n;
        return "function" == typeof t ? (A.add(t), i || (i = () => {
            let t = {
                get width() {
                    return window.innerWidth
                },
                get height() {
                    return window.innerHeight
                }
            };
            A.forEach(e => e(t))
        }, window.addEventListener("resize", i)), () => {
            A.delete(t), A.size || "function" != typeof i || (window.removeEventListener("resize", i), i = void 0)
        }) : (!e && "u" > typeof ResizeObserver && (e = new ResizeObserver(M)), (n = x(t)).forEach(t => {
            let i = T.get(t);
            i || (i = new Set, T.set(t, i)), i.add(s), e ? .observe(t)
        }), () => {
            n.forEach(t => {
                let i = T.get(t);
                i ? .delete(s), i ? .size || e ? .unobserve(t)
            })
        })
    }
    let E = new Set(["BUTTON", "INPUT", "SELECT", "TEXTAREA", "A"]),
        C = new Set(["INPUT", "SELECT", "TEXTAREA"]);

    function D(t) {
        return C.has(t.tagName) || !0 === t.isContentEditable
    }
    t.s(["isElementKeyboardAccessible", 0, function(t) {
        return E.has(t.tagName) || !0 === t.isContentEditable
    }, "isElementTextInput", 0, D], 919880);
    var k = t.i(965566);
    let R = t => "mouse" === t.pointerType ? "number" != typeof t.button || t.button <= 0 : !1 !== t.isPrimary;

    function L(t) {
        return {
            point: {
                x: t.pageX,
                y: t.pageY
            }
        }
    }
    t.s(["isPrimaryPointer", 0, R], 341327);
    let B = t => e => R(e) && t(e, L(e));

    function F(t, e, i, s) {
        return (0, m.addDomEvent)(t, e, B(i), s)
    }
    t.s(["addPointerInfo", 0, B, "extractEventInfo", 0, L], 665536);
    let j = ({
        current: t
    }) => t ? t.ownerDocument.defaultView : null;
    var I = t.i(325522),
        O = t.i(738638),
        N = t.i(763074);
    let U = (t, e) => Math.abs(t - e),
        W = new Set(["auto", "scroll"]);
    class $ {
        constructor(t, e, {
            transformPagePoint: i,
            contextWindow: s = window,
            dragSnapToOrigin: n = !1,
            distanceThreshold: r = 3,
            element: a
        } = {}) {
            if (this.startEvent = null, this.lastMoveEvent = null, this.lastMoveEventInfo = null, this.lastRawMoveEventInfo = null, this.handlers = {}, this.contextWindow = window, this.scrollPositions = new Map, this.removeScrollListeners = null, this.onElementScroll = t => {
                    this.handleScroll(t.target)
                }, this.onWindowScroll = () => {
                    this.handleScroll(window)
                }, this.updatePoint = () => {
                    var t, e;
                    if (!(this.lastMoveEvent && this.lastMoveEventInfo)) return;
                    this.lastRawMoveEventInfo && (this.lastMoveEventInfo = G(this.lastRawMoveEventInfo, this.transformPagePoint));
                    let i = H(this.lastMoveEventInfo, this.history),
                        s = null !== this.startEvent,
                        n = (t = i.offset, e = {
                            x: 0,
                            y: 0
                        }, Math.sqrt(U(t.x, e.x) ** 2 + U(t.y, e.y) ** 2) >= this.distanceThreshold);
                    if (!s && !n) return;
                    let {
                        point: r
                    } = i, {
                        timestamp: a
                    } = o.frameData;
                    this.history.push({ ...r,
                        timestamp: a
                    });
                    let {
                        onStart: l,
                        onMove: h
                    } = this.handlers;
                    s || (l && l(this.lastMoveEvent, i), this.startEvent = this.lastMoveEvent), h && h(this.lastMoveEvent, i)
                }, this.handlePointerMove = (t, e) => {
                    this.lastMoveEvent = t, this.lastRawMoveEventInfo = e, this.lastMoveEventInfo = G(e, this.transformPagePoint), o.frame.update(this.updatePoint, !0)
                }, this.handlePointerUp = (t, e) => {
                    this.end();
                    let {
                        onEnd: i,
                        onSessionEnd: s,
                        resumeAnimation: n
                    } = this.handlers;
                    if ((this.dragSnapToOrigin || !this.startEvent) && n && n(), !(this.lastMoveEvent && this.lastMoveEventInfo)) return;
                    let r = H("pointercancel" === t.type ? this.lastMoveEventInfo : G(e, this.transformPagePoint), this.history);
                    this.startEvent && i && i(t, r), s && s(t, r)
                }, !R(t)) return;
            this.dragSnapToOrigin = n, this.handlers = e, this.transformPagePoint = i, this.distanceThreshold = r, this.contextWindow = s || window;
            const l = G(L(t), this.transformPagePoint),
                {
                    point: h
                } = l,
                {
                    timestamp: u
                } = o.frameData;
            this.history = [{ ...h,
                timestamp: u
            }];
            const {
                onSessionStart: c
            } = e;
            c && c(t, H(l, this.history));
            const d = {
                passive: !0,
                capture: !0
            };
            this.removeListeners = (0, O.pipe)(F(this.contextWindow, "pointermove", this.handlePointerMove, d), F(this.contextWindow, "pointerup", this.handlePointerUp, d), F(this.contextWindow, "pointercancel", this.handlePointerUp, d)), a && this.startScrollTracking(a)
        }
        startScrollTracking(t) {
            let e = t.parentElement;
            for (; e;) {
                let t = getComputedStyle(e);
                (W.has(t.overflowX) || W.has(t.overflowY)) && this.scrollPositions.set(e, {
                    x: e.scrollLeft,
                    y: e.scrollTop
                }), e = e.parentElement
            }
            this.scrollPositions.set(window, {
                x: window.scrollX,
                y: window.scrollY
            }), window.addEventListener("scroll", this.onElementScroll, {
                capture: !0
            }), window.addEventListener("scroll", this.onWindowScroll), this.removeScrollListeners = () => {
                window.removeEventListener("scroll", this.onElementScroll, {
                    capture: !0
                }), window.removeEventListener("scroll", this.onWindowScroll)
            }
        }
        handleScroll(t) {
            let e = this.scrollPositions.get(t);
            if (!e) return;
            let i = t === window,
                s = i ? {
                    x: window.scrollX,
                    y: window.scrollY
                } : {
                    x: t.scrollLeft,
                    y: t.scrollTop
                },
                n = {
                    x: s.x - e.x,
                    y: s.y - e.y
                };
            (0 !== n.x || 0 !== n.y) && (i ? this.lastMoveEventInfo && (this.lastMoveEventInfo.point.x += n.x, this.lastMoveEventInfo.point.y += n.y) : this.history.length > 0 && (this.history[0].x -= n.x, this.history[0].y -= n.y), this.scrollPositions.set(t, s), o.frame.update(this.updatePoint, !0))
        }
        updateHandlers(t) {
            this.handlers = t
        }
        end() {
            this.removeListeners && this.removeListeners(), this.removeScrollListeners && this.removeScrollListeners(), this.scrollPositions.clear(), (0, o.cancelFrame)(this.updatePoint)
        }
    }

    function G(t, e) {
        return e ? {
            point: e(t.point)
        } : t
    }

    function z(t, e) {
        return {
            x: t.x - e.x,
            y: t.y - e.y
        }
    }

    function H({
        point: t
    }, e) {
        return {
            point: t,
            delta: z(t, K(e)),
            offset: z(t, e[0]),
            velocity: function(t) {
                if (t.length < 2) return {
                    x: 0,
                    y: 0
                };
                let e = t.length - 1,
                    i = null,
                    s = K(t);
                for (; e >= 0 && (i = t[e], !(s.timestamp - i.timestamp > (0, N.secondsToMilliseconds)(.1)));) e--;
                if (!i) return {
                    x: 0,
                    y: 0
                };
                i === t[0] && t.length > 2 && s.timestamp - i.timestamp > 2 * (0, N.secondsToMilliseconds)(.1) && (i = t[1]);
                let n = (0, N.millisecondsToSeconds)(s.timestamp - i.timestamp);
                if (0 === n) return {
                    x: 0,
                    y: 0
                };
                let r = {
                    x: (s.x - i.x) / n,
                    y: (s.y - i.y) / n
                };
                return r.x === 1 / 0 && (r.x = 0), r.y === 1 / 0 && (r.y = 0), r
            }(e)
        }
    }

    function K(t) {
        return t[t.length - 1]
    }
    var Y = t.i(783920),
        X = t.i(476959);

    function q(t, e, i) {
        return {
            min: void 0 !== e ? t.min + e : void 0,
            max: void 0 !== i ? t.max + i - (t.max - t.min) : void 0
        }
    }

    function _(t, e) {
        let i = e.min - t.min,
            s = e.max - t.max;
        return e.max - e.min < t.max - t.min && ([i, s] = [s, i]), {
            min: i,
            max: s
        }
    }

    function Z(t, e, i) {
        return {
            min: J(t, e),
            max: J(t, i)
        }
    }

    function J(t, e) {
        return "number" == typeof t ? t : t[e] || 0
    }
    let Q = new WeakMap;
    class tt {
        constructor(t) {
            this.openDragLock = null, this.isDragging = !1, this.currentDirection = null, this.originPoint = {
                x: 0,
                y: 0
            }, this.constraints = !1, this.hasMutatedConstraints = !1, this.elastic = (0, r.createBox)(), this.latestPointerEvent = null, this.latestPanInfo = null, this.visualElement = t
        }
        start(t, {
            snapToCursor: e = !1,
            distanceThreshold: i
        } = {}) {
            let {
                presenceContext: s
            } = this.visualElement;
            if (s && !1 === s.isPresent) return;
            let n = t => {
                    e && this.snapToCursor(L(t).point), this.stopAnimation()
                },
                r = (t, e) => {
                    let {
                        drag: i,
                        dragPropagation: s,
                        onDragStart: n
                    } = this.getProps();
                    if (i && !s && (this.openDragLock && this.openDragLock(), this.openDragLock = (0, p.setDragLock)(i), !this.openDragLock)) return;
                    this.latestPointerEvent = t, this.latestPanInfo = e, this.isDragging = !0, this.currentDirection = null, this.resolveConstraints(), this.visualElement.projection && (this.visualElement.projection.isAnimationBlocked = !0, this.visualElement.projection.target = void 0), (0, a.eachAxis)(t => {
                        let e = this.getAxisMotionValue(t).get() || 0;
                        if (f.percent.test(e)) {
                            let {
                                projection: i
                            } = this.visualElement;
                            if (i && i.layout) {
                                let s = i.layout.layoutBox[t];
                                s && (e = (0, g.calcLength)(s) * (parseFloat(e) / 100))
                            }
                        }
                        this.originPoint[t] = e
                    }), n && o.frame.update(() => n(t, e), !1, !0), (0, u.addValueToWillChange)(this.visualElement, "transform");
                    let {
                        animationState: r
                    } = this.visualElement;
                    r && r.setActive("whileDrag", !0)
                },
                l = (t, e) => {
                    this.latestPointerEvent = t, this.latestPanInfo = e;
                    let {
                        dragPropagation: i,
                        dragDirectionLock: s,
                        onDirectionLock: n,
                        onDrag: r
                    } = this.getProps();
                    if (!i && !this.openDragLock) return;
                    let {
                        offset: a
                    } = e;
                    if (s && null === this.currentDirection) {
                        this.currentDirection = function(t, e = 10) {
                            let i = null;
                            return Math.abs(t.y) > e ? i = "y" : Math.abs(t.x) > e && (i = "x"), i
                        }(a), null !== this.currentDirection && n && n(this.currentDirection);
                        return
                    }
                    this.updateAxis("x", e.point, a), this.updateAxis("y", e.point, a), this.visualElement.render(), r && o.frame.update(() => r(t, e), !1, !0)
                },
                h = (t, e) => {
                    this.latestPointerEvent = t, this.latestPanInfo = e, this.stop(t, e), this.latestPointerEvent = null, this.latestPanInfo = null
                },
                c = () => {
                    let {
                        dragSnapToOrigin: t
                    } = this.getProps();
                    (t || this.constraints) && this.startAnimation({
                        x: 0,
                        y: 0
                    })
                },
                {
                    dragSnapToOrigin: d
                } = this.getProps();
            this.panSession = new $(t, {
                onSessionStart: n,
                onStart: r,
                onMove: l,
                onSessionEnd: h,
                resumeAnimation: c
            }, {
                transformPagePoint: this.visualElement.getTransformPagePoint(),
                dragSnapToOrigin: d,
                distanceThreshold: i,
                contextWindow: j(this.visualElement),
                element: this.visualElement.current
            })
        }
        stop(t, e) {
            let i = t || this.latestPointerEvent,
                s = e || this.latestPanInfo,
                n = this.isDragging;
            if (this.cancel(), !n || !s || !i) return;
            let {
                velocity: r
            } = s;
            this.startAnimation(r);
            let {
                onDragEnd: a
            } = this.getProps();
            a && o.frame.postRender(() => a(i, s))
        }
        cancel() {
            this.isDragging = !1;
            let {
                projection: t,
                animationState: e
            } = this.visualElement;
            t && (t.isAnimationBlocked = !1), this.endPanSession();
            let {
                dragPropagation: i
            } = this.getProps();
            !i && this.openDragLock && (this.openDragLock(), this.openDragLock = null), e && e.setActive("whileDrag", !1)
        }
        endPanSession() {
            this.panSession && this.panSession.end(), this.panSession = void 0
        }
        updateAxis(t, e, i) {
            let {
                drag: s
            } = this.getProps();
            if (!i || !ti(t, s, this.currentDirection)) return;
            let n = this.getAxisMotionValue(t),
                r = this.originPoint[t] + i[t];
            this.constraints && this.constraints[t] && (r = function(t, {
                min: e,
                max: i
            }, s) {
                return void 0 !== e && t < e ? t = s ? (0, d.mixNumber)(e, t, s.min) : Math.max(t, e) : void 0 !== i && t > i && (t = s ? (0, d.mixNumber)(i, t, s.max) : Math.min(t, i)), t
            }(r, this.constraints[t], this.elastic[t])), n.set(r)
        }
        resolveConstraints() {
            let {
                dragConstraints: t,
                dragElastic: e
            } = this.getProps(), i = this.visualElement.projection && !this.visualElement.projection.layout ? this.visualElement.projection.measure(!1) : this.visualElement.projection ? .layout, s = this.constraints;
            t && (0, I.isRefObject)(t) ? this.constraints || (this.constraints = this.resolveRefConstraints()) : t && i ? this.constraints = function(t, {
                top: e,
                left: i,
                bottom: s,
                right: n
            }) {
                return {
                    x: q(t.x, i, n),
                    y: q(t.y, e, s)
                }
            }(i.layoutBox, t) : this.constraints = !1, this.elastic = function(t = .35) {
                return !1 === t ? t = 0 : !0 === t && (t = .35), {
                    x: Z(t, "left", "right"),
                    y: Z(t, "top", "bottom")
                }
            }(e), s !== this.constraints && !(0, I.isRefObject)(t) && i && this.constraints && !this.hasMutatedConstraints && (0, a.eachAxis)(t => {
                var e, s;
                let n;
                !1 !== this.constraints && this.getAxisMotionValue(t) && (this.constraints[t] = (e = i.layoutBox[t], s = this.constraints[t], n = {}, void 0 !== s.min && (n.min = s.min - e.min), void 0 !== s.max && (n.max = s.max - e.min), n))
            })
        }
        resolveRefConstraints() {
            var t;
            let {
                dragConstraints: e,
                onMeasureDragConstraints: i
            } = this.getProps();
            if (!e || !(0, I.isRefObject)(e)) return !1;
            let s = e.current;
            (0, k.invariant)(null !== s, "If `dragConstraints` is set as a React ref, that ref must be passed to another component's `ref` prop.", "drag-constraints-ref");
            let {
                projection: n
            } = this.visualElement;
            if (!n || !n.layout) return !1;
            n.root && (n.root.scroll = void 0, n.root.updateScroll());
            let r = (0, l.measurePageBox)(s, n.root, this.visualElement.getTransformPagePoint()),
                o = (t = n.layout.layoutBox, {
                    x: _(t.x, r.x),
                    y: _(t.y, r.y)
                });
            if (i) {
                let t = i((0, h.convertBoxToBoundingBox)(o));
                this.hasMutatedConstraints = !!t, t && (o = (0, h.convertBoundingBoxToBox)(t))
            }
            return o
        }
        startAnimation(t) {
            let {
                drag: e,
                dragMomentum: i,
                dragElastic: s,
                dragTransition: n,
                dragSnapToOrigin: r,
                onDragTransitionEnd: o
            } = this.getProps(), l = this.constraints || {};
            return Promise.all((0, a.eachAxis)(o => {
                if (!ti(o, e, this.currentDirection)) return;
                let a = l && l[o] || {};
                (!0 === r || r === o) && (a = {
                    min: 0,
                    max: 0
                });
                let h = {
                    type: "inertia",
                    velocity: i ? t[o] : 0,
                    bounceStiffness: s ? 200 : 1e6,
                    bounceDamping: s ? 40 : 1e7,
                    timeConstant: 750,
                    restDelta: 1,
                    restSpeed: 10,
                    ...n,
                    ...a
                };
                return this.startAxisValueAnimation(o, h)
            })).then(o)
        }
        startAxisValueAnimation(t, e) {
            let i = this.getAxisMotionValue(t);
            return (0, u.addValueToWillChange)(this.visualElement, t), i.start((0, c.animateMotionValue)(t, i, 0, e, this.visualElement, !1))
        }
        stopAnimation() {
            (0, a.eachAxis)(t => this.getAxisMotionValue(t).stop())
        }
        getAxisMotionValue(t) {
            let e = `_drag${t.toUpperCase()}`;
            return this.visualElement.getProps()[e] || this.visualElement.getValue(t, this.visualElement.latestValues[t] ? ? 0)
        }
        snapToCursor(t) {
            (0, a.eachAxis)(e => {
                let {
                    drag: i
                } = this.getProps();
                if (!ti(e, i, this.currentDirection)) return;
                let {
                    projection: s
                } = this.visualElement, n = this.getAxisMotionValue(e);
                if (s && s.layout) {
                    let {
                        min: i,
                        max: r
                    } = s.layout.layoutBox[e], o = n.get() || 0;
                    n.set(t[e] - (0, d.mixNumber)(i, r, .5) + o)
                }
            })
        }
        scalePositionWithinConstraints() {
            if (!this.visualElement.current) return;
            let {
                drag: t,
                dragConstraints: e
            } = this.getProps(), {
                projection: i
            } = this.visualElement;
            if (!(0, I.isRefObject)(e) || !i || !this.constraints) return;
            this.stopAnimation();
            let s = {
                x: 0,
                y: 0
            };
            (0, a.eachAxis)(t => {
                let e = this.getAxisMotionValue(t);
                if (e && !1 !== this.constraints) {
                    var i, n;
                    let r, o, a, l = e.get();
                    s[t] = (i = {
                        min: l,
                        max: l
                    }, n = this.constraints[t], r = .5, o = (0, g.calcLength)(i), (a = (0, g.calcLength)(n)) > o ? r = (0, Y.progress)(n.min, n.max - o, i.min) : o > a && (r = (0, Y.progress)(i.min, i.max - a, n.min)), (0, X.clamp)(0, 1, r))
                }
            });
            let {
                transformTemplate: n
            } = this.visualElement.getProps();
            this.visualElement.current.style.transform = n ? n({}, "") : "none", i.root && i.root.updateScroll(), i.updateLayout(), this.constraints = !1, this.resolveConstraints(), (0, a.eachAxis)(e => {
                if (!ti(e, t, null)) return;
                let i = this.getAxisMotionValue(e),
                    {
                        min: n,
                        max: r
                    } = this.constraints[e];
                i.set((0, d.mixNumber)(n, r, s[e]))
            }), this.visualElement.render()
        }
        addListeners() {
            let t;
            if (!this.visualElement.current) return;
            Q.set(this.visualElement, this);
            let e = this.visualElement.current,
                i = F(e, "pointerdown", t => {
                    let {
                        drag: i,
                        dragListener: s = !0
                    } = this.getProps(), n = t.target, r = n !== e && D(n);
                    i && s && !r && this.start(t)
                }),
                s = () => {
                    var i, s, n;
                    let r, o, {
                        dragConstraints: a
                    } = this.getProps();
                    (0, I.isRefObject)(a) && a.current && (this.constraints = this.resolveRefConstraints(), t || (i = e, s = a.current, r = V(i, te(n = () => this.scalePositionWithinConstraints())), o = V(s, te(n)), t = () => {
                        r(), o()
                    }))
                },
                {
                    projection: n
                } = this.visualElement,
                r = n.addEventListener("measure", s);
            n && !n.layout && (n.root && n.root.updateScroll(), n.updateLayout()), o.frame.read(s);
            let l = (0, m.addDomEvent)(window, "resize", () => this.scalePositionWithinConstraints()),
                h = n.addEventListener("didUpdate", ({
                    delta: t,
                    hasLayoutChanged: e
                }) => {
                    this.isDragging && e && ((0, a.eachAxis)(e => {
                        let i = this.getAxisMotionValue(e);
                        i && (this.originPoint[e] += t[e].translate, i.set(i.get() + t[e].translate))
                    }), this.visualElement.render())
                });
            return () => {
                l(), i(), r(), h && h(), t && t()
            }
        }
        getProps() {
            let t = this.visualElement.getProps(),
                {
                    drag: e = !1,
                    dragDirectionLock: i = !1,
                    dragPropagation: s = !1,
                    dragConstraints: n = !1,
                    dragElastic: r = .35,
                    dragMomentum: o = !0
                } = t;
            return { ...t,
                drag: e,
                dragDirectionLock: i,
                dragPropagation: s,
                dragConstraints: n,
                dragElastic: r,
                dragMomentum: o
            }
        }
    }

    function te(t) {
        let e = !0;
        return () => {
            if (e) {
                e = !1;
                return
            }
            t()
        }
    }

    function ti(t, e, i) {
        return (!0 === e || e === t) && (null === i || i === t)
    }
    class ts extends s.Feature {
        constructor(t) {
            super(t), this.removeGroupControls = n.noop, this.removeListeners = n.noop, this.controls = new tt(t)
        }
        mount() {
            let {
                dragControls: t
            } = this.node.getProps();
            t && (this.removeGroupControls = t.subscribe(this.controls)), this.removeListeners = this.controls.addListeners() || n.noop
        }
        update() {
            let {
                dragControls: t
            } = this.node.getProps(), {
                dragControls: e
            } = this.node.prevProps || {};
            t !== e && (this.removeGroupControls(), t && (this.removeGroupControls = t.subscribe(this.controls)))
        }
        unmount() {
            this.removeGroupControls(), this.removeListeners(), this.controls.isDragging || this.controls.endPanSession()
        }
    }
    t.s(["DragGesture", 0, ts], 733986);
    var tn = s;
    let tr = t => (e, i) => {
        t && o.frame.update(() => t(e, i), !1, !0)
    };
    class to extends tn.Feature {
        constructor() {
            super(...arguments), this.removePointerDownListener = n.noop
        }
        onPointerDown(t) {
            this.session = new $(t, this.createPanHandlers(), {
                transformPagePoint: this.node.getTransformPagePoint(),
                contextWindow: j(this.node)
            })
        }
        createPanHandlers() {
            let {
                onPanSessionStart: t,
                onPanStart: e,
                onPan: i,
                onPanEnd: s
            } = this.node.getProps();
            return {
                onSessionStart: tr(t),
                onStart: tr(e),
                onMove: tr(i),
                onEnd: (t, e) => {
                    delete this.session, s && o.frame.postRender(() => s(t, e))
                }
            }
        }
        mount() {
            this.removePointerDownListener = F(this.node.current, "pointerdown", t => this.onPointerDown(t))
        }
        update() {
            this.session && this.session.updateHandlers(this.createPanHandlers())
        }
        unmount() {
            this.removePointerDownListener(), this.session && this.session.end()
        }
    }
    t.s(["PanGesture", 0, to], 485651), t.s(["globalProjectionState", 0, {
        hasAnimatedSinceResize: !0,
        hasEverUpdated: !1
    }], 107230)
}, 464978, t => {
    "use strict";
    var e = t.i(271645),
        i = t.i(821476);
    t.s(["usePresence", 0, function(t = !0) {
        let s = (0, e.useContext)(i.PresenceContext);
        if (null === s) return [!0, null];
        let {
            isPresent: n,
            onExitComplete: r,
            register: o
        } = s, a = (0, e.useId)();
        (0, e.useEffect)(() => {
            if (t) return o(a)
        }, [t]);
        let l = (0, e.useCallback)(() => t && r && r(a), [a, r, t]);
        return !n && r ? [!1, l] : [!0]
    }])
}, 646816, 877397, 717871, 973089, 957512, 99642, t => {
    "use strict";
    var e = t.i(733986),
        i = t.i(485651),
        s = t.i(843476),
        n = t.i(107230),
        r = t.i(287022),
        o = t.i(560140),
        a = t.i(271645),
        l = t.i(464978),
        h = t.i(231178),
        u = t.i(104035);
    let c = !1;
    class d extends a.Component {
        componentDidMount() {
            let {
                visualElement: t,
                layoutGroup: e,
                switchLayoutGroup: i,
                layoutId: s
            } = this.props, {
                projection: r
            } = t;
            r && (e.group && e.group.add(r), i && i.register && s && i.register(r), c && r.root.didUpdate(), r.addEventListener("animationComplete", () => {
                this.safeToRemove()
            }), r.setOptions({ ...r.options,
                layoutDependency: this.props.layoutDependency,
                onExitComplete: () => this.safeToRemove()
            })), n.globalProjectionState.hasEverUpdated = !0
        }
        getSnapshotBeforeUpdate(t) {
            let {
                layoutDependency: e,
                visualElement: i,
                drag: s,
                isPresent: n
            } = this.props, {
                projection: o
            } = i;
            return o && (o.isPresent = n, t.layoutDependency !== e && o.setOptions({ ...o.options,
                layoutDependency: e
            }), c = !0, s || t.layoutDependency !== e || void 0 === e || t.isPresent !== n ? o.willUpdate() : this.safeToRemove(), t.isPresent !== n && (n ? o.promote() : o.relegate() || r.frame.postRender(() => {
                let t = o.getStack();
                t && t.members.length || this.safeToRemove()
            }))), null
        }
        componentDidUpdate() {
            let {
                visualElement: t,
                layoutAnchor: e
            } = this.props, {
                projection: i
            } = t;
            i && (i.options.layoutAnchor = e, i.root.didUpdate(), o.microtask.postRender(() => {
                !i.currentAnimation && i.isLead() && this.safeToRemove()
            }))
        }
        componentWillUnmount() {
            let {
                visualElement: t,
                layoutGroup: e,
                switchLayoutGroup: i
            } = this.props, {
                projection: s
            } = t;
            c = !0, s && (s.scheduleCheckAfterUnmount(), e && e.group && e.group.remove(s), i && i.deregister && i.deregister(s))
        }
        safeToRemove() {
            let {
                safeToRemove: t
            } = this.props;
            t && t()
        }
        render() {
            return null
        }
    }

    function m(t) {
        let [e, i] = (0, l.usePresence)(), n = (0, a.useContext)(h.LayoutGroupContext);
        return (0, s.jsx)(d, { ...t,
            layoutGroup: n,
            switchLayoutGroup: (0, a.useContext)(u.SwitchLayoutGroupContext),
            isPresent: e,
            safeToRemove: i
        })
    }
    t.s(["MeasureLayout", 0, m], 877397);
    var p = t.i(570596),
        f = t.i(476959),
        g = t.i(260830),
        v = t.i(939011),
        y = t.i(486427),
        x = t.i(83411),
        T = t.i(716896),
        w = t.i(987333),
        b = t.i(496173),
        S = t.i(924463);
    t.i(763074);
    var P = t.i(889026),
        M = t.i(100706),
        A = t.i(733871),
        V = t.i(265091),
        E = t.i(783920),
        C = t.i(791559),
        D = t.i(895051);
    let k = D.cornerRadiusProps.length,
        R = t => "string" == typeof t ? parseFloat(t) : t,
        L = t => "number" == typeof t || V.px.test(t);

    function B(t, e) {
        return void 0 !== t[e] ? t[e] : t.borderRadius
    }
    let F = I(0, .5, C.circOut),
        j = I(.5, .95, g.noop);

    function I(t, e, i) {
        return s => s < t ? 0 : s > e ? 1 : i((0, E.progress)(t, e, s))
    }

    function O(t, e) {
        t.min = e.min, t.max = e.max
    }

    function N(t, e) {
        O(t.x, e.x), O(t.y, e.y)
    }

    function U(t, e) {
        t.translate = e.translate, t.scale = e.scale, t.originPoint = e.originPoint, t.origin = e.origin
    }
    var W = t.i(135636),
        $ = t.i(652101);

    function G(t, e, i, s, n) {
        return t -= e, t = (0, W.scalePoint)(t, 1 / i, s), void 0 !== n && (t = (0, W.scalePoint)(t, 1 / n, s)), t
    }

    function z(t, e, [i, s, n], r, o) {
        ! function(t, e = 0, i = 1, s = .5, n, r = t, o = t) {
            if (V.percent.test(e) && (e = parseFloat(e), e = (0, M.mixNumber)(o.min, o.max, e / 100) - o.min), "number" != typeof e) return;
            let a = (0, M.mixNumber)(r.min, r.max, s);
            t === r && (a -= e), t.min = G(t.min, e, i, a, n), t.max = G(t.max, e, i, a, n)
        }(t, e[i], e[s], e[n], e.scale, r, o)
    }
    let H = ["x", "scaleX", "originX"],
        K = ["y", "scaleY", "originY"];

    function Y(t, e, i, s) {
        z(t.x, e, H, i ? i.x : void 0, s ? s.x : void 0), z(t.y, e, K, i ? i.y : void 0, s ? s.y : void 0)
    }
    var X = t.i(130162);

    function q(t) {
        return 0 === t.translate && 1 === t.scale
    }

    function _(t) {
        return q(t.x) && q(t.y)
    }

    function Z(t, e) {
        return t.min === e.min && t.max === e.max
    }

    function J(t, e) {
        return Math.round(t.min) === Math.round(e.min) && Math.round(t.max) === Math.round(e.max)
    }

    function Q(t, e) {
        return J(t.x, e.x) && J(t.y, e.y)
    }

    function tt(t) {
        return (0, $.calcLength)(t.x) / (0, $.calcLength)(t.y)
    }

    function te(t, e) {
        return t.translate === e.translate && t.scale === e.scale && t.originPoint === e.originPoint
    }
    var ti = t.i(133887);
    class ts {
        constructor() {
            this.members = []
        }
        add(t) {
            (0, ti.addUniqueItem)(this.members, t);
            for (let e = this.members.length - 1; e >= 0; e--) {
                let i = this.members[e];
                if (i === t || i === this.lead || i === this.prevLead) continue;
                let s = i.instance;
                s && !1 !== s.isConnected || i.snapshot || ((0, ti.removeItem)(this.members, i), i.unmount())
            }
            t.scheduleRender()
        }
        remove(t) {
            if ((0, ti.removeItem)(this.members, t), t === this.prevLead && (this.prevLead = void 0), t === this.lead) {
                let t = this.members[this.members.length - 1];
                t && this.promote(t)
            }
        }
        relegate(t) {
            for (let e = this.members.indexOf(t) - 1; e >= 0; e--) {
                let t = this.members[e];
                if (!1 !== t.isPresent && t.instance ? .isConnected !== !1) return this.promote(t), !0
            }
            return !1
        }
        promote(t, e) {
            let i = this.lead;
            if (t !== i && (this.prevLead = i, this.lead = t, t.show(), i)) {
                i.updateSnapshot(), t.scheduleRender();
                let {
                    layoutDependency: s
                } = i.options, {
                    layoutDependency: n
                } = t.options;
                (void 0 === s || s !== n) && (t.resumeFrom = i, e && (i.preserveOpacity = !0), i.snapshot && (t.snapshot = i.snapshot, t.snapshot.latestValues = i.animationValues || i.latestValues), t.root ? .isUpdating && (t.isLayoutDirty = !0)), !1 === t.options.crossfade && i.hide()
            }
        }
        exitAnimationComplete() {
            this.members.forEach(t => {
                t.options.onExitComplete ? .(), t.resumingFrom ? .options.onExitComplete ? .()
            })
        }
        scheduleRender() {
            this.members.forEach(t => t.instance && t.scheduleRender(!1))
        }
        removeLeadSnapshot() {
            this.lead ? .snapshot && (this.lead.snapshot = void 0)
        }
    }
    var tn = t.i(655559);
    let tr = (t, e) => t.depth - e.depth;
    class to {
        constructor() {
            this.children = [], this.isDirty = !1
        }
        add(t) {
            (0, ti.addUniqueItem)(this.children, t), this.isDirty = !0
        }
        remove(t) {
            (0, ti.removeItem)(this.children, t), this.isDirty = !0
        }
        forEach(t) {
            this.isDirty && this.children.sort(tr), this.isDirty = !1, this.children.forEach(t)
        }
    }
    var ta = t.i(177777);
    let tl = ["", "X", "Y", "Z"],
        th = 0;

    function tu(t, e, i, s) {
        let {
            latestValues: n
        } = e;
        n[t] && (i[t] = n[t], e.setStaticValue(t, 0), s && (s[t] = 0))
    }

    function tc({
        attachResizeListener: t,
        defaultParent: e,
        measureScroll: i,
        checkIsScrollRoot: s,
        resetTransform: a
    }) {
        return class {
            constructor(t = {}, i = e ? .()) {
                this.id = th++, this.animationId = 0, this.animationCommitId = 0, this.children = new Set, this.options = {}, this.isTreeAnimating = !1, this.isAnimationBlocked = !1, this.isLayoutDirty = !1, this.isProjectionDirty = !1, this.isSharedProjectionDirty = !1, this.isTransformDirty = !1, this.updateManuallyBlocked = !1, this.updateBlockedByResize = !1, this.isUpdating = !1, this.isSVG = !1, this.needsReset = !1, this.shouldResetTransform = !1, this.hasCheckedOptimisedAppear = !1, this.treeScale = {
                    x: 1,
                    y: 1
                }, this.eventHandlers = new Map, this.hasTreeAnimated = !1, this.layoutVersion = 0, this.updateScheduled = !1, this.scheduleUpdate = () => this.update(), this.projectionUpdateScheduled = !1, this.checkUpdateFailed = () => {
                    this.isUpdating && (this.isUpdating = !1, this.clearAllSnapshots())
                }, this.updateProjection = () => {
                    this.projectionUpdateScheduled = !1, this.nodes.forEach(tp), this.nodes.forEach(tS), this.nodes.forEach(tP), this.nodes.forEach(tf)
                }, this.resolvedRelativeTargetAt = 0, this.linkedParentVersion = 0, this.hasProjected = !1, this.isVisible = !0, this.animationProgress = 0, this.sharedNodes = new Map, this.latestValues = t, this.root = i ? i.root || i : this, this.path = i ? [...i.path, i] : [], this.parent = i, this.depth = i ? i.depth + 1 : 0;
                for (let t = 0; t < this.path.length; t++) this.path[t].shouldResetTransform = !0;
                this.root === this && (this.nodes = new to)
            }
            addEventListener(t, e) {
                return this.eventHandlers.has(t) || this.eventHandlers.set(t, new p.SubscriptionManager), this.eventHandlers.get(t).add(e)
            }
            notifyListeners(t, ...e) {
                let i = this.eventHandlers.get(t);
                i && i.notify(...e)
            }
            hasListeners(t) {
                return this.eventHandlers.has(t)
            }
            mount(e) {
                if (this.instance) return;
                this.isSVG = (0, P.isSVGElement)(e) && (!(0, P.isSVGElement)(e) || "svg" !== e.tagName), this.instance = e;
                let {
                    layoutId: i,
                    layout: s,
                    visualElement: o
                } = this.options;
                if (o && !o.current && o.mount(e), this.root.nodes.add(this), this.parent && this.parent.children.add(this), this.root.hasTreeAnimated && (s || i) && (this.isLayoutDirty = !0), t) {
                    let i, s = 0,
                        o = () => this.root.updateBlockedByResize = !1;
                    r.frame.read(() => {
                        s = window.innerWidth
                    }), t(e, () => {
                        let t = window.innerWidth;
                        if (t !== s) {
                            let e, a;
                            s = t, this.root.updateBlockedByResize = !0, i && i(), e = b.time.now(), a = ({
                                timestamp: t
                            }) => {
                                let i = t - e;
                                i >= 250 && ((0, r.cancelFrame)(a), o(i - 250))
                            }, r.frame.setup(a, !0), i = () => (0, r.cancelFrame)(a), n.globalProjectionState.hasAnimatedSinceResize && (n.globalProjectionState.hasAnimatedSinceResize = !1, this.nodes.forEach(tb))
                        }
                    })
                }
                i && this.root.registerSharedNode(i, this), !1 !== this.options.animate && o && (i || s) && this.addEventListener("didUpdate", ({
                    delta: t,
                    hasLayoutChanged: e,
                    hasRelativeLayoutChanged: i,
                    layout: s
                }) => {
                    if (this.isTreeAnimationBlocked()) {
                        this.target = void 0, this.relativeTarget = void 0;
                        return
                    }
                    let n = this.options.transition || o.getDefaultTransition() || tD,
                        {
                            onLayoutAnimationStart: r,
                            onLayoutAnimationComplete: a
                        } = o.getProps(),
                        l = !this.targetLayout || !Q(this.targetLayout, s),
                        h = !e && i;
                    if (this.options.layoutRoot || this.resumeFrom || h || e && (l || !this.currentAnimation)) {
                        this.resumeFrom && (this.resumingFrom = this.resumeFrom, this.resumingFrom.resumingFrom = void 0);
                        let e = { ...(0, w.getValueTransition)(n, "layout"),
                            onPlay: r,
                            onComplete: a
                        };
                        (o.shouldReduceMotion || this.options.layoutRoot) && (e.delay = 0, e.type = !1), this.startAnimation(e), this.setAnimationOrigin(t, h, e.path)
                    } else e || tb(this), this.isLead() && this.options.onExitComplete && this.options.onExitComplete();
                    this.targetLayout = s
                })
            }
            unmount() {
                this.options.layoutId && this.willUpdate(), this.root.nodes.remove(this);
                let t = this.getStack();
                t && t.remove(this), this.parent && this.parent.children.delete(this), this.instance = void 0, this.eventHandlers.clear(), (0, r.cancelFrame)(this.updateProjection)
            }
            blockUpdate() {
                this.updateManuallyBlocked = !0
            }
            unblockUpdate() {
                this.updateManuallyBlocked = !1
            }
            isUpdateBlocked() {
                return this.updateManuallyBlocked || this.updateBlockedByResize
            }
            isTreeAnimationBlocked() {
                return this.isAnimationBlocked || this.parent && this.parent.isTreeAnimationBlocked() || !1
            }
            startUpdate() {
                !this.isUpdateBlocked() && (this.isUpdating = !0, this.nodes && this.nodes.forEach(tM), this.animationId++)
            }
            getTransformTemplate() {
                let {
                    visualElement: t
                } = this.options;
                return t && t.getProps().transformTemplate
            }
            willUpdate(t = !0) {
                if (this.root.hasTreeAnimated = !0, this.root.isUpdateBlocked()) {
                    this.options.onExitComplete && this.options.onExitComplete();
                    return
                }
                if (window.MotionCancelOptimisedAnimation && !this.hasCheckedOptimisedAppear && function t(e) {
                        if (e.hasCheckedOptimisedAppear = !0, e.root === e) return;
                        let {
                            visualElement: i
                        } = e.options;
                        if (!i) return;
                        let s = (0, T.getOptimisedAppearId)(i);
                        if (window.MotionHasOptimisedAnimation(s, "transform")) {
                            let {
                                layout: t,
                                layoutId: i
                            } = e.options;
                            window.MotionCancelOptimisedAnimation(s, "transform", r.frame, !(t || i))
                        }
                        let {
                            parent: n
                        } = e;
                        n && !n.hasCheckedOptimisedAppear && t(n)
                    }(this), this.root.isUpdating || this.root.startUpdate(), this.isLayoutDirty) return;
                this.isLayoutDirty = !0;
                for (let t = 0; t < this.path.length; t++) {
                    let e = this.path[t];
                    e.shouldResetTransform = !0, ("string" == typeof e.latestValues.x || "string" == typeof e.latestValues.y) && (e.isLayoutDirty = !0), e.updateScroll("snapshot"), e.options.layoutRoot && e.willUpdate(!1)
                }
                let {
                    layoutId: e,
                    layout: i
                } = this.options;
                if (void 0 === e && !i) return;
                let s = this.getTransformTemplate();
                this.prevTransformTemplateValue = s ? s(this.latestValues, "") : void 0, this.updateSnapshot(), t && this.notifyListeners("willUpdate")
            }
            update() {
                if (this.updateScheduled = !1, this.isUpdateBlocked()) {
                    let t = this.updateBlockedByResize;
                    this.unblockUpdate(), this.updateBlockedByResize = !1, this.clearAllSnapshots(), t && this.nodes.forEach(ty), this.nodes.forEach(tv);
                    return
                }
                if (this.animationId <= this.animationCommitId) return void this.nodes.forEach(tx);
                this.animationCommitId = this.animationId, this.isUpdating ? (this.isUpdating = !1, this.nodes.forEach(tT), this.nodes.forEach(tw), this.nodes.forEach(td), this.nodes.forEach(tm)) : this.nodes.forEach(tx), this.clearAllSnapshots();
                let t = b.time.now();
                r.frameData.delta = (0, f.clamp)(0, 1e3 / 60, t - r.frameData.timestamp), r.frameData.timestamp = t, r.frameData.isProcessing = !0, r.frameSteps.update.process(r.frameData), r.frameSteps.preRender.process(r.frameData), r.frameSteps.render.process(r.frameData), r.frameData.isProcessing = !1
            }
            didUpdate() {
                this.updateScheduled || (this.updateScheduled = !0, o.microtask.read(this.scheduleUpdate))
            }
            clearAllSnapshots() {
                this.nodes.forEach(tg), this.sharedNodes.forEach(tA)
            }
            scheduleUpdateProjection() {
                this.projectionUpdateScheduled || (this.projectionUpdateScheduled = !0, r.frame.preRender(this.updateProjection, !1, !0))
            }
            scheduleCheckAfterUnmount() {
                r.frame.postRender(() => {
                    this.isLayoutDirty ? this.root.didUpdate() : this.root.checkUpdateFailed()
                })
            }
            updateSnapshot() {
                !this.snapshot && this.instance && (this.snapshot = this.measure(), !this.snapshot || (0, $.calcLength)(this.snapshot.measuredBox.x) || (0, $.calcLength)(this.snapshot.measuredBox.y) || (this.snapshot = void 0))
            }
            updateLayout() {
                if (!this.instance || (this.updateScroll(), !(this.options.alwaysMeasureLayout && this.isLead()) && !this.isLayoutDirty)) return;
                if (this.resumeFrom && !this.resumeFrom.instance)
                    for (let t = 0; t < this.path.length; t++) this.path[t].updateScroll();
                let t = this.layout;
                this.layout = this.measure(!1), this.layoutVersion++, this.layoutCorrected || (this.layoutCorrected = (0, X.createBox)()), this.isLayoutDirty = !1, this.projectionDelta = void 0, this.notifyListeners("measure", this.layout.layoutBox);
                let {
                    visualElement: e
                } = this.options;
                e && e.notify("LayoutMeasure", this.layout.layoutBox, t ? t.layoutBox : void 0)
            }
            updateScroll(t = "measure") {
                let e = !!(this.options.layoutScroll && this.instance);
                if (this.scroll && this.scroll.animationId === this.root.animationId && this.scroll.phase === t && (e = !1), e && this.instance) {
                    let e = s(this.instance);
                    this.scroll = {
                        animationId: this.root.animationId,
                        phase: t,
                        isRoot: e,
                        offset: i(this.instance),
                        wasRoot: this.scroll ? this.scroll.isRoot : e
                    }
                }
            }
            resetTransform() {
                if (!a) return;
                let t = this.isLayoutDirty || this.shouldResetTransform || this.options.alwaysMeasureLayout,
                    e = this.projectionDelta && !_(this.projectionDelta),
                    i = this.getTransformTemplate(),
                    s = i ? i(this.latestValues, "") : void 0,
                    n = s !== this.prevTransformTemplateValue;
                t && this.instance && (e || (0, ta.hasTransform)(this.latestValues) || n) && (a(this.instance, s), this.shouldResetTransform = !1, this.scheduleRender())
            }
            measure(t = !0) {
                var e;
                let i = this.measurePageBox(),
                    s = this.removeElementScroll(i);
                return t && (s = this.removeTransform(s)), tL((e = s).x), tL(e.y), {
                    animationId: this.root.animationId,
                    measuredBox: i,
                    layoutBox: s,
                    latestValues: {},
                    source: this.id
                }
            }
            measurePageBox() {
                let {
                    visualElement: t
                } = this.options;
                if (!t) return (0, X.createBox)();
                let e = t.measureViewportBox();
                if (!(this.scroll ? .wasRoot || this.path.some(tF))) {
                    let {
                        scroll: t
                    } = this.root;
                    t && ((0, W.translateAxis)(e.x, t.offset.x), (0, W.translateAxis)(e.y, t.offset.y))
                }
                return e
            }
            removeElementScroll(t) {
                let e = (0, X.createBox)();
                if (N(e, t), this.scroll ? .wasRoot) return e;
                for (let i = 0; i < this.path.length; i++) {
                    let s = this.path[i],
                        {
                            scroll: n,
                            options: r
                        } = s;
                    s !== this.root && n && r.layoutScroll && (n.wasRoot && N(e, t), (0, W.translateAxis)(e.x, n.offset.x), (0, W.translateAxis)(e.y, n.offset.y))
                }
                return e
            }
            applyTransform(t, e = !1, i) {
                let s = i || (0, X.createBox)();
                N(s, t);
                for (let t = 0; t < this.path.length; t++) {
                    let i = this.path[t];
                    !e && i.options.layoutScroll && i.scroll && i !== i.root && ((0, W.translateAxis)(s.x, -i.scroll.offset.x), (0, W.translateAxis)(s.y, -i.scroll.offset.y)), (0, ta.hasTransform)(i.latestValues) && (0, W.transformBox)(s, i.latestValues, i.layout ? .layoutBox)
                }
                return (0, ta.hasTransform)(this.latestValues) && (0, W.transformBox)(s, this.latestValues, this.layout ? .layoutBox), s
            }
            removeTransform(t) {
                let e = (0, X.createBox)();
                N(e, t);
                for (let t = 0; t < this.path.length; t++) {
                    let i, s = this.path[t];
                    (0, ta.hasTransform)(s.latestValues) && (s.instance && ((0, ta.hasScale)(s.latestValues) && s.updateSnapshot(), N(i = (0, X.createBox)(), s.measurePageBox())), Y(e, s.latestValues, s.snapshot ? .layoutBox, i))
                }
                return (0, ta.hasTransform)(this.latestValues) && Y(e, this.latestValues), e
            }
            setTargetDelta(t) {
                this.targetDelta = t, this.root.scheduleUpdateProjection(), this.isProjectionDirty = !0
            }
            setOptions(t) {
                this.options = { ...this.options,
                    ...t,
                    crossfade: void 0 === t.crossfade || t.crossfade
                }
            }
            clearMeasurements() {
                this.scroll = void 0, this.layout = void 0, this.snapshot = void 0, this.prevTransformTemplateValue = void 0, this.targetDelta = void 0, this.target = void 0, this.isLayoutDirty = !1
            }
            forceRelativeParentToResolveTarget() {
                this.relativeParent && this.relativeParent.resolvedRelativeTargetAt !== r.frameData.timestamp && this.relativeParent.resolveTargetDelta(!0)
            }
            resolveTargetDelta(t = !1) {
                let e = this.getLead();
                this.isProjectionDirty || (this.isProjectionDirty = e.isProjectionDirty), this.isTransformDirty || (this.isTransformDirty = e.isTransformDirty), this.isSharedProjectionDirty || (this.isSharedProjectionDirty = e.isSharedProjectionDirty);
                let i = !!this.resumingFrom || this !== e;
                if (!(t || i && this.isSharedProjectionDirty || this.isProjectionDirty || this.parent ? .isProjectionDirty || this.attemptToResolveRelativeTarget || this.root.updateBlockedByResize)) return;
                let {
                    layout: s,
                    layoutId: n
                } = this.options;
                if (!this.layout || !(s || n)) return;
                this.resolvedRelativeTargetAt = r.frameData.timestamp;
                let o = this.getClosestProjectingParent();
                o && this.linkedParentVersion !== o.layoutVersion && !o.options.layoutRoot && this.removeRelativeTarget(), this.targetDelta || this.relativeTarget || (!1 !== this.options.layoutAnchor && o && o.layout ? this.createRelativeTarget(o, this.layout.layoutBox, o.layout.layoutBox) : this.removeRelativeTarget()), (this.relativeTarget || this.targetDelta) && (this.target || (this.target = (0, X.createBox)(), this.targetWithTransforms = (0, X.createBox)()), this.relativeTarget && this.relativeTargetOrigin && this.relativeParent && this.relativeParent.target ? (this.forceRelativeParentToResolveTarget(), (0, $.calcRelativeBox)(this.target, this.relativeTarget, this.relativeParent.target, this.options.layoutAnchor || void 0)) : this.targetDelta ? (this.resumingFrom ? this.applyTransform(this.layout.layoutBox, !1, this.target) : N(this.target, this.layout.layoutBox), (0, W.applyBoxDelta)(this.target, this.targetDelta)) : N(this.target, this.layout.layoutBox), this.attemptToResolveRelativeTarget && (this.attemptToResolveRelativeTarget = !1, !1 !== this.options.layoutAnchor && o && !!o.resumingFrom == !!this.resumingFrom && !o.options.layoutScroll && o.target && 1 !== this.animationProgress ? this.createRelativeTarget(o, this.target, o.target) : this.relativeParent = this.relativeTarget = void 0))
            }
            getClosestProjectingParent() {
                if (!(!this.parent || (0, ta.hasScale)(this.parent.latestValues) || (0, ta.has2DTranslate)(this.parent.latestValues)))
                    if (this.parent.isProjecting()) return this.parent;
                    else return this.parent.getClosestProjectingParent()
            }
            isProjecting() {
                return !!((this.relativeTarget || this.targetDelta || this.options.layoutRoot) && this.layout)
            }
            createRelativeTarget(t, e, i) {
                this.relativeParent = t, this.linkedParentVersion = t.layoutVersion, this.forceRelativeParentToResolveTarget(), this.relativeTarget = (0, X.createBox)(), this.relativeTargetOrigin = (0, X.createBox)(), (0, $.calcRelativePosition)(this.relativeTargetOrigin, e, i, this.options.layoutAnchor || void 0), N(this.relativeTarget, this.relativeTargetOrigin)
            }
            removeRelativeTarget() {
                this.relativeParent = this.relativeTarget = void 0
            }
            calcProjection() {
                let t = this.getLead(),
                    e = !!this.resumingFrom || this !== t,
                    i = !0;
                if ((this.isProjectionDirty || this.parent ? .isProjectionDirty) && (i = !1), e && (this.isSharedProjectionDirty || this.isTransformDirty) && (i = !1), this.resolvedRelativeTargetAt === r.frameData.timestamp && (i = !1), i) return;
                let {
                    layout: s,
                    layoutId: n
                } = this.options;
                if (this.isTreeAnimating = !!(this.parent && this.parent.isTreeAnimating || this.currentAnimation || this.pendingAnimation), this.isTreeAnimating || (this.targetDelta = this.relativeTarget = void 0), !this.layout || !(s || n)) return;
                N(this.layoutCorrected, this.layout.layoutBox);
                let o = this.treeScale.x,
                    a = this.treeScale.y;
                (0, W.applyTreeDeltas)(this.layoutCorrected, this.treeScale, this.path, e), t.layout && !t.target && (1 !== this.treeScale.x || 1 !== this.treeScale.y) && (t.target = t.layout.layoutBox, t.targetWithTransforms = (0, X.createBox)());
                let {
                    target: l
                } = t;
                if (!l) {
                    this.prevProjectionDelta && (this.createProjectionDeltas(), this.scheduleRender());
                    return
                }
                this.projectionDelta && this.prevProjectionDelta ? (U(this.prevProjectionDelta.x, this.projectionDelta.x), U(this.prevProjectionDelta.y, this.projectionDelta.y)) : this.createProjectionDeltas(), (0, $.calcBoxDelta)(this.projectionDelta, this.layoutCorrected, l, this.latestValues), this.treeScale.x === o && this.treeScale.y === a && te(this.projectionDelta.x, this.prevProjectionDelta.x) && te(this.projectionDelta.y, this.prevProjectionDelta.y) || (this.hasProjected = !0, this.scheduleRender(), this.notifyListeners("projectionUpdate", l))
            }
            hide() {
                this.isVisible = !1
            }
            show() {
                this.isVisible = !0
            }
            scheduleRender(t = !0) {
                if (this.options.visualElement ? .scheduleRender(), t) {
                    let t = this.getStack();
                    t && t.scheduleRender()
                }
                this.resumingFrom && !this.resumingFrom.instance && (this.resumingFrom = void 0)
            }
            createProjectionDeltas() {
                this.prevProjectionDelta = (0, X.createDelta)(), this.projectionDelta = (0, X.createDelta)(), this.projectionDeltaWithTransform = (0, X.createDelta)()
            }
            setAnimationOrigin(t, e = !1, i) {
                let s, n = this.snapshot,
                    r = n ? n.latestValues : {},
                    o = { ...this.latestValues
                    },
                    a = (0, X.createDelta)();
                this.relativeParent && this.relativeParent.options.layoutRoot || (this.relativeTarget = this.relativeTargetOrigin = void 0), this.attemptToResolveRelativeTarget = !e;
                let l = (0, X.createBox)(),
                    h = (n ? n.source : void 0) !== (this.layout ? this.layout.source : void 0),
                    u = this.getStack(),
                    c = !u || u.members.length <= 1,
                    d = !!(h && !c && !0 === this.options.crossfade && !this.path.some(tC));
                this.animationProgress = 0;
                let m = i ? .interpolateProjection(t);
                this.mixTargetDelta = e => {
                    let i = e / 1e3,
                        n = m ? .(i);
                    if (n ? (a.x.translate = n.x, a.x.scale = (0, M.mixNumber)(t.x.scale, 1, i), a.x.origin = t.x.origin, a.x.originPoint = t.x.originPoint, a.y.translate = n.y, a.y.scale = (0, M.mixNumber)(t.y.scale, 1, i), a.y.origin = t.y.origin, a.y.originPoint = t.y.originPoint) : (tV(a.x, t.x, i), tV(a.y, t.y, i)), this.setTargetDelta(a), this.relativeTarget && this.relativeTargetOrigin && this.layout && this.relativeParent && this.relativeParent.layout) {
                        var u, p, f, g, v, y;
                        (0, $.calcRelativePosition)(l, this.layout.layoutBox, this.relativeParent.layout.layoutBox, this.options.layoutAnchor || void 0), f = this.relativeTarget, g = this.relativeTargetOrigin, v = l, y = i, tE(f.x, g.x, v.x, y), tE(f.y, g.y, v.y, y), s && (u = this.relativeTarget, p = s, Z(u.x, p.x) && Z(u.y, p.y)) && (this.isProjectionDirty = !1), s || (s = (0, X.createBox)()), N(s, this.relativeTarget)
                    }
                    h && (this.animationValues = o, function(t, e, i, s, n, r) {
                        n ? (t.opacity = (0, M.mixNumber)(0, i.opacity ? ? 1, F(s)), t.opacityExit = (0, M.mixNumber)(e.opacity ? ? 1, 0, j(s))) : r && (t.opacity = (0, M.mixNumber)(e.opacity ? ? 1, i.opacity ? ? 1, s));
                        for (let n = 0; n < k; n++) {
                            let r = D.cornerRadiusProps[n],
                                o = B(e, r),
                                a = B(i, r);
                            (void 0 !== o || void 0 !== a) && (o || (o = 0), a || (a = 0), 0 === o || 0 === a || L(o) === L(a) ? (t[r] = Math.max((0, M.mixNumber)(R(o), R(a), s), 0), (V.percent.test(a) || V.percent.test(o)) && (t[r] += "%")) : t[r] = a)
                        }(e.rotate || i.rotate) && (t.rotate = (0, M.mixNumber)(e.rotate || 0, i.rotate || 0, s))
                    }(o, r, this.latestValues, i, d, c)), n && void 0 !== n.rotate && (this.animationValues || (this.animationValues = o), this.animationValues.pathRotation = n.rotate), this.root.scheduleUpdateProjection(), this.scheduleRender(), this.animationProgress = i
                }, this.mixTargetDelta(1e3 * !!this.options.layoutRoot)
            }
            startAnimation(t) {
                this.notifyListeners("animationStart"), this.currentAnimation ? .stop(), this.resumingFrom ? .currentAnimation ? .stop(), this.pendingAnimation && ((0, r.cancelFrame)(this.pendingAnimation), this.pendingAnimation = void 0), this.pendingAnimation = r.frame.update(() => {
                    var e, i, s;
                    let r;
                    n.globalProjectionState.hasAnimatedSinceResize = !0, this.motionValue || (this.motionValue = (0, y.motionValue)(0)), this.motionValue.jump(0, !1), this.currentAnimation = (e = this.motionValue, i = [0, 1e3], s = { ...t,
                        velocity: 0,
                        isSync: !0,
                        onUpdate: e => {
                            this.mixTargetDelta(e), t.onUpdate && t.onUpdate(e)
                        },
                        onComplete: () => {
                            t.onComplete && t.onComplete(), this.completeAnimation()
                        }
                    }, (r = (0, x.isMotionValue)(e) ? e : (0, y.motionValue)(e)).start((0, v.animateMotionValue)("", r, i, s)), r.animation), this.resumingFrom && (this.resumingFrom.currentAnimation = this.currentAnimation), this.pendingAnimation = void 0
                })
            }
            completeAnimation() {
                this.resumingFrom && (this.resumingFrom.currentAnimation = void 0, this.resumingFrom.preserveOpacity = void 0);
                let t = this.getStack();
                t && t.exitAnimationComplete(), this.resumingFrom = this.currentAnimation = this.animationValues = void 0, this.notifyListeners("animationComplete")
            }
            finishAnimation() {
                this.currentAnimation && (this.mixTargetDelta && this.mixTargetDelta(1e3), this.currentAnimation.stop()), this.completeAnimation()
            }
            applyTransformsToTarget() {
                let t = this.getLead(),
                    {
                        targetWithTransforms: e,
                        target: i,
                        layout: s,
                        latestValues: n
                    } = t;
                if (e && i && s) {
                    if (this !== t && this.layout && s && tB(this.options.animationType, this.layout.layoutBox, s.layoutBox)) {
                        i = this.target || (0, X.createBox)();
                        let e = (0, $.calcLength)(this.layout.layoutBox.x);
                        i.x.min = t.target.x.min, i.x.max = i.x.min + e;
                        let s = (0, $.calcLength)(this.layout.layoutBox.y);
                        i.y.min = t.target.y.min, i.y.max = i.y.min + s
                    }
                    N(e, i), (0, W.transformBox)(e, n), (0, $.calcBoxDelta)(this.projectionDeltaWithTransform, this.layoutCorrected, e, n)
                }
            }
            registerSharedNode(t, e) {
                this.sharedNodes.has(t) || this.sharedNodes.set(t, new ts), this.sharedNodes.get(t).add(e);
                let i = e.options.initialPromotionConfig;
                e.promote({
                    transition: i ? i.transition : void 0,
                    preserveFollowOpacity: i && i.shouldPreserveFollowOpacity ? i.shouldPreserveFollowOpacity(e) : void 0
                })
            }
            isLead() {
                let t = this.getStack();
                return !t || t.lead === this
            }
            getLead() {
                let {
                    layoutId: t
                } = this.options;
                return t && this.getStack() ? .lead || this
            }
            getPrevLead() {
                let {
                    layoutId: t
                } = this.options;
                return t ? this.getStack() ? .prevLead : void 0
            }
            getStack() {
                let {
                    layoutId: t
                } = this.options;
                if (t) return this.root.sharedNodes.get(t)
            }
            promote({
                needsReset: t,
                transition: e,
                preserveFollowOpacity: i
            } = {}) {
                let s = this.getStack();
                s && s.promote(this, i), t && (this.projectionDelta = void 0, this.needsReset = !0), e && this.setOptions({
                    transition: e
                })
            }
            relegate() {
                let t = this.getStack();
                return !!t && t.relegate(this)
            }
            resetSkewAndRotation() {
                let {
                    visualElement: t
                } = this.options;
                if (!t) return;
                let e = !1,
                    {
                        latestValues: i
                    } = t;
                if ((i.z || i.rotate || i.rotateX || i.rotateY || i.rotateZ || i.skewX || i.skewY) && (e = !0), !e) return;
                let s = {};
                i.z && tu("z", t, s, this.animationValues);
                for (let e = 0; e < tl.length; e++) tu(`rotate${tl[e]}`, t, s, this.animationValues), tu(`skew${tl[e]}`, t, s, this.animationValues);
                for (let e in t.render(), s) t.setStaticValue(e, s[e]), this.animationValues && (this.animationValues[e] = s[e]);
                t.scheduleRender()
            }
            applyProjectionStyles(t, e) {
                if (!this.instance || this.isSVG) return;
                if (!this.isVisible) {
                    t.visibility = "hidden";
                    return
                }
                let i = this.getTransformTemplate();
                if (this.needsReset) {
                    this.needsReset = !1, t.visibility = "", t.opacity = "", t.pointerEvents = (0, A.resolveMotionValue)(e ? .pointerEvents) || "", t.transform = i ? i(this.latestValues, "") : "none";
                    return
                }
                let s = this.getLead();
                if (!this.projectionDelta || !this.layout || !s.target) {
                    this.options.layoutId && (t.opacity = void 0 !== this.latestValues.opacity ? this.latestValues.opacity : 1, t.pointerEvents = (0, A.resolveMotionValue)(e ? .pointerEvents) || ""), this.hasProjected && !(0, ta.hasTransform)(this.latestValues) && (t.transform = i ? i({}, "") : "none", this.hasProjected = !1);
                    return
                }
                t.visibility = "";
                let n = s.animationValues || s.latestValues;
                this.applyTransformsToTarget();
                let r = function(t, e, i) {
                    let s = "",
                        n = t.x.translate / e.x,
                        r = t.y.translate / e.y,
                        o = i ? .z || 0;
                    if ((n || r || o) && (s = `translate3d(${n}px, ${r}px, ${o}px) `), (1 !== e.x || 1 !== e.y) && (s += `scale(${1/e.x}, ${1/e.y}) `), i) {
                        let {
                            transformPerspective: t,
                            rotate: e,
                            pathRotation: n,
                            rotateX: r,
                            rotateY: o,
                            skewX: a,
                            skewY: l
                        } = i;
                        t && (s = `perspective(${t}px) ${s}`), e && (s += `rotate(${e}deg) `), n && (s += `rotate(${n}deg) `), r && (s += `rotateX(${r}deg) `), o && (s += `rotateY(${o}deg) `), a && (s += `skewX(${a}deg) `), l && (s += `skewY(${l}deg) `)
                    }
                    let a = t.x.scale * e.x,
                        l = t.y.scale * e.y;
                    return (1 !== a || 1 !== l) && (s += `scale(${a}, ${l})`), s || "none"
                }(this.projectionDeltaWithTransform, this.treeScale, n);
                i && (r = i(n, r)), t.transform = r;
                let {
                    x: o,
                    y: a
                } = this.projectionDelta;
                for (let e in t.transformOrigin = `${100*o.origin}% ${100*a.origin}% 0`, s.animationValues ? t.opacity = s === this ? n.opacity ? ? this.latestValues.opacity ? ? 1 : this.preserveOpacity ? this.latestValues.opacity : n.opacityExit : t.opacity = s === this ? void 0 !== n.opacity ? n.opacity : "" : void 0 !== n.opacityExit ? n.opacityExit : 0, S.scaleCorrectors) {
                    if (void 0 === n[e]) continue;
                    let {
                        correct: i,
                        applyTo: o,
                        isCSSVariable: a
                    } = S.scaleCorrectors[e], l = "none" === r ? n[e] : i(n[e], s);
                    if (o) {
                        let e = o.length;
                        for (let i = 0; i < e; i++) t[o[i]] = l
                    } else a ? this.options.visualElement.renderState.vars[e] = l : t[e] = l
                }
                this.options.layoutId && (t.pointerEvents = s === this ? (0, A.resolveMotionValue)(e ? .pointerEvents) || "" : "none")
            }
            clearSnapshot() {
                this.resumeFrom = this.snapshot = void 0
            }
            resetTree() {
                this.root.nodes.forEach(t => t.currentAnimation ? .stop()), this.root.nodes.forEach(tv), this.root.sharedNodes.clear()
            }
        }
    }

    function td(t) {
        t.updateLayout()
    }

    function tm(t) {
        let e = t.resumeFrom ? .snapshot || t.snapshot;
        if (t.isLead() && t.layout && e && t.hasListeners("didUpdate")) {
            let {
                layoutBox: i,
                measuredBox: s
            } = t.layout, {
                animationType: n
            } = t.options, r = e.source !== t.layout.source;
            if ("size" === n)(0, tn.eachAxis)(t => {
                let s = r ? e.measuredBox[t] : e.layoutBox[t],
                    n = (0, $.calcLength)(s);
                s.min = i[t].min, s.max = s.min + n
            });
            else if ("x" === n || "y" === n) {
                let t = "x" === n ? "y" : "x";
                O(r ? e.measuredBox[t] : e.layoutBox[t], i[t])
            } else tB(n, e.layoutBox, i) && (0, tn.eachAxis)(s => {
                let n = r ? e.measuredBox[s] : e.layoutBox[s],
                    o = (0, $.calcLength)(i[s]);
                n.max = n.min + o, t.relativeTarget && !t.currentAnimation && (t.isProjectionDirty = !0, t.relativeTarget[s].max = t.relativeTarget[s].min + o)
            });
            let o = (0, X.createDelta)();
            (0, $.calcBoxDelta)(o, i, e.layoutBox);
            let a = (0, X.createDelta)();
            r ? (0, $.calcBoxDelta)(a, t.applyTransform(s, !0), e.measuredBox) : (0, $.calcBoxDelta)(a, i, e.layoutBox);
            let l = !_(o),
                h = !1;
            if (!t.resumeFrom) {
                let s = t.getClosestProjectingParent();
                if (s && !s.resumeFrom) {
                    let {
                        snapshot: n,
                        layout: r
                    } = s;
                    if (n && r) {
                        let o = t.options.layoutAnchor || void 0,
                            a = (0, X.createBox)();
                        (0, $.calcRelativePosition)(a, e.layoutBox, n.layoutBox, o);
                        let l = (0, X.createBox)();
                        (0, $.calcRelativePosition)(l, i, r.layoutBox, o), Q(a, l) || (h = !0), s.options.layoutRoot && (t.relativeTarget = l, t.relativeTargetOrigin = a, t.relativeParent = s)
                    }
                }
            }
            t.notifyListeners("didUpdate", {
                layout: i,
                snapshot: e,
                delta: a,
                layoutDelta: o,
                hasLayoutChanged: l,
                hasRelativeLayoutChanged: h
            })
        } else if (t.isLead()) {
            let {
                onExitComplete: e
            } = t.options;
            e && e()
        }
        t.options.transition = void 0
    }

    function tp(t) {
        t.parent && (t.isProjecting() || (t.isProjectionDirty = t.parent.isProjectionDirty), t.isSharedProjectionDirty || (t.isSharedProjectionDirty = !!(t.isProjectionDirty || t.parent.isProjectionDirty || t.parent.isSharedProjectionDirty)), t.isTransformDirty || (t.isTransformDirty = t.parent.isTransformDirty))
    }

    function tf(t) {
        t.isProjectionDirty = t.isSharedProjectionDirty = t.isTransformDirty = !1
    }

    function tg(t) {
        t.clearSnapshot()
    }

    function tv(t) {
        t.clearMeasurements()
    }

    function ty(t) {
        t.isLayoutDirty = !0, t.updateLayout()
    }

    function tx(t) {
        t.isLayoutDirty = !1
    }

    function tT(t) {
        t.isAnimationBlocked && t.layout && !t.isLayoutDirty && (t.snapshot = t.layout, t.isLayoutDirty = !0)
    }

    function tw(t) {
        let {
            visualElement: e
        } = t.options;
        e && e.getProps().onBeforeLayoutMeasure && e.notify("BeforeLayoutMeasure"), t.resetTransform()
    }

    function tb(t) {
        t.finishAnimation(), t.targetDelta = t.relativeTarget = t.target = void 0, t.isProjectionDirty = !0
    }

    function tS(t) {
        t.resolveTargetDelta()
    }

    function tP(t) {
        t.calcProjection()
    }

    function tM(t) {
        t.resetSkewAndRotation()
    }

    function tA(t) {
        t.removeLeadSnapshot()
    }

    function tV(t, e, i) {
        t.translate = (0, M.mixNumber)(e.translate, 0, i), t.scale = (0, M.mixNumber)(e.scale, 1, i), t.origin = e.origin, t.originPoint = e.originPoint
    }

    function tE(t, e, i, s) {
        t.min = (0, M.mixNumber)(e.min, i.min, s), t.max = (0, M.mixNumber)(e.max, i.max, s)
    }

    function tC(t) {
        return t.animationValues && void 0 !== t.animationValues.opacityExit
    }
    let tD = {
            duration: .45,
            ease: [.4, 0, .1, 1]
        },
        tk = t => "u" > typeof navigator && navigator.userAgent && navigator.userAgent.toLowerCase().includes(t),
        tR = tk("applewebkit/") && !tk("chrome/") ? Math.round : g.noop;

    function tL(t) {
        t.min = tR(t.min), t.max = tR(t.max)
    }

    function tB(t, e, i) {
        return "position" === t || "preserve-aspect" === t && !(0, $.isNear)(tt(e), tt(i), .2)
    }

    function tF(t) {
        return t !== t.root && t.scroll ? .wasRoot
    }
    var tj = t.i(282774);
    let tI = tc({
            attachResizeListener: (t, e) => (0, tj.addDomEvent)(t, "resize", e),
            measureScroll: () => ({
                x: document.documentElement.scrollLeft || document.body ? .scrollLeft || 0,
                y: document.documentElement.scrollTop || document.body ? .scrollTop || 0
            }),
            checkIsScrollRoot: () => !0
        }),
        tO = {
            current: void 0
        },
        tN = tc({
            measureScroll: t => ({
                x: t.scrollLeft,
                y: t.scrollTop
            }),
            defaultParent: () => {
                if (!tO.current) {
                    let t = new tI({});
                    t.mount(window), t.setOptions({
                        layoutScroll: !0
                    }), tO.current = t
                }
                return tO.current
            },
            resetTransform: (t, e) => {
                t.style.transform = void 0 !== e ? e : "none"
            },
            checkIsScrollRoot: t => "fixed" === window.getComputedStyle(t).position
        });
    t.s(["HTMLProjectionNode", 0, tN], 717871);
    let tU = {
        pan: {
            Feature: i.PanGesture
        },
        drag: {
            Feature: e.DragGesture,
            ProjectionNode: tN,
            MeasureLayout: m
        }
    };
    t.s(["drag", 0, tU], 646816);
    var tW = t.i(142098),
        t$ = t.i(439676),
        tG = t.i(749652);

    function tz(t, e) {
        let i = (0, tG.resolveElements)(t),
            s = new AbortController;
        return [i, {
            passive: !0,
            ...e,
            signal: s.signal
        }, () => s.abort()]
    }
    t.s(["setupGesture", 0, tz], 973089);
    var tH = t.i(665536);

    function tK(t, e, i) {
        let {
            props: s
        } = t;
        t.animationState && s.whileHover && t.animationState.setActive("whileHover", "Start" === i);
        let n = s["onHover" + i];
        n && r.frame.postRender(() => n(e, (0, tH.extractEventInfo)(e)))
    }
    class tY extends tW.Feature {
        mount() {
            let {
                current: t
            } = this.node;
            t && (this.unmount = function(t, e, i = {}) {
                let [s, n, r] = tz(t, i);
                return s.forEach(t => {
                    let i, s = !1,
                        r = !1,
                        o = e => {
                            i && (i(e), i = void 0), t.removeEventListener("pointerleave", l)
                        },
                        a = t => {
                            s = !1, window.removeEventListener("pointerup", a), window.removeEventListener("pointercancel", a), r && (r = !1, o(t))
                        },
                        l = t => {
                            if ("touch" !== t.pointerType) {
                                if (s) {
                                    r = !0;
                                    return
                                }
                                o(t)
                            }
                        };
                    t.addEventListener("pointerenter", s => {
                        if ("touch" === s.pointerType || (0, t$.isDragActive)()) return;
                        r = !1;
                        let o = e(t, s);
                        "function" == typeof o && (i = o, t.addEventListener("pointerleave", l, n))
                    }, n), t.addEventListener("pointerdown", () => {
                        s = !0, window.addEventListener("pointerup", a, n), window.addEventListener("pointercancel", a, n)
                    }, n)
                }), r
            }(t, (t, e) => (tK(this.node, e, "Start"), t => tK(this.node, t, "End"))))
        }
        unmount() {}
    }
    t.s(["HoverGesture", 0, tY], 957512);
    var tX = tW,
        tq = t.i(738638);
    class t_ extends tX.Feature {
        constructor() {
            super(...arguments), this.isActive = !1
        }
        onFocus() {
            let t = !1;
            try {
                t = this.node.current.matches(":focus-visible")
            } catch (e) {
                t = !0
            }
            t && this.node.animationState && (this.node.animationState.setActive("whileFocus", !0), this.isActive = !0)
        }
        onBlur() {
            this.isActive && this.node.animationState && (this.node.animationState.setActive("whileFocus", !1), this.isActive = !1)
        }
        mount() {
            this.unmount = (0, tq.pipe)((0, tj.addDomEvent)(this.node.current, "focus", () => this.onFocus()), (0, tj.addDomEvent)(this.node.current, "blur", () => this.onBlur()))
        }
        unmount() {}
    }
    t.s(["FocusGesture", 0, t_], 99642)
}, 772846, t => {
    "use strict";
    var e = t.i(642824);
    t.s(["isHTMLElement", 0, function(t) {
        return (0, e.isObject)(t) && "offsetHeight" in t && !("ownerSVGElement" in t)
    }])
}, 846932, t => {
    "use strict";
    var e = t.i(154505),
        i = t.i(907051),
        s = t.i(223070),
        n = t.i(646816),
        r = t.i(957512),
        o = t.i(99642),
        a = t.i(142098),
        l = t.i(772846),
        h = t.i(439676);
    let u = (t, e) => !!e && (t === e || u(t, e.parentElement));
    var c = t.i(341327),
        d = t.i(973089),
        m = t.i(919880);
    let p = new WeakSet;

    function f(t) {
        return e => {
            "Enter" === e.key && t(e)
        }
    }

    function g(t, e) {
        t.dispatchEvent(new PointerEvent("pointer" + e, {
            isPrimary: !0,
            bubbles: !0
        }))
    }

    function v(t) {
        return (0, c.isPrimaryPointer)(t) && !(0, h.isDragActive)()
    }
    let y = new WeakSet;
    var x = t.i(287022),
        T = t.i(665536);

    function w(t, e, i) {
        let {
            props: s
        } = t;
        if (t.current instanceof HTMLButtonElement && t.current.disabled) return;
        t.animationState && s.whileTap && t.animationState.setActive("whileTap", "Start" === i);
        let n = s["onTap" + ("End" === i ? "" : i)];
        n && x.frame.postRender(() => n(e, (0, T.extractEventInfo)(e)))
    }
    class b extends a.Feature {
        mount() {
            let {
                current: t
            } = this.node;
            if (!t) return;
            let {
                globalTapTarget: e,
                propagate: i
            } = this.node.props;
            this.unmount = function(t, e, i = {}) {
                let [s, n, r] = (0, d.setupGesture)(t, i), o = t => {
                    let s = t.currentTarget;
                    if (!v(t) || y.has(t)) return;
                    p.add(s), i.stopPropagation && y.add(t);
                    let r = e(s, t),
                        o = { ...n,
                            capture: !0
                        },
                        a = (t, e) => {
                            window.removeEventListener("pointerup", l, o), window.removeEventListener("pointercancel", h, o), p.has(s) && p.delete(s), v(t) && "function" == typeof r && r(t, {
                                success: e
                            })
                        },
                        l = t => {
                            a(t, s === window || s === document || i.useGlobalTarget || u(s, t.target))
                        },
                        h = t => {
                            a(t, !1)
                        };
                    window.addEventListener("pointerup", l, o), window.addEventListener("pointercancel", h, o)
                };
                return s.forEach(t => {
                    (i.useGlobalTarget ? window : t).addEventListener("pointerdown", o, n), (0, l.isHTMLElement)(t) && (t.addEventListener("focus", t => ((t, e) => {
                        let i = t.currentTarget;
                        if (!i) return;
                        let s = f(() => {
                            if (p.has(i)) return;
                            g(i, "down");
                            let t = f(() => {
                                g(i, "up")
                            });
                            i.addEventListener("keyup", t, e), i.addEventListener("blur", () => g(i, "cancel"), e)
                        });
                        i.addEventListener("keydown", s, e), i.addEventListener("blur", () => i.removeEventListener("keydown", s), e)
                    })(t, n)), (0, m.isElementKeyboardAccessible)(t) || t.hasAttribute("tabindex") || (t.tabIndex = 0))
                }), r
            }(t, (t, e) => (w(this.node, e, "Start"), (t, {
                success: e
            }) => w(this.node, t, e ? "End" : "Cancel")), {
                useGlobalTarget: e,
                stopPropagation: i ? .tap === !1
            })
        }
        unmount() {}
    }
    var S = a;
    let P = new WeakMap,
        M = new WeakMap,
        A = t => {
            let e = P.get(t.target);
            e && e(t)
        },
        V = t => {
            t.forEach(A)
        },
        E = {
            some: 0,
            all: 1
        };
    class C extends S.Feature {
        constructor() {
            super(...arguments), this.hasEnteredView = !1, this.isInView = !1
        }
        startObserver() {
            var t;
            let e;
            this.stopObserver ? .();
            let {
                viewport: i = {}
            } = this.node.getProps(), {
                root: s,
                margin: n,
                amount: r = "some",
                once: o
            } = i, a = {
                root: s ? s.current : void 0,
                rootMargin: n,
                threshold: "number" == typeof r ? r : E[r]
            }, l = t => {
                let {
                    isIntersecting: e
                } = t;
                if (this.isInView === e || (this.isInView = e, o && !e && this.hasEnteredView)) return;
                e && (this.hasEnteredView = !0), this.node.animationState && this.node.animationState.setActive("whileInView", e);
                let {
                    onViewportEnter: i,
                    onViewportLeave: s
                } = this.node.getProps(), n = e ? i : s;
                n && n(t)
            };
            this.stopObserver = (t = this.node.current, e = function({
                root: t,
                ...e
            }) {
                let i = t || document;
                M.has(i) || M.set(i, {});
                let s = M.get(i),
                    n = JSON.stringify(e);
                return s[n] || (s[n] = new IntersectionObserver(V, {
                    root: t,
                    ...e
                })), s[n]
            }(a), P.set(t, l), e.observe(t), () => {
                P.delete(t), e.unobserve(t)
            })
        }
        mount() {
            this.startObserver()
        }
        update() {
            if ("u" < typeof IntersectionObserver) return;
            let {
                props: t,
                prevProps: e
            } = this.node;
            ["amount", "margin", "root"].some(function({
                viewport: t = {}
            }, {
                viewport: e = {}
            } = {}) {
                return i => t[i] !== e[i]
            }(t, e)) && this.startObserver()
        }
        unmount() {
            this.stopObserver ? .(), this.hasEnteredView = !1, this.isInView = !1
        }
    }
    let D = {
        inView: {
            Feature: C
        },
        tap: {
            Feature: b
        },
        focus: {
            Feature: o.FocusGesture
        },
        hover: {
            Feature: r.HoverGesture
        }
    };
    var k = t.i(717871),
        R = t.i(877397);
    let L = {
            layout: {
                ProjectionNode: k.HTMLProjectionNode,
                MeasureLayout: R.MeasureLayout
            }
        },
        B = { ...s.animations,
            ...D,
            ...n.drag,
            ...L
        },
        F = (0, i.createMotionProxy)(B, e.createDomVisualElement);
    t.s(["motion", 0, F], 846932)
}]);