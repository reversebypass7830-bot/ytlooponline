(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 540886, 838452, e => {
    "use strict";
    e.i(247167);
    var t = e.i(271645),
        r = e.i(229315),
        n = e.i(667865),
        o = e.i(146376),
        u = e.i(176782),
        a = e.i(733332);
    let l = t.createContext(void 0);

    function i(e = !1) {
        let r = t.useContext(l);
        if (void 0 === r && !e) throw Error((0, a.default)(16));
        return r
    }

    function c(e) {
        return (0, r.isHTMLElement)(e) && "BUTTON" === e.tagName
    }
    e.s(["CompositeRootContext", 0, l, "useCompositeRootContext", 0, i], 838452), e.s(["useButton", 0, function(e = {}) {
        let {
            disabled: r = !1,
            focusableWhenDisabled: a,
            tabIndex: l = 0,
            native: s = !0,
            composite: f
        } = e, p = t.useRef(null), d = i(!0), h = f ? ? void 0 !== d, {
            props: y
        } = function(e) {
            let {
                focusableWhenDisabled: r,
                disabled: n,
                composite: o = !1,
                tabIndex: u = 0,
                isNativeButton: a
            } = e, l = o && !1 !== r, i = o && !1 === r;
            return {
                props: t.useMemo(() => {
                    let e = {
                        onKeyDown(e) {
                            n && r && "Tab" !== e.key && e.preventDefault()
                        }
                    };
                    return o || (e.tabIndex = u, !a && n && (e.tabIndex = r ? u : -1)), (a && (r || l) || !a && n) && (e["aria-disabled"] = n), a && (!r || i) && (e.disabled = n), e
                }, [o, n, r, l, i, a, u])
            }
        }({
            focusableWhenDisabled: a,
            disabled: r,
            composite: h,
            tabIndex: l,
            isNativeButton: s
        }), b = t.useCallback(() => {
            let e = p.current;
            c(e) && h && r && void 0 === y.disabled && e.disabled && (e.disabled = !1)
        }, [r, y.disabled, h]);
        return (0, o.useIsoLayoutEffect)(b, [b]), {
            getButtonProps: t.useCallback((e = {}) => {
                let {
                    onClick: t,
                    onMouseDown: n,
                    onKeyUp: o,
                    onKeyDown: a,
                    onPointerDown: l,
                    ...i
                } = e;
                return (0, u.mergeProps)({
                    onClick(e) {
                        r ? e.preventDefault() : t ? .(e)
                    },
                    onMouseDown(e) {
                        r || n ? .(e)
                    },
                    onKeyDown(e) {
                        var n;
                        if (r || ((0, u.makeEventPreventable)(e), a ? .(e), e.baseUIHandlerPrevented)) return;
                        let o = e.target === e.currentTarget,
                            l = e.currentTarget,
                            i = c(l),
                            f = !s && (n = l, !!(n ? .tagName === "A" && n ? .href)),
                            p = o && (s ? i : !f),
                            d = "Enter" === e.key,
                            y = " " === e.key,
                            b = l.getAttribute("role"),
                            v = b ? .startsWith("menuitem") || "option" === b || "gridcell" === b;
                        if (o && h && y) {
                            if (e.defaultPrevented && v) return;
                            e.preventDefault(), f || s && i ? (l.click(), e.preventBaseUIHandler()) : p && (t ? .(e), e.preventBaseUIHandler());
                            return
                        }
                        p && (!s && (y || d) && e.preventDefault(), !s && d && t ? .(e))
                    },
                    onKeyUp(e) {
                        r || (((0, u.makeEventPreventable)(e), o ? .(e), e.target === e.currentTarget && s && h && c(e.currentTarget) && " " === e.key) ? e.preventDefault() : !e.baseUIHandlerPrevented && (e.target !== e.currentTarget || s || h || " " !== e.key || t ? .(e)))
                    },
                    onPointerDown(e) {
                        r ? e.preventDefault() : l ? .(e)
                    }
                }, s ? {
                    type: "button"
                } : {
                    role: "button"
                }, y, i)
            }, [r, y, h, s]),
            buttonRef: (0, n.useStableCallback)(e => {
                p.current = e, b()
            })
        }
    }], 540886)
}, 527930, e => {
    "use strict";
    var t = e.i(271645),
        r = e.i(540886),
        n = e.i(552245);
    let o = t.forwardRef(function(e, t) {
        let {
            render: o,
            className: u,
            disabled: a = !1,
            focusableWhenDisabled: l = !1,
            nativeButton: i = !0,
            style: c,
            ...s
        } = e, {
            getButtonProps: f,
            buttonRef: p
        } = (0, r.useButton)({
            disabled: a,
            focusableWhenDisabled: l,
            native: i
        });
        return (0, n.useRenderElement)("button", e, {
            state: {
                disabled: a
            },
            ref: [t, p],
            props: [s, f]
        })
    });
    e.s(["Button", 0, o])
}, 818581, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "useMergedRef", {
        enumerable: !0,
        get: function() {
            return o
        }
    });
    let n = e.r(271645);

    function o(e, t) {
        let r = (0, n.useRef)(null),
            o = (0, n.useRef)(null);
        return (0, n.useCallback)(n => {
            if (null === n) {
                let e = r.current;
                e && (r.current = null, e());
                let t = o.current;
                t && (o.current = null, t())
            } else e && (r.current = u(e, n)), t && (o.current = u(t, n))
        }, [e, t])
    }

    function u(e, t) {
        if ("function" != typeof e) return e.current = t, () => {
            e.current = null
        }; {
            let r = e(t);
            return "function" == typeof r ? r : () => e(null)
        }
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 195057, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        formatUrl: function() {
            return l
        },
        formatWithValidation: function() {
            return c
        },
        urlObjectKeys: function() {
            return i
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let u = e.r(190809)._(e.r(998183)),
        a = /https?|ftp|gopher|file/;

    function l(e) {
        let {
            auth: t,
            hostname: r
        } = e, n = e.protocol || "", o = e.pathname || "", l = e.hash || "", i = e.query || "", c = !1;
        t = t ? encodeURIComponent(t).replace(/%3A/i, ":") + "@" : "", e.host ? c = t + e.host : r && (c = t + (~r.indexOf(":") ? `[${r}]` : r), e.port && (c += ":" + e.port)), i && "object" == typeof i && (i = String(u.urlQueryToSearchParams(i)));
        let s = e.search || i && `?${i}` || "";
        return n && !n.endsWith(":") && (n += ":"), e.slashes || (!n || a.test(n)) && !1 !== c ? (c = "//" + (c || ""), o && "/" !== o[0] && (o = "/" + o)) : c || (c = ""), l && "#" !== l[0] && (l = "#" + l), s && "?" !== s[0] && (s = "?" + s), o = o.replace(/[?#]/g, encodeURIComponent), s = s.replace("#", "%23"), `${n}${c}${o}${s}${l}`
    }
    let i = ["auth", "hash", "host", "hostname", "href", "path", "pathname", "port", "protocol", "query", "search", "slashes"];

    function c(e) {
        return l(e)
    }
}, 573668, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "isLocalURL", {
        enumerable: !0,
        get: function() {
            return u
        }
    });
    let n = e.r(718967),
        o = e.r(652817);

    function u(e) {
        if (!(0, n.isAbsoluteUrl)(e)) return !0;
        try {
            let t = (0, n.getLocationOrigin)(),
                r = new URL(e, t);
            return r.origin === t && (0, o.hasBasePath)(r.pathname)
        } catch (e) {
            return !1
        }
    }
}, 284508, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "errorOnce", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = e => {}
}, 522016, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        default: function() {
            return v
        },
        useLinkStatus: function() {
            return m
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let u = e.r(190809),
        a = e.r(843476),
        l = u._(e.r(271645)),
        i = e.r(195057),
        c = e.r(8372),
        s = e.r(818581),
        f = e.r(718967),
        p = e.r(405550);
    e.r(233525);
    let d = e.r(388540),
        h = e.r(91949),
        y = e.r(573668),
        b = e.r(509396);

    function v(t) {
        var r, n;
        let o, u, v, [m, P] = (0, l.useOptimistic)(h.IDLE_LINK_STATUS),
            C = (0, l.useRef)(null),
            {
                href: T,
                as: _,
                children: O,
                prefetch: R = null,
                passHref: j,
                replace: k,
                shallow: E,
                scroll: S,
                onClick: U,
                onMouseEnter: D,
                onTouchStart: M,
                legacyBehavior: I = !1,
                onNavigate: w,
                transitionTypes: x,
                ref: L,
                unstable_dynamicOnHover: B,
                ...K
            } = t;
        o = O, I && ("string" == typeof o || "number" == typeof o) && (o = (0, a.jsx)("a", {
            children: o
        }));
        let A = l.default.useContext(c.AppRouterContext),
            N = !1 !== R,
            $ = !1 !== R ? null === (n = R) || "auto" === n ? b.FetchStrategy.PPR : b.FetchStrategy.Full : b.FetchStrategy.PPR,
            F = "string" == typeof(r = _ || T) ? r : (0, i.formatUrl)(r);
        if (I) {
            if (o ? .$$typeof === Symbol.for("react.lazy")) throw Object.defineProperty(Error("`<Link legacyBehavior>` received a direct child that is either a Server Component, or JSX that was loaded with React.lazy(). This is not supported. Either remove legacyBehavior, or make the direct child a Client Component that renders the Link's `<a>` tag."), "__NEXT_ERROR_CODE", {
                value: "E863",
                enumerable: !1,
                configurable: !0
            });
            u = l.default.Children.only(o)
        }
        let H = I ? u && "object" == typeof u && u.ref : L,
            W = l.default.useCallback(e => (null !== A && (C.current = (0, h.mountLinkInstance)(e, F, A, $, N, P)), () => {
                C.current && ((0, h.unmountLinkForCurrentNavigation)(C.current), C.current = null), (0, h.unmountPrefetchableInstance)(e)
            }), [N, F, A, $, P]),
            q = {
                ref: (0, s.useMergedRef)(W, H),
                onClick(t) {
                    I || "function" != typeof U || U(t), I && u.props && "function" == typeof u.props.onClick && u.props.onClick(t), !A || t.defaultPrevented || function(t, r, n, o, u, a, i) {
                        if ("u" > typeof window) {
                            let c, {
                                nodeName: s
                            } = t.currentTarget;
                            if ("A" === s.toUpperCase() && ((c = t.currentTarget.getAttribute("target")) && "_self" !== c || t.metaKey || t.ctrlKey || t.shiftKey || t.altKey || t.nativeEvent && 2 === t.nativeEvent.which) || t.currentTarget.hasAttribute("download")) return;
                            if (!(0, y.isLocalURL)(r)) {
                                o && (t.preventDefault(), location.replace(r));
                                return
                            }
                            if (t.preventDefault(), a) {
                                let e = !1;
                                if (a({
                                        preventDefault: () => {
                                            e = !0
                                        }
                                    }), e) return
                            }
                            let {
                                dispatchNavigateAction: f
                            } = e.r(699781);
                            l.default.startTransition(() => {
                                f(r, o ? "replace" : "push", !1 === u ? d.ScrollBehavior.NoScroll : d.ScrollBehavior.Default, n.current, i)
                            })
                        }
                    }(t, F, C, k, S, w, x)
                },
                onMouseEnter(e) {
                    I || "function" != typeof D || D(e), I && u.props && "function" == typeof u.props.onMouseEnter && u.props.onMouseEnter(e), A && N && (0, h.onNavigationIntent)(e.currentTarget, !0 === B)
                },
                onTouchStart: function(e) {
                    I || "function" != typeof M || M(e), I && u.props && "function" == typeof u.props.onTouchStart && u.props.onTouchStart(e), A && N && (0, h.onNavigationIntent)(e.currentTarget, !0 === B)
                }
            };
        return (0, f.isAbsoluteUrl)(F) ? q.href = F : I && !j && ("a" !== u.type || "href" in u.props) || (q.href = (0, p.addBasePath)(F)), v = I ? l.default.cloneElement(u, q) : (0, a.jsx)("a", { ...K,
            ...q,
            children: o
        }), (0, a.jsx)(g.Provider, {
            value: m,
            children: v
        })
    }
    e.r(284508);
    let g = (0, l.createContext)(h.IDLE_LINK_STATUS),
        m = () => (0, l.useContext)(g);
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}]);