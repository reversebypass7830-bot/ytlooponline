(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 395530, e => {
    "use strict";
    var t = e.i(271645),
        n = e.i(828918),
        i = e.i(838452),
        a = e.i(673553);
    e.s(["useCompositeItem", 0, function(e = {}) {
        let {
            highlightItemOnHover: r,
            highlightedIndex: o,
            onHighlightedIndexChange: l
        } = (0, i.useCompositeRootContext)(), {
            ref: u,
            index: s
        } = (0, a.useCompositeListItem)(e), c = o === s, d = t.useRef(null), f = (0, n.useMergedRefs)(u, d);
        return {
            compositeProps: {
                tabIndex: c ? 0 : -1,
                onFocus() {
                    l(s)
                },
                onMouseMove() {
                    let e = d.current;
                    if (!r || !e) return;
                    let t = e.hasAttribute("disabled") || "true" === e.ariaDisabled;
                    c || t || e.focus()
                }
            },
            compositeRef: f,
            index: s
        }
    }])
}, 677572, 405934, e => {
    "use strict";
    var t, n, i, a = e.i(843476);
    e.s([], 559657), e.i(559657), e.i(247167);
    var r = e.i(271645),
        o = e.i(951437),
        l = e.i(146376),
        u = e.i(667865),
        s = e.i(552245),
        c = e.i(53687),
        d = e.i(733332);
    let f = r.createContext(void 0);

    function b() {
        let e = r.useContext(f);
        if (void 0 === e) throw Error((0, d.default)(64));
        return e
    }
    let v = ((t = {}).activationDirection = "data-activation-direction", t.orientation = "data-orientation", t),
        p = {
            tabActivationDirection: e => ({
                [v.activationDirection]: e
            })
        };
    var g = e.i(675606),
        h = e.i(56434);
    let R = r.forwardRef(function(e, t) {
        let {
            className: n,
            defaultValue: i = 0,
            onValueChange: d,
            orientation: b = "horizontal",
            render: v,
            value: R,
            style: x,
            ...S
        } = e, C = void 0 !== e.defaultValue, E = r.useRef([]), [y, T] = r.useState(() => new Map), [I, A] = (0, o.useControlled)({
            controlled: R,
            default: i,
            name: "Tabs",
            state: "value"
        }), O = void 0 !== R, [L, M] = r.useState(() => new Map), k = r.useRef(void 0), w = r.useCallback(e => {
            if (void 0 === e) return null;
            for (let [t, n] of L.entries())
                if (null != n && e === (n.value ? ? n.index)) return t;
            return null
        }, [L]), [D, N] = r.useState(() => ({
            previousValue: I,
            tabActivationDirection: "none"
        })), {
            previousValue: _,
            tabActivationDirection: W
        } = D, P = W, z = !1;
        _ !== I && (P = m(_, I, b, L), z = null != _ && null != I && null == w(I));
        let H = z ? _ : I,
            B = _ !== H || W !== P;
        (0, l.useIsoLayoutEffect)(() => {
            B && N({
                previousValue: H,
                tabActivationDirection: P
            })
        }, [H, B, P]);
        let j = (0, u.useStableCallback)((e, t) => {
                t.activationDirection = m(I, e, b, L), d ? .(e, t), t.isCanceled || A(e)
            }),
            Y = (0, u.useStableCallback)((e, t) => {
                d ? .(e, (0, g.createChangeEventDetails)(t, void 0, void 0, {
                    activationDirection: "none"
                }))
            }),
            K = (0, u.useStableCallback)((e, t) => {
                T(n => {
                    if (n.get(e) === t) return n;
                    let i = new Map(n);
                    return i.set(e, t), i
                })
            }),
            V = (0, u.useStableCallback)((e, t) => {
                T(n => {
                    if (!n.has(e) || n.get(e) !== t) return n;
                    let i = new Map(n);
                    return i.delete(e), i
                })
            }),
            F = r.useCallback(e => y.get(e), [y]),
            $ = r.useCallback(e => {
                for (let t of L.values())
                    if (e === t ? .value) return t ? .id
            }, [L]),
            U = r.useMemo(() => ({
                getTabElementBySelectedValue: w,
                getTabIdByPanelValue: $,
                getTabPanelIdByValue: F,
                onValueChange: j,
                orientation: b,
                registerMountedTabPanel: K,
                setTabMap: M,
                unregisterMountedTabPanel: V,
                tabActivationDirection: P,
                value: I
            }), [w, $, F, j, b, K, M, V, P, I]),
            q = r.useMemo(() => {
                for (let e of L.values())
                    if (null != e && e.value === I) return e
            }, [L, I]),
            G = r.useMemo(() => {
                for (let e of L.values())
                    if (null != e && !e.disabled) return e.value
            }, [L]),
            X = r.useRef(!C),
            Z = r.useRef(i),
            J = r.useRef(C),
            Q = r.useRef(!1);
        (0, l.useIsoLayoutEffect)(() => {
            if (O) return;

            function e(e, t) {
                A(e), N(t => t.previousValue === e && "none" === t.tabActivationDirection ? t : {
                    previousValue: e,
                    tabActivationDirection: "none"
                }), Y(e, t), X.current = !1
            }
            if (0 === L.size) {
                Q.current && null !== I && !k.current ? .isConnected && e(null, h.REASONS.missing);
                return
            }
            Q.current = !0, k.current = L.keys().next().value;
            let t = q ? .disabled,
                n = null == q && null !== I;
            if (t || I !== Z.current || (J.current = !1), J.current && t && I === Z.current) return;
            let i = X.current;
            if (t || n) {
                let n = G ? ? null;
                if (I === n) {
                    X.current = !1;
                    return
                }
                let a = h.REASONS.missing;
                i ? a = h.REASONS.initial : t && (a = h.REASONS.disabled), e(n, a);
                return
            }
            i && null != q && (Y(I, h.REASONS.initial), X.current = !1)
        }, [G, O, Y, q, A, L, I]);
        let ee = {
                orientation: b,
                tabActivationDirection: P
            },
            et = (0, s.useRenderElement)("div", e, {
                state: ee,
                ref: t,
                props: S,
                stateAttributesMapping: p
            });
        return (0, a.jsx)(f.Provider, {
            value: U,
            children: (0, a.jsx)(c.CompositeList, {
                elementsRef: E,
                children: et
            })
        })
    });

    function m(e, t, n, i) {
        if (null == e || null == t) return "none";
        let a = null,
            r = null;
        for (let [n, o] of i.entries()) {
            if (null == o) continue;
            let i = o.value ? ? o.index;
            if (e === i && (a = n), t === i && (r = n), null != a && null != r) break
        }
        if (null == a || null == r) return a !== r && ("number" == typeof e || "string" == typeof e) && typeof e == typeof t ? "horizontal" === n ? t > e ? "right" : "left" : t > e ? "down" : "up" : "none";
        let o = a.getBoundingClientRect(),
            l = r.getBoundingClientRect();
        if ("horizontal" === n) {
            if (l.left < o.left) return "left";
            if (l.left > o.left) return "right"
        } else {
            if (l.top < o.top) return "up";
            if (l.top > o.top) return "down"
        }
        return "none"
    }
    var x = e.i(108868),
        S = e.i(788015),
        C = e.i(540886);
    let E = "data-composite-item-active";
    var y = e.i(395530);
    let T = r.createContext(void 0);

    function I() {
        let e = r.useContext(T);
        if (void 0 === e) throw Error((0, d.default)(65));
        return e
    }
    var A = e.i(647554);
    let O = r.forwardRef(function(e, t) {
        let {
            className: n,
            disabled: i = !1,
            render: a,
            value: o,
            id: u,
            nativeButton: c = !0,
            style: d,
            ...f
        } = e, {
            value: v,
            getTabPanelIdByValue: R,
            orientation: m,
            tabActivationDirection: T
        } = b(), {
            activateOnFocus: O,
            highlightedTabIndex: L,
            onTabActivation: M,
            registerTabResizeObserverElement: k,
            setHighlightedTabIndex: w,
            tabsListElement: D
        } = I(), N = (0, S.useBaseUiId)(u), _ = r.useMemo(() => ({
            disabled: i,
            id: N,
            value: o
        }), [i, N, o]), {
            compositeProps: W,
            compositeRef: P,
            index: z
        } = (0, y.useCompositeItem)({
            metadata: _
        }), H = o === v, B = r.useRef(!1), j = r.useRef(null);
        (0, l.useIsoLayoutEffect)(() => {
            let e = j.current;
            if (e) return k(e)
        }, [k]), (0, l.useIsoLayoutEffect)(() => {
            if (B.current) {
                B.current = !1;
                return
            }
            if (H && z > -1 && L !== z) {
                if (null != D) {
                    let e = (0, A.activeElement)((0, x.ownerDocument)(D));
                    if (e && (0, A.contains)(D, e)) return
                }
                i || w(z)
            }
        }, [H, z, L, w, i, D]);
        let {
            getButtonProps: Y,
            buttonRef: K
        } = (0, C.useButton)({
            disabled: i,
            native: c,
            focusableWhenDisabled: !0
        }), V = R(o), F = r.useRef(!1), $ = r.useRef(!1);
        return (0, s.useRenderElement)("button", e, {
            state: {
                disabled: i,
                active: H,
                orientation: m,
                tabActivationDirection: T
            },
            ref: [t, K, P, j],
            props: [W, {
                role: "tab",
                "aria-controls": V,
                "aria-selected": H,
                id: N,
                onClick: function(e) {
                    H || i || M(o, (0, g.createChangeEventDetails)(h.REASONS.none, e.nativeEvent, void 0, {
                        activationDirection: "none"
                    }))
                },
                onFocus: function(e) {
                    H || (z > -1 && !i && w(z), !i && O && (!F.current || F.current && $.current) && M(o, (0, g.createChangeEventDetails)(h.REASONS.none, e.nativeEvent, void 0, {
                        activationDirection: "none"
                    })))
                },
                onPointerDown: function(e) {
                    H || i || (F.current = !0, e.button && 0 !== e.button || ($.current = !0, (0, x.ownerDocument)(e.currentTarget).addEventListener("pointerup", function() {
                        F.current = !1, $.current = !1
                    }, {
                        once: !0
                    })))
                },
                [E]: H ? "" : void 0,
                onKeyDownCapture() {
                    B.current = !0
                }
            }, f, Y],
            stateAttributesMapping: p
        })
    });
    var L = e.i(73364),
        M = e.i(802239),
        k = e.i(956789);

    function w() {
        return k.NOOP
    }

    function D() {
        return !1
    }

    function N() {
        return !0
    }
    let _ = ((n = {}).activeTabLeft = "--active-tab-left", n.activeTabRight = "--active-tab-right", n.activeTabTop = "--active-tab-top", n.activeTabBottom = "--active-tab-bottom", n.activeTabWidth = "--active-tab-width", n.activeTabHeight = "--active-tab-height", n);
    var W = e.i(172410);
    let P = { ...p,
            activeTabPosition: () => null,
            activeTabSize: () => null
        },
        z = r.forwardRef(function(e, t) {
            let {
                className: n,
                render: i,
                renderBeforeHydration: o = !1,
                style: l,
                ...u
            } = e, {
                nonce: c
            } = (0, W.useCSPContext)(), {
                getTabElementBySelectedValue: d,
                orientation: f,
                tabActivationDirection: v,
                value: p
            } = b(), {
                tabsListElement: g,
                registerIndicatorUpdateListener: h
            } = I(), R = (0, M.useSyncExternalStore)(w, D, N), m = function() {
                let [, e] = r.useState({});
                return r.useCallback(() => {
                    e({})
                }, [])
            }();
            r.useEffect(() => h(m), [h, m]);
            let x = 0,
                S = 0,
                C = 0,
                E = 0,
                y = 0,
                T = 0,
                A = !1;
            if (null != p && null != g) {
                let e = d(p);
                if (null != e) {
                    A = !0;
                    let {
                        width: t,
                        height: n
                    } = (0, L.getCssDimensions)(e), {
                        width: i,
                        height: a
                    } = (0, L.getCssDimensions)(g), r = e.getBoundingClientRect(), o = g.getBoundingClientRect(), l = i > 0 ? o.width / i : 1, u = a > 0 ? o.height / a : 1;
                    if (Math.abs(l) > Number.EPSILON && Math.abs(u) > Number.EPSILON) {
                        let e = r.left - o.left,
                            t = r.top - o.top;
                        x = e / l + g.scrollLeft - g.clientLeft, C = t / u + g.scrollTop - g.clientTop
                    } else x = e.offsetLeft, C = e.offsetTop;
                    y = t, T = n, S = g.scrollWidth - x - y, E = g.scrollHeight - C - T
                }
            }
            let O = A ? {
                    left: x,
                    right: S,
                    top: C,
                    bottom: E
                } : null,
                k = A ? {
                    width: y,
                    height: T
                } : null,
                z = A ? {
                    [_.activeTabLeft]: `${x}px`,
                    [_.activeTabRight]: `${S}px`,
                    [_.activeTabTop]: `${C}px`,
                    [_.activeTabBottom]: `${E}px`,
                    [_.activeTabWidth]: `${y}px`,
                    [_.activeTabHeight]: `${T}px`
                } : void 0,
                H = A && y > 0 && T > 0,
                B = (0, s.useRenderElement)("span", e, {
                    state: {
                        orientation: f,
                        activeTabPosition: O,
                        activeTabSize: k,
                        tabActivationDirection: v
                    },
                    ref: t,
                    props: [{
                        role: "presentation",
                        style: z,
                        hidden: !H
                    }, u, {
                        suppressHydrationWarning: !0
                    }],
                    stateAttributesMapping: P
                });
            return null == p ? null : (0, a.jsxs)(r.Fragment, {
                children: [B, R && o && (0, a.jsx)("script", {
                    nonce: c,
                    dangerouslySetInnerHTML: {
                        __html: '!function(){const t=document.currentScript.previousElementSibling;if(!t)return;const e=t.closest(\'[role="tablist"]\');if(!e)return;const i=e.querySelector("[data-active]");if(!i)return;if(0===i.offsetWidth||0===e.offsetWidth)return;let o=0,n=0,h=0,l=0,r=0,f=0;function s(t){const e=getComputedStyle(t);let i=parseFloat(e.width)||0,o=parseFloat(e.height)||0;return(Math.round(i)!==t.offsetWidth||Math.round(o)!==t.offsetHeight)&&(i=t.offsetWidth,o=t.offsetHeight),{width:i,height:o}}if(null!=i&&null!=e){const{width:t,height:c}=s(i),{width:u,height:d}=s(e),a=i.getBoundingClientRect(),g=e.getBoundingClientRect(),p=u>0?g.width/u:1,b=d>0?g.height/d:1;if(Math.abs(p)>Number.EPSILON&&Math.abs(b)>Number.EPSILON){const t=a.left-g.left,i=a.top-g.top;o=t/p+e.scrollLeft-e.clientLeft,h=i/b+e.scrollTop-e.clientTop}else o=i.offsetLeft,h=i.offsetTop;r=t,f=c,n=e.scrollWidth-o-r,l=e.scrollHeight-h-f}function c(e,i){t.style.setProperty(`--active-tab-${e}`,`${i}px`)}c("left",o),c("right",n),c("top",h),c("bottom",l),c("width",r),c("height",f),r>0&&f>0&&t.removeAttribute("hidden")}();'
                    },
                    suppressHydrationWarning: !0
                })]
            })
        });
    var H = e.i(144394),
        B = e.i(209407),
        j = e.i(137584),
        Y = e.i(223910),
        K = e.i(673553);
    let V = ((i = {}).index = "data-index", i.activationDirection = "data-activation-direction", i.orientation = "data-orientation", i.hidden = "data-hidden", i[i.startingStyle = B.TransitionStatusDataAttributes.startingStyle] = "startingStyle", i[i.endingStyle = B.TransitionStatusDataAttributes.endingStyle] = "endingStyle", i),
        F = { ...p,
            ...B.transitionStatusMapping
        },
        $ = r.forwardRef(function(e, t) {
            let {
                className: n,
                value: i,
                render: a,
                keepMounted: o = !1,
                style: u,
                ...c
            } = e, {
                value: d,
                getTabIdByPanelValue: f,
                orientation: v,
                tabActivationDirection: p,
                registerMountedTabPanel: g,
                unregisterMountedTabPanel: h
            } = b(), R = (0, S.useBaseUiId)(), m = r.useMemo(() => ({
                id: R,
                value: i
            }), [R, i]), {
                ref: x,
                index: C
            } = (0, K.useCompositeListItem)({
                metadata: m
            }), E = i === d, {
                mounted: y,
                transitionStatus: T,
                setMounted: I
            } = (0, Y.useTransitionStatus)(E), A = !y, O = f(i), L = r.useRef(null), M = (0, s.useRenderElement)("div", e, {
                state: {
                    hidden: A,
                    orientation: v,
                    tabActivationDirection: p,
                    transitionStatus: T
                },
                ref: [t, x, L],
                props: [{
                    "aria-labelledby": O,
                    hidden: A,
                    id: R,
                    role: "tabpanel",
                    tabIndex: E ? 0 : -1,
                    inert: (0, H.inertValue)(!E),
                    [V.index]: C
                }, c],
                stateAttributesMapping: F
            });
            return ((0, j.useOpenChangeComplete)({
                open: E,
                ref: L,
                onComplete() {
                    E || I(!1)
                }
            }), (0, l.useIsoLayoutEffect)(() => {
                if ((!A || o) && null != R) return g(i, R), () => {
                    h(i, R)
                }
            }, [A, o, i, R, g, h]), o || y) ? M : null
        });
    var U = e.i(590803),
        q = e.i(828918),
        G = e.i(673327),
        X = e.i(621082);
    let Z = [];
    var J = e.i(838452),
        Q = e.i(872855);

    function ee(e) {
        let {
            render: t,
            className: n,
            style: i,
            refs: o = k.EMPTY_ARRAY,
            props: d = k.EMPTY_ARRAY,
            state: f = k.EMPTY_OBJECT,
            stateAttributesMapping: b,
            highlightedIndex: v,
            onHighlightedIndexChange: p,
            orientation: g,
            grid: h,
            loopFocus: R,
            onLoop: m,
            enableHomeAndEndKeys: x,
            onMapChange: S,
            stopEventPropagation: C = !0,
            rootRef: y,
            disabledIndices: T,
            modifierKeys: I,
            highlightItemOnHover: O = !1,
            tag: L = "div",
            ...M
        } = e, {
            props: w,
            highlightedIndex: D,
            onHighlightedIndexChange: N,
            elementsRef: _,
            onMapChange: W,
            relayKeyboardEvent: P
        } = function(e) {
            let {
                loopFocus: t = !0,
                orientation: n = "both",
                grid: i,
                onLoop: a,
                direction: o,
                highlightedIndex: s,
                onHighlightedIndexChange: c,
                rootRef: d,
                enableHomeAndEndKeys: f = !1,
                stopEventPropagation: b = !1,
                disabledIndices: v,
                modifierKeys: p = Z
            } = e, [g, h] = r.useState(0), R = null != i, m = r.useRef(null), x = (0, q.useMergedRefs)(m, d), S = r.useRef([]), C = r.useRef(!1), y = s ? ? g, T = (0, u.useStableCallback)((e, t = !1) => {
                if ((c ? ? h)(e), t) {
                    let t = S.current[e];
                    (0, G.scrollIntoViewIfNeeded)(m.current, t, o, n)
                }
            }), I = (0, u.useStableCallback)(e => {
                if (0 === e.size || C.current) return;
                C.current = !0;
                let t = Array.from(e.keys()),
                    i = t.find(e => e ? .hasAttribute(E)) ? ? null,
                    a = i ? t.indexOf(i) : -1;
                if (-1 !== a) T(a);
                else if ((0, X.isListIndexDisabled)(t, y, v)) {
                    let e = (0, X.findNonDisabledListIndex)(t, {
                        disabledIndices: v
                    });
                    (0, X.isIndexOutOfListBounds)(t, e) || T(e)
                }(0, G.scrollIntoViewIfNeeded)(m.current, i, o, n)
            });
            (0, l.useIsoLayoutEffect)(() => {
                if (null == v || null != s || !C.current) return;
                let e = S.current;
                if ((0, X.isListIndexDisabled)(e, y, v)) {
                    let t = (0, X.findNonDisabledListIndex)(e, {
                        disabledIndices: v
                    });
                    (0, X.isIndexOutOfListBounds)(e, t) || T(t)
                }
            }, [v, s, y, S, T]);
            let O = (0, u.useStableCallback)((e, t, n) => a ? a(e, t, n, S) : n),
                L = (0, u.useStableCallback)(e => {
                    let r = f ? G.COMPOSITE_KEYS : G.ARROW_KEYS;
                    if (!r.has(e.key) || function(e, t) {
                            for (let n of G.MODIFIER_KEYS.values())
                                if (!t.includes(n) && e.getModifierState(n)) return !0;
                            return !1
                        }(e, p) || !m.current) return;
                    let l = "rtl" === o,
                        u = l ? G.ARROW_LEFT : G.ARROW_RIGHT,
                        s = {
                            horizontal: u,
                            vertical: G.ARROW_DOWN,
                            both: u
                        }[n],
                        c = l ? G.ARROW_RIGHT : G.ARROW_LEFT,
                        d = {
                            horizontal: c,
                            vertical: G.ARROW_UP,
                            both: c
                        }[n],
                        g = (0, A.getTarget)(e.nativeEvent);
                    if (null != g && (0, G.isNativeInput)(g) && !(0, U.isElementDisabled)(g)) {
                        let t = g.selectionStart,
                            n = g.selectionEnd,
                            i = g.value ? ? "";
                        if (null == t || e.shiftKey || t !== n || e.key !== d && t < i.length || e.key !== s && t > 0) return
                    }
                    let h = y,
                        x = (0, X.getMinListIndex)(S, v),
                        C = (0, X.getMaxListIndex)(S, v);
                    null != i && (h = i({
                        disabledIndices: v,
                        elementsRef: S,
                        event: e,
                        highlightedIndex: y,
                        loopFocus: t,
                        maxIndex: C,
                        minIndex: x,
                        onLoop: O,
                        orientation: n,
                        rtl: l
                    }));
                    let E = {
                            horizontal: [u],
                            vertical: [G.ARROW_DOWN],
                            both: [u, G.ARROW_DOWN]
                        }[n],
                        I = {
                            horizontal: [c],
                            vertical: [G.ARROW_UP],
                            both: [c, G.ARROW_UP]
                        }[n],
                        L = R ? r : ({
                            horizontal: f ? G.HORIZONTAL_KEYS_WITH_EXTRA_KEYS : G.HORIZONTAL_KEYS,
                            vertical: f ? G.VERTICAL_KEYS_WITH_EXTRA_KEYS : G.VERTICAL_KEYS,
                            both: r
                        })[n];
                    f && (e.key === G.HOME ? h = x : e.key === G.END && (h = C)), h === y && (E.includes(e.key) || I.includes(e.key)) && (t && h === C && E.includes(e.key) ? (h = x, a && (h = a(e, y, h, S))) : t && h === x && I.includes(e.key) ? (h = C, a && (h = a(e, y, h, S))) : h = (0, X.findNonDisabledListIndex)(S.current, {
                        startingIndex: h,
                        decrement: I.includes(e.key),
                        disabledIndices: v
                    })), h === y || (0, X.isIndexOutOfListBounds)(S.current, h) || (b && e.stopPropagation(), L.has(e.key) && e.preventDefault(), T(h, !0), queueMicrotask(() => {
                        S.current[h] ? .focus()
                    }))
                });
            return {
                props: {
                    ref: x,
                    onFocus(e) {
                        let t = m.current,
                            n = (0, A.getTarget)(e.nativeEvent);
                        t && null != n && (0, G.isNativeInput)(n) && n.setSelectionRange(0, n.value.length ? ? 0)
                    },
                    onKeyDown: L
                },
                highlightedIndex: y,
                onHighlightedIndexChange: T,
                elementsRef: S,
                disabledIndices: v,
                onMapChange: I,
                relayKeyboardEvent: L
            }
        }({
            grid: h,
            loopFocus: R,
            onLoop: m,
            orientation: g,
            highlightedIndex: v,
            onHighlightedIndexChange: p,
            rootRef: y,
            stopEventPropagation: C,
            enableHomeAndEndKeys: x,
            direction: (0, Q.useDirection)(),
            disabledIndices: T,
            modifierKeys: I
        }), z = (0, s.useRenderElement)(L, e, {
            state: f,
            ref: o,
            props: [w, ...d, M],
            stateAttributesMapping: b
        }), H = r.useMemo(() => ({
            highlightedIndex: D,
            onHighlightedIndexChange: N,
            highlightItemOnHover: O,
            relayKeyboardEvent: P
        }), [D, N, O, P]);
        return (0, a.jsx)(J.CompositeRootContext.Provider, {
            value: H,
            children: (0, a.jsx)(c.CompositeList, {
                elementsRef: _,
                onMapChange: e => {
                    S ? .(e), W(e)
                },
                children: z
            })
        })
    }
    e.s(["CompositeRoot", 0, ee], 405934);
    let et = r.forwardRef(function(e, t) {
        let {
            activateOnFocus: n = !1,
            className: i,
            loopFocus: o = !0,
            render: s,
            style: c,
            ...d
        } = e, {
            onValueChange: f,
            orientation: v,
            value: g,
            setTabMap: h,
            tabActivationDirection: R
        } = b(), [m, x] = r.useState(0), [S, C] = r.useState(null), E = r.useRef(new Set), y = r.useRef(new Set), I = r.useRef(null);
        (0, l.useIsoLayoutEffect)(() => {
            if ("u" < typeof ResizeObserver) return;
            let e = new ResizeObserver(() => {
                E.current.forEach(e => {
                    e()
                })
            });
            return I.current = e, S && e.observe(S), y.current.forEach(t => {
                e.observe(t)
            }), () => {
                e.disconnect(), I.current = null
            }
        }, [S]);
        let A = (0, u.useStableCallback)(e => (E.current.add(e), () => {
                E.current.delete(e)
            })),
            O = (0, u.useStableCallback)(e => (y.current.add(e), I.current ? .observe(e), () => {
                y.current.delete(e), I.current ? .unobserve(e)
            })),
            L = (0, u.useStableCallback)((e, t) => {
                e !== g && f(e, t)
            }),
            M = r.useMemo(() => ({
                activateOnFocus: n,
                highlightedTabIndex: m,
                registerIndicatorUpdateListener: A,
                registerTabResizeObserverElement: O,
                onTabActivation: L,
                setHighlightedTabIndex: x,
                tabsListElement: S
            }), [n, m, A, O, L, x, S]);
        return (0, a.jsx)(T.Provider, {
            value: M,
            children: (0, a.jsx)(ee, {
                render: s,
                className: i,
                style: c,
                state: {
                    orientation: v,
                    tabActivationDirection: R
                },
                refs: [t, C],
                props: [{
                    "aria-orientation": "vertical" === v ? "vertical" : void 0,
                    role: "tablist"
                }, d],
                stateAttributesMapping: p,
                highlightedIndex: m,
                enableHomeAndEndKeys: !0,
                loopFocus: o,
                orientation: v,
                onHighlightedIndexChange: x,
                onMapChange: h,
                disabledIndices: k.EMPTY_ARRAY
            })
        })
    });
    e.s(["Indicator", 0, z, "List", 0, et, "Panel", 0, $, "Root", 0, R, "Tab", 0, O], 69281);
    var en = e.i(69281),
        en = en,
        ei = e.i(225913),
        ea = e.i(975157);
    let er = (0, ei.cva)("group/tabs-list inline-flex w-fit items-center justify-center rounded-lg p-[3px] text-muted-foreground group-data-horizontal/tabs:h-9 group-data-vertical/tabs:h-fit group-data-vertical/tabs:flex-col data-[variant=line]:rounded-none", {
        variants: {
            variant: {
                default: "bg-muted",
                line: "gap-1 bg-transparent"
            }
        },
        defaultVariants: {
            variant: "default"
        }
    });
    e.s(["Tabs", 0, function({
        className: e,
        orientation: t = "horizontal",
        ...n
    }) {
        return (0, a.jsx)(en.Root, {
            "data-slot": "tabs",
            "data-orientation": t,
            className: (0, ea.cn)("group/tabs flex gap-2 data-horizontal:flex-col", e),
            ...n
        })
    }, "TabsContent", 0, function({
        className: e,
        ...t
    }) {
        return (0, a.jsx)(en.Panel, {
            "data-slot": "tabs-content",
            className: (0, ea.cn)("flex-1 text-sm outline-none", e),
            ...t
        })
    }, "TabsList", 0, function({
        className: e,
        variant: t = "default",
        ...n
    }) {
        return (0, a.jsx)(en.List, {
            "data-slot": "tabs-list",
            "data-variant": t,
            className: (0, ea.cn)(er({
                variant: t
            }), e),
            ...n
        })
    }, "TabsTrigger", 0, function({
        className: e,
        ...t
    }) {
        return (0, a.jsx)(en.Tab, {
            "data-slot": "tabs-trigger",
            className: (0, ea.cn)("relative inline-flex h-[calc(100%-1px)] flex-1 items-center justify-center gap-1.5 rounded-md border border-transparent px-2 py-1 text-sm font-medium whitespace-nowrap text-foreground/60 transition-all group-data-vertical/tabs:w-full group-data-vertical/tabs:justify-start hover:text-foreground focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 focus-visible:outline-1 focus-visible:outline-ring disabled:pointer-events-none disabled:opacity-50 has-data-[icon=inline-end]:pr-1.5 has-data-[icon=inline-start]:pl-1.5 aria-disabled:pointer-events-none aria-disabled:opacity-50 dark:text-muted-foreground dark:hover:text-foreground group-data-[variant=default]/tabs-list:data-active:shadow-sm group-data-[variant=line]/tabs-list:data-active:shadow-none [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4", "group-data-[variant=line]/tabs-list:bg-transparent group-data-[variant=line]/tabs-list:data-active:bg-transparent dark:group-data-[variant=line]/tabs-list:data-active:border-transparent dark:group-data-[variant=line]/tabs-list:data-active:bg-transparent", "data-active:bg-background data-active:text-foreground dark:data-active:border-input dark:data-active:bg-input/30 dark:data-active:text-foreground", "after:absolute after:bg-foreground after:opacity-0 after:transition-opacity group-data-horizontal/tabs:after:inset-x-0 group-data-horizontal/tabs:after:bottom-[-5px] group-data-horizontal/tabs:after:h-0.5 group-data-vertical/tabs:after:inset-y-0 group-data-vertical/tabs:after:-right-1 group-data-vertical/tabs:after:w-0.5 group-data-[variant=line]/tabs-list:data-active:after:opacity-100", e),
            ...t
        })
    }], 677572)
}]);