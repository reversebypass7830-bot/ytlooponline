(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 929592, e => {
    "use strict";
    var t = e.i(843476),
        a = e.i(225913),
        r = e.i(975157);
    let n = (0, a.cva)("group/alert relative grid w-full gap-0.5 rounded-lg border px-4 py-3 text-left text-sm has-data-[slot=alert-action]:relative has-data-[slot=alert-action]:pr-18 has-[>svg]:grid-cols-[auto_1fr] has-[>svg]:gap-x-2.5 *:[svg]:row-span-2 *:[svg]:translate-y-0.5 *:[svg]:text-current *:[svg:not([class*='size-'])]:size-4", {
        variants: {
            variant: {
                default: "bg-card text-card-foreground",
                destructive: "bg-card text-destructive *:data-[slot=alert-description]:text-destructive/90 *:[svg]:text-current"
            }
        },
        defaultVariants: {
            variant: "default"
        }
    });
    e.s(["Alert", 0, function({
        className: e,
        variant: a,
        ...s
    }) {
        return (0, t.jsx)("div", {
            "data-slot": "alert",
            role: "alert",
            className: (0, r.cn)(n({
                variant: a
            }), e),
            ...s
        })
    }, "AlertDescription", 0, function({
        className: e,
        ...a
    }) {
        return (0, t.jsx)("div", {
            "data-slot": "alert-description",
            className: (0, r.cn)("text-sm text-balance text-muted-foreground md:text-pretty [&_a]:underline [&_a]:underline-offset-3 [&_a]:hover:text-foreground [&_p:not(:last-child)]:mb-4", e),
            ...a
        })
    }, "AlertTitle", 0, function({
        className: e,
        ...a
    }) {
        return (0, t.jsx)("div", {
            "data-slot": "alert-title",
            className: (0, r.cn)("font-medium group-has-[>svg]/alert:col-start-2 [&_a]:underline [&_a]:underline-offset-3 [&_a]:hover:text-foreground", e),
            ...a
        })
    }])
}, 840816, e => {
    "use strict";
    var t = e.i(843476),
        a = e.i(271645),
        r = e.i(552838),
        n = e.i(677572),
        s = e.i(975157);
    let i = {
        [r.GlobalConstants.PlanDuration.Day]: {
            min: 1,
            max: 30
        },
        [r.GlobalConstants.PlanDuration.Month]: {
            min: 1,
            max: 12
        },
        [r.GlobalConstants.PlanDuration.Year]: {
            min: 1,
            max: 2
        }
    };

    function l({
        direction: e,
        active: a
    }) {
        return (0, t.jsx)("span", {
            "aria-hidden": !0,
            className: (0, s.cn)("inline-block h-6 w-5 transition-colors", a ? "bg-primary" : "bg-primary/25"),
            style: {
                clipPath: "right" === e ? "polygon(0% 0%, 55% 0%, 100% 50%, 55% 100%, 0% 100%, 45% 50%)" : "polygon(100% 0%, 45% 0%, 0% 50%, 45% 100%, 100% 100%, 55% 50%)"
            }
        })
    }
    let o = "h-9 rounded-full border-transparent px-4 text-sm font-medium text-primary shadow-none data-active:bg-primary data-active:text-primary-foreground data-active:shadow-none dark:data-active:border-primary dark:data-active:bg-primary dark:data-active:text-primary-foreground";
    e.s(["PlanPeriodSelector", 0, function({
        currency: e,
        onCurrencyChange: c,
        currencyAlign: d = "center",
        onPeriodChange: u
    }) {
        let [m, x] = (0, a.useState)(r.GlobalConstants.PlanDuration.Day), [p, g] = (0, a.useState)(1), b = i[m];

        function h(e) {
            let t = Math.min(b.max, Math.max(b.min, p + e));
            g(t), u(t, m)
        }
        return (0, a.useEffect)(() => {
            g(1), u(1, m)
        }, [m]), (0, t.jsxs)("div", {
            children: [e && c && (0, t.jsx)("div", {
                className: (0, s.cn)("mb-8 flex justify-center px-2", "end" === d && "md:justify-end md:px-0"),
                children: (0, t.jsx)(n.Tabs, {
                    value: e,
                    onValueChange: e => c(e),
                    children: (0, t.jsx)(n.TabsList, {
                        className: "group-data-horizontal/tabs:h-auto rounded-full border border-primary bg-background p-1",
                        children: ["INR", "USD"].map(e => (0, t.jsx)(n.TabsTrigger, {
                            value: e,
                            className: o,
                            children: "INR" === e ? "🇮🇳 ₹ INR" : "🇺🇸 $ USD"
                        }, e))
                    })
                })
            }), (0, t.jsxs)("div", {
                className: "relative mx-auto max-w-[600px]",
                children: [(0, t.jsx)("div", {
                    className: "mb-8 flex justify-center",
                    children: (0, t.jsx)(n.Tabs, {
                        value: m,
                        onValueChange: e => x(e),
                        children: (0, t.jsx)(n.TabsList, {
                            className: "group-data-horizontal/tabs:h-auto rounded-full border border-primary bg-background p-1",
                            children: [r.GlobalConstants.PlanDuration.Day, r.GlobalConstants.PlanDuration.Month, r.GlobalConstants.PlanDuration.Year].map(e => (0, t.jsx)(n.TabsTrigger, {
                                value: e,
                                className: o,
                                children: e
                            }, e))
                        })
                    })
                }), (0, t.jsxs)("div", {
                    className: "relative h-6 w-full",
                    children: [(0, t.jsx)("div", {
                        className: "pointer-events-none absolute inset-x-0 top-1/2 h-1 -translate-y-1/2 bg-primary/10"
                    }), (0, t.jsx)("div", {
                        className: "pointer-events-none absolute inset-0 flex items-center",
                        children: Array.from({
                            length: b.max - b.min + 1
                        }, (e, t) => b.min + t).map(e => (0, t.jsx)("span", {
                            className: "absolute h-1 w-1 -translate-x-1/2 rounded-full bg-primary/40",
                            style: {
                                left: `${(e-b.min)/(b.max-b.min)*100}%`
                            }
                        }, e))
                    }), (0, t.jsx)("div", {
                        className: "pointer-events-none absolute top-1/2 h-4 w-4 -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary shadow-[0_0_10px_color-mix(in_srgb,var(--primary)_70%,transparent)]",
                        style: {
                            left: `${(p-b.min)/(b.max-b.min)*100}%`
                        }
                    }), (0, t.jsx)("input", {
                        type: "range",
                        min: b.min,
                        max: b.max,
                        value: p,
                        onChange: e => {
                            let t = Number(e.target.value);
                            g(t), u(t, m)
                        },
                        "aria-label": "Billing period",
                        className: "absolute inset-0 h-full w-full cursor-pointer opacity-0"
                    })]
                }), (0, t.jsxs)("div", {
                    className: "mt-2 grid grid-cols-[2.5rem_1fr_2.5rem] items-center",
                    children: [(0, t.jsx)("button", {
                        type: "button",
                        onClick: () => h(-1),
                        disabled: p <= b.min,
                        "aria-label": "Decrease period",
                        className: "flex justify-start disabled:cursor-not-allowed",
                        children: (0, t.jsx)(l, {
                            direction: "left",
                            active: p > b.min
                        })
                    }), (0, t.jsx)("span", {
                        className: "mx-auto min-w-[140px] rounded-lg border border-primary bg-black px-6 py-2 text-center text-base text-muted-foreground",
                        children: m === r.GlobalConstants.PlanDuration.Year ? 1 === p ? "1 Year" : `${p} Years` : `${p} ${m}${p>1?"s":""}`
                    }), (0, t.jsx)("button", {
                        type: "button",
                        onClick: () => h(1),
                        disabled: p >= b.max,
                        "aria-label": "Increase period",
                        className: "flex justify-end disabled:cursor-not-allowed",
                        children: (0, t.jsx)(l, {
                            direction: "right",
                            active: p < b.max
                        })
                    })]
                })]
            })]
        })
    }])
}, 529216, e => {
    "use strict";
    var t = e.i(843476),
        a = e.i(271645),
        r = e.i(929592),
        n = e.i(64742),
        s = e.i(840816),
        i = e.i(67239),
        l = e.i(350854),
        o = e.i(290838),
        c = e.i(793021),
        d = e.i(552838);
    let u = {
        [d.GlobalConstants.PlanDuration.Day]: d.GlobalConstants.ProductTimeCategory.t_day,
        [d.GlobalConstants.PlanDuration.Month]: d.GlobalConstants.ProductTimeCategory.t_month,
        [d.GlobalConstants.PlanDuration.Year]: d.GlobalConstants.ProductTimeCategory.t_year
    };
    e.s(["PricingSection", 0, function({
        showLoopDropPromo: e = !1
    }) {
        let [m, x] = (0, a.useState)([]), [p, g] = (0, a.useState)("INR"), [b, h] = (0, a.useState)(d.GlobalConstants.PlanDuration.Day), [f, v] = (0, a.useState)(1), [y, j] = (0, a.useState)(!0), [N, C] = (0, a.useState)(!1), P = (0, a.useRef)(null), w = (0, a.useRef)(!1), {
            metadata: D
        } = (0, c.useMetadata)(), T = D ? .freeTrialActive ? ? !0;
        (0, a.useEffect)(() => {
            l.default.productService.getProducts().then(e => x(e.items)).catch(() => x([])).finally(() => j(!1))
        }, []), (0, a.useEffect)(() => {
            if (w.current || y) return;
            let e = P.current;
            if (!e) return;
            let t = new IntersectionObserver(([e]) => {
                e ? .isIntersecting && (o.default.viewPricing(), w.current = !0, t.disconnect())
            }, {
                threshold: .25
            });
            return t.observe(e), () => t.disconnect()
        }, [y]);
        let _ = m.filter(e => e.category.includes(u[b])),
            G = e => e.category.includes(d.GlobalConstants.ProductStreamCategory.s_4k),
            S = _.filter(e => !G(e)),
            k = _.find(G);
        return (0, t.jsxs)("section", {
            id: "pricing",
            ref: P,
            className: "px-4 py-16 text-center text-white sm:px-10 md:px-20",
            children: [e && (0, t.jsx)("p", {
                className: "mb-2 text-xs font-semibold tracking-[0.2em] text-primary uppercase",
                children: "Loop Drop Pricing"
            }), (0, t.jsx)("h2", {
                className: "text-3xl font-bold text-white sm:text-5xl md:text-[60px]",
                children: "Choose the Plan That Fits You"
            }), (0, t.jsx)("p", {
                className: "mt-2 mb-4 text-base text-white sm:text-lg md:text-2xl",
                children: "Flexible plans for every stage — from free to pro."
            }), e && (0, t.jsxs)(r.Alert, {
                className: "mx-auto mb-8 w-2xl gap-0 rounded-xl border-chart-4/30 bg-chart-4/10 px-4 py-3 text-sm text-chart-4",
                children: ["🔥 Loop Drop is live — up to ", (0, t.jsx)("strong", {
                    className: "font-bold",
                    children: "45% additional off"
                }), " ", "regular prices. Timer above is counting down. 🔥"]
            }), (0, t.jsx)("div", {
                className: "mt-10 mb-6",
                children: (0, t.jsx)(s.PlanPeriodSelector, {
                    currency: p,
                    onCurrencyChange: g,
                    currencyAlign: "center",
                    onPeriodChange: function(e, t) {
                        h(t), v(e)
                    }
                })
            }), 0 === S.length ? (0, t.jsx)("h3", {
                className: "mt-16 text-lg font-medium text-muted-foreground",
                children: "No plans available for this duration."
            }) : (0, t.jsx)("div", {
                className: "mt-20 flex flex-wrap items-stretch justify-center gap-x-8 gap-y-20 text-left",
                children: S.map(e => (0, t.jsx)("div", {
                    className: "flex w-full max-w-[340px]",
                    children: (0, t.jsx)(n.PlanCard, {
                        product: e,
                        currency: p,
                        periodValue: f,
                        freeTrialActive: T
                    })
                }, e.id))
            }), k && (0, t.jsxs)("div", {
                className: "mx-auto mt-14 flex max-w-[560px] flex-wrap items-center justify-center gap-x-2 gap-y-1 border-t border-white/10 pt-6 text-sm text-[#8D8D94]",
                children: [(0, t.jsxs)("span", {
                    children: ["Need ", (0, t.jsx)("span", {
                        className: "text-white/70",
                        children: "4K broadcast-grade"
                    }), " streaming? Coming soon."]
                }), (0, t.jsx)("button", {
                    type: "button",
                    onClick: () => C(!0),
                    className: "font-medium text-primary/75 underline decoration-primary/25 underline-offset-4 transition-colors hover:text-primary hover:decoration-primary",
                    children: "Join the 4K waitlist"
                })]
            }), k && (0, t.jsx)(i.WaitlistDialog, {
                open: N,
                onOpenChange: C,
                category: k.category.join(",")
            })]
        })
    }])
}]);