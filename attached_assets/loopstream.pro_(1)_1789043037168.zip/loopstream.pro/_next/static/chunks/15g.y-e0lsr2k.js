(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 951437, e => {
    "use strict";
    var t = e.i(271645);
    e.s(["useControlled", 0, function({
        controlled: e,
        default: n,
        name: i,
        state: r = "value"
    }) {
        let {
            current: o
        } = t.useRef(void 0 !== e), [s, u] = t.useState(n), a = t.useCallback(e => {
            o || u(e)
        }, []);
        return [o ? e : s, a]
    }])
}, 545356, e => {
    "use strict";
    var t = e.i(271645);
    let n = t.createContext({
        register: () => {},
        unregister: () => {},
        subscribeMapChange: () => () => {},
        elementsRef: {
            current: []
        },
        nextIndexRef: {
            current: 0
        }
    });
    e.s(["CompositeListContext", 0, n, "useCompositeListContext", 0, function() {
        return t.useContext(n)
    }])
}, 53687, e => {
    "use strict";
    var t = e.i(271645),
        n = e.i(388940),
        i = e.i(667865),
        r = e.i(146376),
        o = e.i(545356),
        s = e.i(843476);

    function u() {
        return new Map
    }

    function a() {
        return new Set
    }

    function l(e, t) {
        let n = e.compareDocumentPosition(t);
        return n & Node.DOCUMENT_POSITION_FOLLOWING || n & Node.DOCUMENT_POSITION_CONTAINED_BY ? -1 : n & Node.DOCUMENT_POSITION_PRECEDING || n & Node.DOCUMENT_POSITION_CONTAINS ? 1 : 0
    }
    e.s(["CompositeList", 0, function(e) {
        let {
            children: c,
            elementsRef: d,
            labelsRef: f,
            onMapChange: p
        } = e, m = (0, i.useStableCallback)(p), C = t.useRef(0), b = (0, n.useRefWithInit)(a).current, g = (0, n.useRefWithInit)(u).current, [v, h] = t.useState(0), S = t.useRef(v), y = (0, i.useStableCallback)((e, t) => {
            g.set(e, t ? ? null), S.current += 1, h(S.current)
        }), x = (0, i.useStableCallback)(e => {
            g.delete(e), S.current += 1, h(S.current)
        }), R = t.useMemo(() => {
            let e = new Map;
            return Array.from(g.keys()).filter(e => e.isConnected).sort(l).forEach((t, n) => {
                let i = g.get(t) ? ? {};
                e.set(t, { ...i,
                    index: n
                })
            }), e
        }, [g, v]);
        (0, r.useIsoLayoutEffect)(() => {
            if ("function" != typeof MutationObserver || 0 === R.size) return;
            let e = new MutationObserver(e => {
                let t = new Set,
                    n = e => t.has(e) ? t.delete(e) : t.add(e);
                e.forEach(e => {
                    e.removedNodes.forEach(n), e.addedNodes.forEach(n)
                }), 0 === t.size && (S.current += 1, h(S.current))
            });
            return R.forEach((t, n) => {
                n.parentElement && e.observe(n.parentElement, {
                    childList: !0
                })
            }), () => {
                e.disconnect()
            }
        }, [R]), (0, r.useIsoLayoutEffect)(() => {
            S.current === v && (d.current.length !== R.size && (d.current.length = R.size), f && f.current.length !== R.size && (f.current.length = R.size), C.current = R.size), m(R)
        }, [m, R, d, f, v]), (0, r.useIsoLayoutEffect)(() => () => {
            d.current = []
        }, [d]), (0, r.useIsoLayoutEffect)(() => () => {
            f && (f.current = [])
        }, [f]);
        let E = (0, i.useStableCallback)(e => (b.add(e), () => {
            b.delete(e)
        }));
        (0, r.useIsoLayoutEffect)(() => {
            b.forEach(e => e(R))
        }, [b, R]);
        let A = t.useMemo(() => ({
            register: y,
            unregister: x,
            subscribeMapChange: E,
            elementsRef: d,
            labelsRef: f,
            nextIndexRef: C
        }), [y, x, E, d, f, C]);
        return (0, s.jsx)(o.CompositeListContext.Provider, {
            value: A,
            children: c
        })
    }])
}, 673553, e => {
    "use strict";
    var t, n = e.i(271645),
        i = e.i(146376),
        r = e.i(545356);
    let o = ((t = {})[t.None = 0] = "None", t[t.GuessFromOrder = 1] = "GuessFromOrder", t);
    e.s(["IndexGuessBehavior", 0, o, "useCompositeListItem", 0, function(e = {}) {
        let {
            label: t,
            metadata: s,
            textRef: u,
            indexGuessBehavior: a,
            index: l
        } = e, {
            register: c,
            unregister: d,
            subscribeMapChange: f,
            elementsRef: p,
            labelsRef: m,
            nextIndexRef: C
        } = (0, r.useCompositeListContext)(), b = n.useRef(-1), [g, v] = n.useState(l ? ? (a === o.GuessFromOrder ? () => {
            if (-1 === b.current) {
                let e = C.current;
                C.current += 1, b.current = e
            }
            return b.current
        } : -1)), h = n.useRef(null), S = n.useCallback(e => {
            if (h.current = e, -1 !== g && null !== e && (p.current[g] = e, m)) {
                let n = void 0 !== t;
                m.current[g] = n ? t : u ? .current ? .textContent ? ? e.textContent
            }
        }, [g, p, m, t, u]);
        return (0, i.useIsoLayoutEffect)(() => {
            if (null != l) return;
            let e = h.current;
            if (e) return c(e, s), () => {
                d(e)
            }
        }, [l, c, d, s]), (0, i.useIsoLayoutEffect)(() => {
            if (null == l) return f(e => {
                let t = h.current ? e.get(h.current) ? .index : null;
                null != t && v(t)
            })
        }, [l, f, v]), {
            ref: S,
            index: g
        }
    }])
}, 873284, e => {
    "use strict";
    var t = e.i(733332),
        n = e.i(271645);
    let i = n.createContext(void 0);
    e.s(["AccordionRootContext", 0, i, "useAccordionRootContext", 0, function() {
        let e = n.useContext(i);
        if (void 0 === e) throw Error((0, t.default)(10));
        return e
    }])
}, 537076, e => {
    "use strict";
    var t = e.i(271645),
        n = e.i(951437),
        i = e.i(667865),
        r = e.i(53687),
        o = e.i(872855),
        s = e.i(873284),
        u = e.i(552245),
        a = e.i(843476);
    let l = {
            value: () => null
        },
        c = t.forwardRef(function(e, c) {
            let {
                render: d,
                className: f,
                disabled: p = !1,
                hiddenUntilFound: m,
                keepMounted: C,
                loopFocus: b,
                onValueChange: g,
                multiple: v = !1,
                orientation: h = "vertical",
                value: S,
                defaultValue: y,
                style: x,
                ...R
            } = e, E = (0, o.useDirection)(), A = t.useMemo(() => {
                if (void 0 === S) return y ? ? []
            }, [S, y]), I = t.useRef([]), [M, O] = (0, n.useControlled)({
                controlled: S,
                default: A,
                name: "Accordion",
                state: "value"
            }), P = (0, i.useStableCallback)((e, t, n) => {
                if (v)
                    if (t) {
                        let t = M.slice();
                        if (t.push(e), g ? .(t, n), n.isCanceled) return;
                        O(t)
                    } else {
                        let t = M.filter(t => t !== e);
                        if (g ? .(t, n), n.isCanceled) return;
                        O(t)
                    }
                else {
                    let t = M[0] === e ? [] : [e];
                    g ? .(t, n), n.isCanceled || O(t)
                }
            }), N = t.useMemo(() => ({
                value: M,
                disabled: p,
                orientation: h
            }), [M, p, h]), L = t.useMemo(() => ({
                disabled: p,
                handleValueChange: P,
                hiddenUntilFound: m ? ? !1,
                keepMounted: C ? ? !1,
                state: N,
                value: M
            }), [p, P, m, C, N, M]), w = (0, u.useRenderElement)("div", e, {
                state: N,
                ref: c,
                props: [{
                    dir: E
                }, R],
                stateAttributesMapping: l
            });
            return (0, a.jsx)(s.AccordionRootContext.Provider, {
                value: L,
                children: (0, a.jsx)(r.CompositeList, {
                    elementsRef: I,
                    children: w
                })
            })
        });
    e.s(["AccordionRoot", 0, c])
}, 823397, e => {
    "use strict";
    var t = e.i(733332),
        n = e.i(271645);
    let i = n.createContext(void 0);
    e.s(["CollapsibleRootContext", 0, i, "useCollapsibleRootContext", 0, function() {
        let e = n.useContext(i);
        if (void 0 === e) throw Error((0, t.default)(15));
        return e
    }])
}, 421310, 903352, 718337, e => {
    "use strict";
    var t, n, i = e.i(209407);
    let r = ((t = {}).open = "data-open", t.closed = "data-closed", t[t.startingStyle = i.TransitionStatusDataAttributes.startingStyle] = "startingStyle", t[t.endingStyle = i.TransitionStatusDataAttributes.endingStyle] = "endingStyle", t);
    e.s(["CollapsiblePanelDataAttributes", 0, r], 421310), e.i(247167);
    var o = e.i(733332),
        s = e.i(271645);
    let u = s.createContext(void 0);
    e.s(["AccordionItemContext", 0, u, "useAccordionItemContext", 0, function() {
        let e = s.useContext(u);
        if (void 0 === e) throw Error((0, o.default)(9));
        return e
    }], 903352);
    let a = ((n = {}).panelOpen = "data-panel-open", n),
        l = {
            [r.open]: ""
        },
        c = {
            [r.closed]: ""
        };
    e.s(["collapsibleOpenStateMapping", 0, {
        open: e => e ? l : c
    }, "triggerOpenStateMapping", 0, {
        open: e => e ? {
            [a.panelOpen]: ""
        } : null
    }], 718337)
}, 220100, e => {
    "use strict";
    var t, n = e.i(718337),
        i = e.i(209407);
    let r = ((t = {}).index = "data-index", t.disabled = "data-disabled", t.open = "data-open", t),
        o = { ...n.collapsibleOpenStateMapping,
            index: e => Number.isInteger(e) ? {
                [r.index]: String(e)
            } : null,
            ...i.transitionStatusMapping,
            value: () => null
        };
    e.s(["accordionStateAttributesMapping", 0, o], 220100)
}, 814837, e => {
    "use strict";
    e.i(247167);
    var t = e.i(271645),
        n = e.i(667865),
        i = e.i(828918),
        r = e.i(788015),
        o = e.i(951437),
        s = e.i(675606),
        u = e.i(56434),
        a = e.i(223910),
        l = e.i(823397),
        c = e.i(673553),
        d = e.i(873284),
        f = e.i(903352),
        p = e.i(220100),
        m = e.i(552245),
        C = e.i(843476);
    let b = t.forwardRef(function(e, b) {
        let {
            className: g,
            disabled: v = !1,
            onOpenChange: h,
            render: S,
            value: y,
            style: x,
            ...R
        } = e, {
            ref: E,
            index: A
        } = (0, c.useCompositeListItem)(), I = (0, i.useMergedRefs)(b, E), {
            disabled: M,
            handleValueChange: O,
            state: P,
            value: N
        } = (0, d.useAccordionRootContext)(), L = (0, r.useBaseUiId)(), w = y ? ? L, k = v || M, T = t.useMemo(() => {
            if (!N) return !1;
            for (let e = 0; e < N.length; e += 1)
                if (N[e] === w) return !0;
            return !1
        }, [N, w]), D = (0, n.useStableCallback)((e, t) => {
            h ? .(e, t), t.isCanceled || O(w, e, t)
        }), F = function(e) {
            let {
                open: i,
                defaultOpen: l,
                onOpenChange: c,
                disabled: d
            } = e, [f, p] = (0, o.useControlled)({
                controlled: i,
                default: l,
                name: "Collapsible",
                state: "open"
            }), {
                mounted: m,
                setMounted: C,
                transitionStatus: b
            } = (0, a.useTransitionStatus)(f, !0, !0), g = (0, r.useBaseUiId)(), [v, h] = t.useState(), S = v ? ? g, y = (0, n.useStableCallback)(e => {
                let t = !f,
                    n = (0, s.createChangeEventDetails)(u.REASONS.triggerPress, e.nativeEvent);
                c(t, n), n.isCanceled || p(t)
            });
            return t.useMemo(() => ({
                disabled: d,
                handleTrigger: y,
                mounted: m,
                open: f,
                panelId: S,
                setMounted: C,
                setOpen: p,
                setPanelIdState: h,
                transitionStatus: b
            }), [d, y, m, f, S, C, p, h, b])
        }({
            open: T,
            onOpenChange: D,
            disabled: k
        }), U = t.useMemo(() => ({
            open: F.open,
            disabled: F.disabled,
            transitionStatus: F.transitionStatus
        }), [F.open, F.disabled, F.transitionStatus]), j = t.useMemo(() => ({ ...F,
            onOpenChange: D,
            state: U
        }), [F, U, D]), _ = t.useMemo(() => ({ ...P,
            hidden: !T && !F.mounted,
            index: A,
            disabled: k,
            open: T
        }), [F.mounted, k, A, T, P]), B = (0, r.useBaseUiId)(), [W, z] = t.useState(), G = t.useMemo(() => ({
            open: T,
            state: _,
            setTriggerId: z,
            triggerId: W ? ? B
        }), [B, T, _, z, W]), H = (0, m.useRenderElement)("div", e, {
            state: _,
            ref: I,
            props: R,
            stateAttributesMapping: p.accordionStateAttributesMapping
        });
        return (0, C.jsx)(l.CollapsibleRootContext.Provider, {
            value: j,
            children: (0, C.jsx)(f.AccordionItemContext.Provider, {
                value: G,
                children: H
            })
        })
    });
    e.s(["AccordionItem", 0, b], 814837)
}, 309023, e => {
    "use strict";
    var t = e.i(271645),
        n = e.i(552245),
        i = e.i(903352),
        r = e.i(220100);
    let o = t.forwardRef(function(e, t) {
        let {
            render: o,
            className: s,
            style: u,
            ...a
        } = e, {
            state: l
        } = (0, i.useAccordionItemContext)();
        return (0, n.useRenderElement)("h3", e, {
            state: l,
            ref: t,
            props: a,
            stateAttributesMapping: r.accordionStateAttributesMapping
        })
    });
    e.s(["AccordionHeader", 0, o])
}, 224648, e => {
    "use strict";
    var t = e.i(271645),
        n = e.i(146376),
        i = e.i(718337),
        r = e.i(540886),
        o = e.i(823397),
        s = e.i(903352),
        u = e.i(552245);
    let a = t.forwardRef(function(e, t) {
        let {
            disabled: a,
            className: l,
            id: c,
            render: d,
            nativeButton: f = !0,
            style: p,
            ...m
        } = e, {
            panelId: C,
            open: b,
            handleTrigger: g,
            disabled: v
        } = (0, o.useCollapsibleRootContext)(), {
            getButtonProps: h,
            buttonRef: S
        } = (0, r.useButton)({
            disabled: a || v,
            focusableWhenDisabled: !0,
            native: f
        }), {
            state: y,
            setTriggerId: x,
            triggerId: R
        } = (0, s.useAccordionItemContext)();
        return (0, n.useIsoLayoutEffect)(() => (c && x(c), () => {
            x(void 0)
        }), [c, x]), (0, u.useRenderElement)("button", e, {
            state: y,
            ref: [t, S],
            props: [{
                "aria-controls": b ? C : void 0,
                "aria-expanded": b,
                id: R,
                onClick: g
            }, m, h],
            stateAttributesMapping: i.triggerOpenStateMapping
        })
    });
    e.s(["AccordionTrigger", 0, a])
}, 166930, e => {
    "use strict";
    e.i(247167);
    var t, n = e.i(271645),
        i = e.i(146376),
        r = e.i(377570),
        o = e.i(823397),
        s = e.i(574735),
        u = e.i(828918),
        a = e.i(708445),
        l = e.i(667865),
        c = e.i(446265),
        d = e.i(333848),
        f = e.i(675606),
        p = e.i(56434),
        m = e.i(137584),
        C = e.i(222640),
        b = e.i(421310);
    let g = {
        height: void 0,
        width: void 0
    };

    function v(e) {
        return {
            height: e.scrollHeight,
            width: e.scrollWidth
        }
    }

    function h(e) {
        return e.split(",").map(e => e.trim()).some(e => "" !== e && Number.parseFloat(e) > 0)
    }

    function S(e, t, n) {
        let i = e.style.getPropertyValue(t),
            r = e.style.getPropertyPriority(t);
        return e.style.setProperty(t, n), () => {
            "" === i ? e.style.removeProperty(t) : e.style.setProperty(t, i, r)
        }
    }
    var y = e.i(873284),
        x = e.i(903352),
        R = e.i(220100);
    let E = ((t = {}).accordionPanelHeight = "--accordion-panel-height", t.accordionPanelWidth = "--accordion-panel-width", t);
    var A = e.i(552245);
    let I = n.forwardRef(function(e, t) {
        let {
            className: I,
            hiddenUntilFound: M,
            keepMounted: O,
            id: P,
            render: N,
            style: L,
            ...w
        } = e, {
            hiddenUntilFound: k,
            keepMounted: T
        } = (0, y.useAccordionRootContext)(), {
            mounted: D,
            onOpenChange: F,
            open: U,
            panelId: j,
            setMounted: _,
            setOpen: B,
            setPanelIdState: W,
            transitionStatus: z
        } = (0, o.useCollapsibleRootContext)();
        (0, i.useIsoLayoutEffect)(() => {
            if (P) return W(P), () => {
                W(void 0)
            }
        }, [P, W]);
        let {
            height: G,
            props: H,
            ref: V,
            shouldPreventOpenAnimation: q,
            shouldRender: K,
            transitionStatus: $,
            width: Y
        } = function(e) {
            let {
                externalRef: t,
                hiddenUntilFound: r,
                id: o,
                keepMounted: y,
                mounted: x,
                onOpenChange: R,
                open: E,
                setMounted: A,
                setOpen: I,
                transitionStatus: M
            } = e, O = n.useRef(null), P = n.useRef(null), [N, L] = n.useState(g), w = n.useRef(g), k = n.useRef(!1), T = n.useRef(E), D = n.useRef(!1), [F, U] = n.useState(!1), j = n.useRef(null), _ = (0, u.useMergedRefs)(t, O), B = (0, c.useValueAsRef)({
                mounted: x,
                open: E
            }), W = (0, C.useAnimationsFinished)(O, !1, !1), z = !E && !x, G = F ? "idle" : M, H = E && (T.current || D.current), V = !E && x && "css-animation" === P.current && void 0 === N.height && void 0 === N.width ? w.current : N, q = r && z && "css-animation" !== P.current, K = (0, l.useStableCallback)((e, t = !0) => {
                t && (w.current = e), L(e)
            }), $ = (0, l.useStableCallback)(() => {
                j.current ? .(), j.current = null
            }), Y = (0, l.useStableCallback)(e => {
                $(), j.current = () => {
                    j.current = null, e()
                }
            }), J = (0, l.useStableCallback)(() => {
                E && x && "css-animation" === P.current && (D.current = !0)
            });
            (0, i.useIsoLayoutEffect)(() => {
                F && "starting" !== M && U(!1)
            }, [F, M]), n.useEffect(() => () => {
                J(), $()
            }, [J, $]), (0, i.useIsoLayoutEffect)(() => {
                let e = O.current;
                if (!e) return;
                !E && j.current && $();
                let t = function(e, t = !1) {
                    let n = (0, d.ownerWindow)(e).getComputedStyle(e),
                        i = (n.animationName.split(",").map(e => e.trim()).some(e => "" !== e && "none" !== e) || t) && h(n.animationDuration),
                        r = h(n.transitionDuration);
                    return i && r || r ? "css-transition" : i ? "css-animation" : "none"
                }(e, H);
                if (P.current = t, E && "idle" === M && T.current && "css-animation" === t) {
                    w.current = v(e);
                    return
                }
                if (E && "starting" === M) {
                    let n = k.current;
                    if (k.current = !1, "none" === t) {
                        K(v(e)), U(!0);
                        return
                    }
                    if ("css-transition" === t) {
                        let t = function(e) {
                            let t = {
                                "justify-content": e.style.justifyContent,
                                "align-items": e.style.alignItems,
                                "align-content": e.style.alignContent,
                                "justify-items": e.style.justifyItems
                            };

                            function n() {
                                Object.entries(t).forEach(([t, n]) => {
                                    "" === n ? e.style.removeProperty(t) : e.style.setProperty(t, n)
                                })
                            }
                            Object.keys(t).forEach(t => {
                                e.style.setProperty(t, "initial", "important")
                            });
                            let i = a.AnimationFrame.request(n);
                            return () => {
                                a.AnimationFrame.cancel(i), n()
                            }
                        }(e);
                        return K(v(e)), n && (Y(S(e, "transition-duration", "0s")), U(!0)), t
                    }
                    if ("css-animation" === t) {
                        if (K(v(e)), !n) return void S(e, "animation-name", "none")();
                        let t = S(e, "animation-name", "none"),
                            i = S(e, "animation-duration", "0s");
                        return t(), Y(i), U(!0), void 0
                    }
                }
                if (!E && x && ("idle" === M || "starting" === M)) {
                    if (T.current = !1, D.current = !1, "none" === t) {
                        K(g, !1), A(!1);
                        return
                    }
                    K(v(e));
                    return
                }
                if ("ending" !== M) return;
                if ("none" === t) return void A(!1);
                let n = v(e);
                (n.height ? ? 0) > 0 || (n.width ? ? 0) > 0 ? (K(n), "css-animation" === t && S(e, "animation-name", "none")()) : A(!1)
            }, [x, E, $, K, A, Y, H, M]), (0, m.useOpenChangeComplete)({
                enabled: E && x && "idle" === G,
                open: !0,
                ref: O,
                onComplete() {
                    E && K(g, !1)
                }
            }), n.useEffect(() => {
                if (E || !x || "ending" !== G || !O.current) return;
                let e = new AbortController,
                    t = -1;

                function n() {
                    B.current.open || (A(!1), K(g, !1))
                }
                return t = a.AnimationFrame.request(() => {
                    e.signal.aborted || W(n, e.signal)
                }), () => {
                    a.AnimationFrame.cancel(t), e.abort()
                }
            }, [B, x, E, G, W, K, A]), (0, i.useIsoLayoutEffect)(() => {
                let e = O.current;
                e && r && z && e.setAttribute("hidden", "until-found")
            }, [z, r]), n.useEffect(function() {
                let e = O.current;
                if (e) return (0, s.addEventListener)(e, "beforematch", function(e) {
                    let t = (0, f.createChangeEventDetails)(p.REASONS.none, e);
                    R(!0, t), t.isCanceled || (k.current = !0, I(!0))
                })
            }, [R, I]);
            let Q = y || r || x || E;
            return {
                height: V.height,
                props: { ...q ? {
                        [b.CollapsiblePanelDataAttributes.startingStyle]: ""
                    } : void 0,
                    hidden: z,
                    id: o
                },
                ref: _,
                shouldPreventOpenAnimation: H,
                shouldRender: Q,
                transitionStatus: G,
                width: V.width
            }
        }({
            externalRef: t,
            hiddenUntilFound: M ? ? k,
            id: P ? ? j,
            keepMounted: O ? ? T,
            mounted: D,
            onOpenChange: F,
            open: U,
            setMounted: _,
            setOpen: B,
            transitionStatus: z
        }), {
            state: J,
            triggerId: Q
        } = (0, x.useAccordionItemContext)(), X = { ...J,
            transitionStatus: $
        }, Z = (0, r.resolveStyle)(L, X), ee = (0, A.useRenderElement)("div", { ...e,
            style: void 0
        }, {
            state: X,
            ref: V,
            props: [H, {
                "aria-labelledby": Q,
                role: "region",
                style: {
                    [E.accordionPanelHeight]: void 0 === G ? "auto" : `${G}px`,
                    [E.accordionPanelWidth]: void 0 === Y ? "auto" : `${Y}px`
                }
            }, w, Z ? {
                style: Z
            } : void 0, q ? {
                style: {
                    animationName: "none"
                }
            } : void 0],
            stateAttributesMapping: R.accordionStateAttributesMapping
        });
        return K ? ee : null
    });
    e.s(["AccordionPanel", 0, I], 166930)
}]);