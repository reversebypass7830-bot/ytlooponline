(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, {
    otherChunks: ["static/chunks/0m97bbjp.vgzu.js", "static/chunks/001_q4azplwp2.js", "static/chunks/0~rk~iesp54ct.js", "static/chunks/0uqgm3y7qfyr6.js", "static/chunks/128aahewwf1we.js"],
    runtimeModuleIds: [494553]
}]), (() => {
    let e;
    if (!Array.isArray(globalThis.TURBOPACK)) return;
    let t = "/_next/",
        r = function() {
            if (null != self.TURBOPACK_ASSET_SUFFIX) return self.TURBOPACK_ASSET_SUFFIX;
            let e = document ? .currentScript ? .getAttribute ? .("src") ? ? "",
                t = e.indexOf("?");
            return t >= 0 ? e.slice(t) : ""
        }(),
        n = ["NEXT_DEPLOYMENT_ID", "NEXT_CLIENT_ASSET_SUFFIX"];
    var o, i = ((o = i || {})[o.Runtime = 0] = "Runtime", o[o.Parent = 1] = "Parent", o[o.Update = 2] = "Update", o);
    let l = new WeakMap;

    function s(e, t) {
        this.m = e, this.e = t
    }
    let u = s.prototype,
        a = Object.prototype.hasOwnProperty,
        c = "u" > typeof Symbol && Symbol.toStringTag;

    function f(e, t, r) {
        a.call(e, t) || Object.defineProperty(e, t, r)
    }

    function p(e, t) {
        let r = e[t];
        return r || (r = h(t), e[t] = r), r
    }

    function h(e) {
        return {
            exports: {},
            error: void 0,
            id: e,
            namespaceObject: void 0
        }
    }

    function d(e, t) {
        f(e, "__esModule", {
            value: !0
        }), c && f(e, c, {
            value: "Module"
        });
        let r = 0;
        for (; r < t.length;) {
            let n = t[r++],
                o = t[r++];
            if ("number" == typeof o)
                if (0 === o) f(e, n, {
                    value: t[r++],
                    enumerable: !0,
                    writable: !1
                });
                else throw Error(`unexpected tag: ${o}`);
            else "function" == typeof t[r] ? f(e, n, {
                get: o,
                set: t[r++],
                enumerable: !0
            }) : f(e, n, {
                get: o,
                enumerable: !0
            })
        }
        Object.seal(e)
    }

    function m(e, t) {
        (null != t ? p(this.c, t) : this.m).exports = e
    }
    u.s = function(e, t) {
        let r, n;
        null != t ? n = (r = p(this.c, t)).exports : (r = this.m, n = this.e), r.namespaceObject = n, d(n, e)
    }, u.j = function(e, t) {
        var r, n;
        let o, i, s;
        null != t ? i = (o = p(this.c, t)).exports : (o = this.m, i = this.e);
        let u = (r = o, n = i, (s = l.get(r)) || (l.set(r, s = []), r.exports = r.namespaceObject = new Proxy(n, {
            get(e, t) {
                if (a.call(e, t) || "default" === t || "__esModule" === t) return Reflect.get(e, t);
                for (let e of s) {
                    let r = Reflect.get(e, t);
                    if (void 0 !== r) return r
                }
            },
            ownKeys(e) {
                let t = Reflect.ownKeys(e);
                for (let e of s)
                    for (let r of Reflect.ownKeys(e)) "default" === r || t.includes(r) || t.push(r);
                return t
            }
        })), s);
        "object" == typeof e && null !== e && u.push(e)
    }, u.v = m, u.n = function(e, t) {
        let r;
        (r = null != t ? p(this.c, t) : this.m).exports = r.namespaceObject = e
    };
    let b = Object.getPrototypeOf ? e => Object.getPrototypeOf(e) : e => e.__proto__,
        y = [null, b({}), b([]), b(b)];

    function g(e, t, r) {
        let n = [],
            o = -1;
        for (let t = e;
            ("object" == typeof t || "function" == typeof t) && !y.includes(t); t = b(t))
            for (let r of Object.getOwnPropertyNames(t)) n.push(r, function(e, t) {
                return () => e[t]
            }(e, r)), -1 === o && "default" === r && (o = n.length - 1);
        return r && o >= 0 || (o >= 0 ? n.splice(o, 1, 0, e) : n.push("default", 0, e)), d(t, n), t
    }

    function w(e) {
        let t = B(e, this.m);
        if (t.namespaceObject) return t.namespaceObject;
        let r = t.exports;
        return t.namespaceObject = g(r, "function" == typeof r ? function(...e) {
            return r.apply(this, e)
        } : Object.create(null), r && r.__esModule)
    }

    function O(e) {
        let t = e.indexOf("#"); - 1 !== t && (e = e.substring(0, t));
        let r = e.indexOf("?");
        return -1 !== r && (e = e.substring(0, r)), e
    }

    function j() {
        let e, t;
        return {
            promise: new Promise((r, n) => {
                t = n, e = r
            }),
            resolve: e,
            reject: t
        }
    }
    u.i = w, u.A = function(e) {
        return this.r(e)(w.bind(this))
    }, u.t = "function" == typeof require ? require : function() {
        throw Error("Unexpected use of runtime require")
    }, u.r = function(e) {
        return B(e, this.m).exports
    }, u.f = function(e) {
        function t(t) {
            if (t = O(t), a.call(e, t)) return e[t].module();
            let r = Error(`Cannot find module '${t}'`);
            throw r.code = "MODULE_NOT_FOUND", r
        }
        return t.keys = () => Object.keys(e), t.resolve = t => {
            if (t = O(t), a.call(e, t)) return e[t].id();
            let r = Error(`Cannot find module '${t}'`);
            throw r.code = "MODULE_NOT_FOUND", r
        }, t.import = async e => await t(e), t
    };
    let k = Symbol("turbopack queues"),
        U = Symbol("turbopack exports"),
        v = Symbol("turbopack error");

    function C(e) {
        e && 1 !== e.status && (e.status = 1, e.forEach(e => e.queueCount--), e.forEach(e => e.queueCount-- ? e.queueCount++ : e()))
    }
    u.a = function(e, t) {
        let r = this.m,
            n = t ? Object.assign([], {
                status: -1
            }) : void 0,
            o = new Set,
            {
                resolve: i,
                reject: l,
                promise: s
            } = j(),
            u = Object.assign(s, {
                [U]: r.exports,
                [k]: e => {
                    n && e(n), o.forEach(e), u.catch(() => {})
                }
            }),
            a = {
                get: () => u,
                set(e) {
                    e !== u && (u[U] = e)
                }
            };
        Object.defineProperty(r, "exports", a), Object.defineProperty(r, "namespaceObject", a), e(function(e) {
            let t = e.map(e => {
                    if (null !== e && "object" == typeof e) {
                        if (k in e) return e;
                        if (null != e && "object" == typeof e && "then" in e && "function" == typeof e.then) {
                            let t = Object.assign([], {
                                    status: 0
                                }),
                                r = {
                                    [U]: {},
                                    [k]: e => e(t)
                                };
                            return e.then(e => {
                                r[U] = e, C(t)
                            }, e => {
                                r[v] = e, C(t)
                            }), r
                        }
                    }
                    return {
                        [U]: e,
                        [k]: () => {}
                    }
                }),
                r = () => t.map(e => {
                    if (e[v]) throw e[v];
                    return e[U]
                }),
                {
                    promise: i,
                    resolve: l
                } = j(),
                s = Object.assign(() => l(r), {
                    queueCount: 0
                });

            function u(e) {
                e !== n && !o.has(e) && (o.add(e), e && 0 === e.status && (s.queueCount++, e.push(s)))
            }
            return t.map(e => e[k](u)), s.queueCount ? i : r()
        }, function(e) {
            e ? l(u[v] = e) : i(u[U]), C(n)
        }), n && -1 === n.status && (n.status = 0)
    };
    let P = function(e) {
        let t = new URL(e, "x:/"),
            r = {};
        for (let e in t) r[e] = t[e];
        for (let t in r.href = e, r.pathname = e.replace(/[?#].*/, ""), r.origin = r.protocol = "", r.toString = r.toJSON = (...t) => e, r) Object.defineProperty(this, t, {
            enumerable: !0,
            configurable: !0,
            value: r[t]
        })
    };

    function R(e, t) {
        throw Error(`Invariant: ${t(e)}`)
    }
    P.prototype = URL.prototype, u.U = P, u.z = function(e) {
        throw Error("dynamic usage of require is not supported")
    }, u.g = globalThis;
    let S = s.prototype,
        $ = new Map;
    u.M = $;
    let _ = new Map,
        E = new Map;
    async function T(e, t, r) {
        let n;
        if ("string" == typeof r) return M(e, t, q(r));
        let o = r.included || [],
            i = o.map(e => !!$.has(e) || _.get(e));
        if (i.length > 0 && i.every(e => e)) return void await Promise.all(i);
        let l = r.moduleChunks || [],
            s = l.map(e => E.get(e)).filter(e => e);
        if (s.length > 0) {
            if (s.length === l.length) return void await Promise.all(s);
            let r = new Set;
            for (let e of l) E.has(e) || r.add(e);
            for (let n of r) {
                let r = M(e, t, q(n));
                E.set(n, r), s.push(r)
            }
            n = Promise.all(s)
        } else {
            for (let o of (n = M(e, t, q(r.path)), l)) E.has(o) || E.set(o, n)
        }
        for (let e of o) _.has(e) || _.set(e, n);
        await n
    }
    S.l = function(e) {
        return T(i.Parent, this.m.id, e)
    };
    let A = Promise.resolve(void 0),
        x = new WeakMap;

    function M(t, r, n) {
        let o = e.loadChunkCached(t, n),
            l = x.get(o);
        if (void 0 === l) {
            let e = x.set.bind(x, o, A);
            l = o.then(e).catch(e => {
                let o;
                switch (t) {
                    case i.Runtime:
                        o = `as a runtime dependency of chunk ${r}`;
                        break;
                    case i.Parent:
                        o = `from module ${r}`;
                        break;
                    case i.Update:
                        o = "from an HMR update";
                        break;
                    default:
                        R(t, e => `Unknown source type: ${e}`)
                }
                let l = Error(`Failed to load chunk ${n} ${o}${e?`: ${e}`:""}`, e ? {
                    cause: e
                } : void 0);
                throw l.name = "ChunkLoadError", l
            }), x.set(o, l)
        }
        return l
    }

    function q(e) {
        return `${t}${e.split("/").map(e=>encodeURIComponent(e)).join("/")}${r}`
    }
    S.L = function(e) {
        return M(i.Parent, this.m.id, e)
    }, S.R = function(e) {
        let t = this.r(e);
        return t ? .default ? ? t
    }, S.P = function(e) {
        return `/ROOT/${e??""}`
    }, S.q = function(e, t) {
        m.call(this, `${e}${r}`, t)
    }, S.b = function(e, t, o, i) {
        let l = "SharedWorker" === e.name,
            s = [o.map(e => q(e)).reverse(), r];
        for (let e of n) s.push(globalThis[e]);
        let u = new URL(q(t), location.origin),
            a = JSON.stringify(s);
        return l ? u.searchParams.set("params", a) : u.hash = "#params=" + encodeURIComponent(a), new e(u, i ? { ...i,
            type: void 0
        } : void 0)
    };
    let N = /\.js(?:\?[^#]*)?(?:#.*)?$/,
        K = /\.css(?:\?[^#]*)?(?:#.*)?$/;

    function L(e) {
        return K.test(e)
    }
    u.w = function(t, r, n) {
        return e.loadWebAssembly(i.Parent, this.m.id, t, r, n)
    }, u.u = function(t, r) {
        return e.loadWebAssemblyModule(i.Parent, this.m.id, t, r)
    };
    let I = {};
    u.c = I;
    let B = (e, t) => {
        let r = I[e];
        if (r) {
            if (r.error) throw r.error;
            return r
        }
        return W(e, i.Parent, t.id)
    };

    function W(e, t, r) {
        let n = $.get(e);
        if ("function" != typeof n) throw Error(function(e, t, r) {
            let n;
            switch (t) {
                case 0:
                    n = `as a runtime entry of chunk ${r}`;
                    break;
                case 1:
                    n = `because it was required from module ${r}`;
                    break;
                case 2:
                    n = "because of an HMR update";
                    break;
                default:
                    R(t, e => `Unknown source type: ${e}`)
            }
            return `Module ${e} was instantiated ${n}, but the module factory is not available.`
        }(e, t, r));
        let o = h(e),
            i = o.exports;
        I[e] = o;
        let l = new s(o, i);
        try {
            n(l, o, i)
        } catch (e) {
            throw o.error = e, e
        }
        return o.namespaceObject && o.exports !== o.namespaceObject && g(o.exports, o.namespaceObject), o
    }

    function F(t) {
        let r, n = function(e) {
            if ("string" == typeof e) return e;
            if (e) return {
                src: e.getAttribute("src")
            };
            if ("u" > typeof TURBOPACK_NEXT_CHUNK_URLS) return {
                src: TURBOPACK_NEXT_CHUNK_URLS.pop()
            };
            throw Error("chunk path empty but not in a worker")
        }(t[0]);
        return 2 === t.length ? r = t[1] : (r = void 0, ! function(e, t) {
            let r = 1;
            for (; r < e.length;) {
                let n, o = r + 1;
                for (; o < e.length && "function" != typeof e[o];) o++;
                if (o === e.length) throw Error("malformed chunk format, expected a factory function");
                let i = e[o];
                for (let i = r; i < o; i++) {
                    let r = e[i],
                        o = t.get(r);
                    if (o) {
                        n = o;
                        break
                    }
                }
                let l = n ? ? i,
                    s = !1;
                for (let n = r; n < o; n++) {
                    let r = e[n];
                    t.has(r) || (s || (l === i && Object.defineProperty(i, "name", {
                        value: "module evaluation"
                    }), s = !0), t.set(r, l))
                }
                r = o + 1
            }
        }(t, $)), e.registerChunk(n, r)
    }
    let X = new Map;

    function D(e) {
        let t = X.get(e);
        if (!t) {
            let r, n;
            t = {
                resolved: !1,
                loadingStarted: !1,
                promise: new Promise((e, t) => {
                    r = e, n = t
                }),
                resolve: () => {
                    t.resolved = !0, r()
                },
                reject: n
            }, X.set(e, t)
        }
        return t
    }
    e = {
        async registerChunk(e, r) {
            let n = function(e) {
                if ("string" == typeof e) return e;
                let r = decodeURIComponent(e.src.replace(/[?#].*$/, ""));
                return r.startsWith(t) ? r.slice(t.length) : r
            }(e);
            if (D("string" == typeof e ? q(e) : e.src).resolve(), null != r) {
                for (let e of r.otherChunks) D(q("string" == typeof e ? e : e.path));
                if (await Promise.all(r.otherChunks.map(e => T(i.Runtime, n, e))), r.runtimeModuleIds.length > 0)
                    for (let e of r.runtimeModuleIds) ! function(e, t) {
                        let r = I[t];
                        if (r) {
                            if (r.error) throw r.error;
                            return
                        }
                        W(t, i.Runtime, e)
                    }(n, e)
            }
        },
        loadChunkCached: (e, t) => (function(e, t) {
            let r = D(t);
            if (r.loadingStarted) return r.promise;
            if (e === i.Runtime) return r.loadingStarted = !0, L(t) && r.resolve(), r.promise;
            if ("function" == typeof importScripts)
                if (L(t));
                else if (N.test(t)) self.TURBOPACK_NEXT_CHUNK_URLS.push(t), importScripts(t);
            else throw Error(`can't infer type of chunk from URL ${t} in worker`);
            else {
                let e = decodeURI(t);
                if (L(t))
                    if (document.querySelectorAll(`link[rel=stylesheet][href="${t}"],link[rel=stylesheet][href^="${t}?"],link[rel=stylesheet][href="${e}"],link[rel=stylesheet][href^="${e}?"]`).length > 0) r.resolve();
                    else {
                        let e = document.createElement("link");
                        e.rel = "stylesheet", e.href = t, e.onerror = () => {
                            r.reject()
                        }, e.onload = () => {
                            r.resolve()
                        }, document.head.appendChild(e)
                    }
                else if (N.test(t)) {
                    let n = document.querySelectorAll(`script[src="${t}"],script[src^="${t}?"],script[src="${e}"],script[src^="${e}?"]`);
                    if (n.length > 0)
                        for (let e of Array.from(n)) e.addEventListener("error", () => {
                            r.reject()
                        });
                    else {
                        let e = document.createElement("script");
                        e.src = t, e.onerror = () => {
                            r.reject()
                        }, document.head.appendChild(e)
                    }
                } else throw Error(`can't infer type of chunk from URL ${t}`)
            }
            return r.loadingStarted = !0, r.promise
        })(e, t),
        async loadWebAssembly(e, t, r, n, o) {
            let i = fetch(q(r)),
                {
                    instance: l
                } = await WebAssembly.instantiateStreaming(i, o);
            return l.exports
        },
        async loadWebAssemblyModule(e, t, r, n) {
            let o = fetch(q(r));
            return await WebAssembly.compileStreaming(o)
        }
    };
    let H = globalThis.TURBOPACK;
    globalThis.TURBOPACK = {
        push: F
    }, H.forEach(F)
})();