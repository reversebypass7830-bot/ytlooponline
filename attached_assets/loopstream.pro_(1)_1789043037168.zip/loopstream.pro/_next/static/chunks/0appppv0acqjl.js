(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 975157, 207670, e => {
    "use strict";

    function r() {
        for (var e, r, o = 0, t = "", l = arguments.length; o < l; o++)(e = arguments[o]) && (r = function e(r) {
            var o, t, l = "";
            if ("string" == typeof r || "number" == typeof r) l += r;
            else if ("object" == typeof r)
                if (Array.isArray(r)) {
                    var s = r.length;
                    for (o = 0; o < s; o++) r[o] && (t = e(r[o])) && (l && (l += " "), l += t)
                } else
                    for (t in r) r[t] && (l && (l += " "), l += t);
            return l
        }(e)) && (t && (t += " "), t += r);
        return t
    }
    e.s(["clsx", 0, r], 207670);
    let o = (e = new Map, r = null, o) => ({
            nextPart: e,
            validators: r,
            classGroupId: o
        }),
        t = [],
        l = (e, r, o) => {
            if (0 == e.length - r) return o.classGroupId;
            let t = e[r],
                s = o.nextPart.get(t);
            if (s) {
                let o = l(e, r + 1, s);
                if (o) return o
            }
            let a = o.validators;
            if (null === a) return;
            let n = 0 === r ? e.join("-") : e.slice(r).join("-"),
                i = a.length;
            for (let e = 0; e < i; e++) {
                let r = a[e];
                if (r.validator(n)) return r.classGroupId
            }
        },
        s = (e, r) => {
            let t = o();
            for (let o in e) a(e[o], t, o, r);
            return t
        },
        a = (e, r, o, t) => {
            let l = e.length;
            for (let s = 0; s < l; s++) n(e[s], r, o, t)
        },
        n = (e, r, o, t) => {
            "string" == typeof e ? i(e, r, o) : "function" == typeof e ? c(e, r, o, t) : d(e, r, o, t)
        },
        i = (e, r, o) => {
            ("" === e ? r : m(r, e)).classGroupId = o
        },
        c = (e, r, o, t) => {
            p(e) ? a(e(t), r, o, t) : (null === r.validators && (r.validators = []), r.validators.push({
                classGroupId: o,
                validator: e
            }))
        },
        d = (e, r, o, t) => {
            let l = Object.entries(e),
                s = l.length;
            for (let e = 0; e < s; e++) {
                let [s, n] = l[e];
                a(n, m(r, s), o, t)
            }
        },
        m = (e, r) => {
            let t = e,
                l = r.split("-"),
                s = l.length;
            for (let e = 0; e < s; e++) {
                let r = l[e],
                    s = t.nextPart.get(r);
                s || (s = o(), t.nextPart.set(r, s)), t = s
            }
            return t
        },
        p = e => "isThemeGetter" in e && !0 === e.isThemeGetter,
        b = [],
        u = (e, r, o, t, l) => ({
            modifiers: e,
            hasImportantModifier: r,
            baseClassName: o,
            maybePostfixModifierPosition: t,
            isExternal: l
        }),
        f = /\s+/,
        g = e => {
            let r;
            if ("string" == typeof e) return e;
            let o = "";
            for (let t = 0; t < e.length; t++) e[t] && (r = g(e[t])) && (o && (o += " "), o += r);
            return o
        },
        h = [],
        k = e => {
            let r = r => r[e] || h;
            return r.isThemeGetter = !0, r
        },
        x = /^\[(?:(\w[\w-]*):)?(.+)\]$/i,
        w = /^\((?:(\w[\w-]*):)?(.+)\)$/i,
        v = /^\d+(?:\.\d+)?\/\d+(?:\.\d+)?$/,
        y = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/,
        z = /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/,
        j = /^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/,
        G = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/,
        C = /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/,
        O = e => v.test(e),
        W = e => !!e && !Number.isNaN(Number(e)),
        I = e => !!e && Number.isInteger(Number(e)),
        N = e => e.endsWith("%") && W(e.slice(0, -1)),
        T = e => y.test(e),
        $ = () => !0,
        M = e => z.test(e) && !j.test(e),
        A = () => !1,
        P = e => G.test(e),
        S = e => C.test(e),
        L = e => !K(e) && !J(e),
        q = e => e.startsWith("@container") && ("/" === e[10] && void 0 !== e[11] || "s" === e[11] && void 0 !== e[16] && e.startsWith("-size/", 10) || "n" === e[11] && void 0 !== e[18] && e.startsWith("-normal/", 10)),
        B = e => eo(e, ea, A),
        K = e => x.test(e),
        R = e => eo(e, en, M),
        U = e => eo(e, ei, W),
        _ = e => eo(e, ed, $),
        E = e => eo(e, ec, A),
        D = e => eo(e, el, A),
        F = e => eo(e, es, S),
        H = e => eo(e, em, P),
        J = e => w.test(e),
        Q = e => et(e, en),
        V = e => et(e, ec),
        X = e => et(e, el),
        Y = e => et(e, ea),
        Z = e => et(e, es),
        ee = e => et(e, em, !0),
        er = e => et(e, ed, !0),
        eo = (e, r, o) => {
            let t = x.exec(e);
            return !!t && (t[1] ? r(t[1]) : o(t[2]))
        },
        et = (e, r, o = !1) => {
            let t = w.exec(e);
            return !!t && (t[1] ? r(t[1]) : o)
        },
        el = e => "position" === e || "percentage" === e,
        es = e => "image" === e || "url" === e,
        ea = e => "length" === e || "size" === e || "bg-size" === e,
        en = e => "length" === e,
        ei = e => "number" === e,
        ec = e => "family-name" === e,
        ed = e => "number" === e || "weight" === e,
        em = e => "shadow" === e,
        ep = ((e, ...r) => {
            let o, a, n, i, c = e => {
                let r = a(e);
                if (r) return r;
                let t = ((e, r) => {
                    let {
                        parseClassName: o,
                        getClassGroupId: t,
                        getConflictingClassGroupIds: l,
                        sortModifiers: s,
                        postfixLookupClassGroupIds: a
                    } = r, n = [], i = e.trim().split(f), c = "";
                    for (let e = i.length - 1; e >= 0; e -= 1) {
                        let r, d = i[e],
                            {
                                isExternal: m,
                                modifiers: p,
                                hasImportantModifier: b,
                                baseClassName: u,
                                maybePostfixModifierPosition: f
                            } = o(d);
                        if (m) {
                            c = d + (c.length > 0 ? " " + c : c);
                            continue
                        }
                        let g = !!f;
                        if (g) {
                            let e = (r = t(u.substring(0, f))) && a[r] ? t(u) : void 0;
                            e && e !== r && (r = e, g = !1)
                        } else r = t(u);
                        if (!r) {
                            if (!g || !(r = t(u))) {
                                c = d + (c.length > 0 ? " " + c : c);
                                continue
                            }
                            g = !1
                        }
                        let h = 0 === p.length ? "" : 1 === p.length ? p[0] : s(p).join(":"),
                            k = b ? h + "!" : h,
                            x = k + r;
                        if (n.indexOf(x) > -1) continue;
                        n.push(x);
                        let w = l(r, g);
                        for (let e = 0; e < w.length; ++e) {
                            let r = w[e];
                            n.push(k + r)
                        }
                        c = d + (c.length > 0 ? " " + c : c)
                    }
                    return c
                })(e, o);
                return n(e, t), t
            };
            return i = d => {
                var m;
                let p;
                return a = (o = {
                    cache: (e => {
                        if (e < 1) return {
                            get: () => void 0,
                            set: () => {}
                        };
                        let r = 0,
                            o = Object.create(null),
                            t = Object.create(null),
                            l = (l, s) => {
                                o[l] = s, ++r > e && (r = 0, t = o, o = Object.create(null))
                            };
                        return {
                            get(e) {
                                let r = o[e];
                                return void 0 !== r ? r : void 0 !== (r = t[e]) ? (l(e, r), r) : void 0
                            },
                            set(e, r) {
                                e in o ? o[e] = r : l(e, r)
                            }
                        }
                    })((m = r.reduce((e, r) => r(e), e())).cacheSize),
                    parseClassName: (e => {
                        let {
                            prefix: r,
                            experimentalParseClassName: o
                        } = e, t = e => {
                            let r, o = [],
                                t = 0,
                                l = 0,
                                s = 0,
                                a = e.length;
                            for (let n = 0; n < a; n++) {
                                let a = e[n];
                                if (0 === t && 0 === l) {
                                    if (":" === a) {
                                        o.push(e.slice(s, n)), s = n + 1;
                                        continue
                                    }
                                    if ("/" === a) {
                                        r = n;
                                        continue
                                    }
                                }
                                "[" === a ? t++ : "]" === a ? t-- : "(" === a ? l++ : ")" === a && l--
                            }
                            let n = 0 === o.length ? e : e.slice(s),
                                i = n,
                                c = !1;
                            return n.endsWith("!") ? (i = n.slice(0, -1), c = !0) : n.startsWith("!") && (i = n.slice(1), c = !0), u(o, c, i, r && r > s ? r - s : void 0)
                        };
                        if (r) {
                            let e = r + ":",
                                o = t;
                            t = r => r.startsWith(e) ? o(r.slice(e.length)) : u(b, !1, r, void 0, !0)
                        }
                        if (o) {
                            let e = t;
                            t = r => o({
                                className: r,
                                parseClassName: e
                            })
                        }
                        return t
                    })(m),
                    sortModifiers: (p = new Map, m.orderSensitiveModifiers.forEach((e, r) => {
                        p.set(e, 1e6 + r)
                    }), e => {
                        let r = [],
                            o = [];
                        for (let t = 0; t < e.length; t++) {
                            let l = e[t],
                                s = "[" === l[0],
                                a = p.has(l);
                            s || a ? (o.length > 0 && (o.sort(), r.push(...o), o = []), r.push(l)) : o.push(l)
                        }
                        return o.length > 0 && (o.sort(), r.push(...o)), r
                    }),
                    postfixLookupClassGroupIds: (e => {
                        let r = Object.create(null),
                            o = e.postfixLookupClassGroups;
                        if (o)
                            for (let e = 0; e < o.length; e++) r[o[e]] = !0;
                        return r
                    })(m),
                    ...(e => {
                        let r = (e => {
                                let {
                                    theme: r,
                                    classGroups: o
                                } = e;
                                return s(o, r)
                            })(e),
                            {
                                conflictingClassGroups: o,
                                conflictingClassGroupModifiers: a
                            } = e;
                        return {
                            getClassGroupId: e => {
                                if (e.startsWith("[") && e.endsWith("]")) {
                                    var o;
                                    let r, t, l;
                                    return -1 === (o = e).slice(1, -1).indexOf(":") ? void 0 : (t = (r = o.slice(1, -1)).indexOf(":"), (l = r.slice(0, t)) ? "arbitrary.." + l : void 0)
                                }
                                let t = e.split("-"),
                                    s = +("" === t[0] && t.length > 1);
                                return l(t, s, r)
                            },
                            getConflictingClassGroupIds: (e, r) => {
                                if (r) {
                                    let r = a[e],
                                        l = o[e];
                                    if (r) {
                                        if (l) {
                                            let e = Array(l.length + r.length);
                                            for (let r = 0; r < l.length; r++) e[r] = l[r];
                                            for (let o = 0; o < r.length; o++) e[l.length + o] = r[o];
                                            return e
                                        }
                                        return r
                                    }
                                    return l || t
                                }
                                return o[e] || t
                            }
                        }
                    })(m)
                }).cache.get, n = o.cache.set, i = c, c(d)
            }, (...e) => i(((...e) => {
                let r, o, t = 0,
                    l = "";
                for (; t < e.length;)(r = e[t++]) && (o = g(r)) && (l && (l += " "), l += o);
                return l
            })(...e))
        })(() => {
            let e = k("color"),
                r = k("font"),
                o = k("text"),
                t = k("font-weight"),
                l = k("tracking"),
                s = k("leading"),
                a = k("breakpoint"),
                n = k("container"),
                i = k("spacing"),
                c = k("radius"),
                d = k("shadow"),
                m = k("inset-shadow"),
                p = k("text-shadow"),
                b = k("drop-shadow"),
                u = k("blur"),
                f = k("perspective"),
                g = k("aspect"),
                h = k("ease"),
                x = k("animate"),
                w = () => ["auto", "avoid", "all", "avoid-page", "page", "left", "right", "column"],
                v = () => ["center", "top", "bottom", "left", "right", "top-left", "left-top", "top-right", "right-top", "bottom-right", "right-bottom", "bottom-left", "left-bottom"],
                y = () => [...v(), J, K],
                z = () => ["auto", "hidden", "clip", "visible", "scroll"],
                j = () => ["auto", "contain", "none"],
                G = () => [J, K, i],
                C = () => [O, "full", "auto", ...G()],
                M = () => [I, "none", "subgrid", J, K],
                A = () => ["auto", {
                    span: ["full", I, J, K]
                }, I, J, K],
                P = () => [I, "auto", J, K],
                S = () => ["auto", "min", "max", "fr", J, K],
                eo = () => ["start", "end", "center", "between", "around", "evenly", "stretch", "baseline", "center-safe", "end-safe"],
                et = () => ["start", "end", "center", "stretch", "center-safe", "end-safe"],
                el = () => ["auto", ...G()],
                es = () => [O, "auto", "full", "dvw", "dvh", "lvw", "lvh", "svw", "svh", "min", "max", "fit", ...G()],
                ea = () => [O, "screen", "full", "dvw", "lvw", "svw", "min", "max", "fit", ...G()],
                en = () => [O, "screen", "full", "lh", "dvh", "lvh", "svh", "min", "max", "fit", ...G()],
                ei = () => [e, J, K],
                ec = () => [...v(), X, D, {
                    position: [J, K]
                }],
                ed = () => ["no-repeat", {
                    repeat: ["", "x", "y", "space", "round"]
                }],
                em = () => ["auto", "cover", "contain", Y, B, {
                    size: [J, K]
                }],
                ep = () => [N, Q, R],
                eb = () => ["", "none", "full", c, J, K],
                eu = () => ["", W, Q, R],
                ef = () => ["solid", "dashed", "dotted", "double"],
                eg = () => ["normal", "multiply", "screen", "overlay", "darken", "lighten", "color-dodge", "color-burn", "hard-light", "soft-light", "difference", "exclusion", "hue", "saturation", "color", "luminosity"],
                eh = () => [W, N, X, D],
                ek = () => ["", "none", u, J, K],
                ex = () => ["none", W, J, K],
                ew = () => ["none", W, J, K],
                ev = () => [W, J, K],
                ey = () => [O, "full", ...G()];
            return {
                cacheSize: 500,
                theme: {
                    animate: ["spin", "ping", "pulse", "bounce"],
                    aspect: ["video"],
                    blur: [T],
                    breakpoint: [T],
                    color: [$],
                    container: [T],
                    "drop-shadow": [T],
                    ease: ["in", "out", "in-out"],
                    font: [L],
                    "font-weight": ["thin", "extralight", "light", "normal", "medium", "semibold", "bold", "extrabold", "black"],
                    "inset-shadow": [T],
                    leading: ["none", "tight", "snug", "normal", "relaxed", "loose"],
                    perspective: ["dramatic", "near", "normal", "midrange", "distant", "none"],
                    radius: [T],
                    shadow: [T],
                    spacing: ["px", W],
                    text: [T],
                    "text-shadow": [T],
                    tracking: ["tighter", "tight", "normal", "wide", "wider", "widest"]
                },
                classGroups: {
                    aspect: [{
                        aspect: ["auto", "square", O, K, J, g]
                    }],
                    container: ["container"],
                    "container-type": [{
                        "@container": ["", "normal", "size", J, K]
                    }],
                    "container-named": [q],
                    columns: [{
                        columns: [W, K, J, n]
                    }],
                    "break-after": [{
                        "break-after": w()
                    }],
                    "break-before": [{
                        "break-before": w()
                    }],
                    "break-inside": [{
                        "break-inside": ["auto", "avoid", "avoid-page", "avoid-column"]
                    }],
                    "box-decoration": [{
                        "box-decoration": ["slice", "clone"]
                    }],
                    box: [{
                        box: ["border", "content"]
                    }],
                    display: ["block", "inline-block", "inline", "flex", "inline-flex", "table", "inline-table", "table-caption", "table-cell", "table-column", "table-column-group", "table-footer-group", "table-header-group", "table-row-group", "table-row", "flow-root", "grid", "inline-grid", "contents", "list-item", "hidden"],
                    sr: ["sr-only", "not-sr-only"],
                    float: [{
                        float: ["right", "left", "none", "start", "end"]
                    }],
                    clear: [{
                        clear: ["left", "right", "both", "none", "start", "end"]
                    }],
                    isolation: ["isolate", "isolation-auto"],
                    "object-fit": [{
                        object: ["contain", "cover", "fill", "none", "scale-down"]
                    }],
                    "object-position": [{
                        object: y()
                    }],
                    overflow: [{
                        overflow: z()
                    }],
                    "overflow-x": [{
                        "overflow-x": z()
                    }],
                    "overflow-y": [{
                        "overflow-y": z()
                    }],
                    overscroll: [{
                        overscroll: j()
                    }],
                    "overscroll-x": [{
                        "overscroll-x": j()
                    }],
                    "overscroll-y": [{
                        "overscroll-y": j()
                    }],
                    position: ["static", "fixed", "absolute", "relative", "sticky"],
                    inset: [{
                        inset: C()
                    }],
                    "inset-x": [{
                        "inset-x": C()
                    }],
                    "inset-y": [{
                        "inset-y": C()
                    }],
                    start: [{
                        "inset-s": C(),
                        start: C()
                    }],
                    end: [{
                        "inset-e": C(),
                        end: C()
                    }],
                    "inset-bs": [{
                        "inset-bs": C()
                    }],
                    "inset-be": [{
                        "inset-be": C()
                    }],
                    top: [{
                        top: C()
                    }],
                    right: [{
                        right: C()
                    }],
                    bottom: [{
                        bottom: C()
                    }],
                    left: [{
                        left: C()
                    }],
                    visibility: ["visible", "invisible", "collapse"],
                    z: [{
                        z: [I, "auto", J, K]
                    }],
                    basis: [{
                        basis: [O, "full", "auto", n, ...G()]
                    }],
                    "flex-direction": [{
                        flex: ["row", "row-reverse", "col", "col-reverse"]
                    }],
                    "flex-wrap": [{
                        flex: ["nowrap", "wrap", "wrap-reverse"]
                    }],
                    flex: [{
                        flex: [W, O, "auto", "initial", "none", K]
                    }],
                    grow: [{
                        grow: ["", W, J, K]
                    }],
                    shrink: [{
                        shrink: ["", W, J, K]
                    }],
                    order: [{
                        order: [I, "first", "last", "none", J, K]
                    }],
                    "grid-cols": [{
                        "grid-cols": M()
                    }],
                    "col-start-end": [{
                        col: A()
                    }],
                    "col-start": [{
                        "col-start": P()
                    }],
                    "col-end": [{
                        "col-end": P()
                    }],
                    "grid-rows": [{
                        "grid-rows": M()
                    }],
                    "row-start-end": [{
                        row: A()
                    }],
                    "row-start": [{
                        "row-start": P()
                    }],
                    "row-end": [{
                        "row-end": P()
                    }],
                    "grid-flow": [{
                        "grid-flow": ["row", "col", "dense", "row-dense", "col-dense"]
                    }],
                    "auto-cols": [{
                        "auto-cols": S()
                    }],
                    "auto-rows": [{
                        "auto-rows": S()
                    }],
                    gap: [{
                        gap: G()
                    }],
                    "gap-x": [{
                        "gap-x": G()
                    }],
                    "gap-y": [{
                        "gap-y": G()
                    }],
                    "justify-content": [{
                        justify: [...eo(), "normal"]
                    }],
                    "justify-items": [{
                        "justify-items": [...et(), "normal"]
                    }],
                    "justify-self": [{
                        "justify-self": ["auto", ...et()]
                    }],
                    "align-content": [{
                        content: ["normal", ...eo()]
                    }],
                    "align-items": [{
                        items: [...et(), {
                            baseline: ["", "last"]
                        }]
                    }],
                    "align-self": [{
                        self: ["auto", ...et(), {
                            baseline: ["", "last"]
                        }]
                    }],
                    "place-content": [{
                        "place-content": eo()
                    }],
                    "place-items": [{
                        "place-items": [...et(), "baseline"]
                    }],
                    "place-self": [{
                        "place-self": ["auto", ...et()]
                    }],
                    p: [{
                        p: G()
                    }],
                    px: [{
                        px: G()
                    }],
                    py: [{
                        py: G()
                    }],
                    ps: [{
                        ps: G()
                    }],
                    pe: [{
                        pe: G()
                    }],
                    pbs: [{
                        pbs: G()
                    }],
                    pbe: [{
                        pbe: G()
                    }],
                    pt: [{
                        pt: G()
                    }],
                    pr: [{
                        pr: G()
                    }],
                    pb: [{
                        pb: G()
                    }],
                    pl: [{
                        pl: G()
                    }],
                    m: [{
                        m: el()
                    }],
                    mx: [{
                        mx: el()
                    }],
                    my: [{
                        my: el()
                    }],
                    ms: [{
                        ms: el()
                    }],
                    me: [{
                        me: el()
                    }],
                    mbs: [{
                        mbs: el()
                    }],
                    mbe: [{
                        mbe: el()
                    }],
                    mt: [{
                        mt: el()
                    }],
                    mr: [{
                        mr: el()
                    }],
                    mb: [{
                        mb: el()
                    }],
                    ml: [{
                        ml: el()
                    }],
                    "space-x": [{
                        "space-x": G()
                    }],
                    "space-x-reverse": ["space-x-reverse"],
                    "space-y": [{
                        "space-y": G()
                    }],
                    "space-y-reverse": ["space-y-reverse"],
                    size: [{
                        size: es()
                    }],
                    "inline-size": [{
                        inline: ["auto", ...ea()]
                    }],
                    "min-inline-size": [{
                        "min-inline": ["auto", ...ea()]
                    }],
                    "max-inline-size": [{
                        "max-inline": ["none", ...ea()]
                    }],
                    "block-size": [{
                        block: ["auto", ...en()]
                    }],
                    "min-block-size": [{
                        "min-block": ["auto", ...en()]
                    }],
                    "max-block-size": [{
                        "max-block": ["none", ...en()]
                    }],
                    w: [{
                        w: [n, "screen", ...es()]
                    }],
                    "min-w": [{
                        "min-w": [n, "screen", "none", ...es()]
                    }],
                    "max-w": [{
                        "max-w": [n, "screen", "none", "prose", {
                            screen: [a]
                        }, ...es()]
                    }],
                    h: [{
                        h: ["screen", "lh", ...es()]
                    }],
                    "min-h": [{
                        "min-h": ["screen", "lh", "none", ...es()]
                    }],
                    "max-h": [{
                        "max-h": ["screen", "lh", ...es()]
                    }],
                    "font-size": [{
                        text: ["base", o, Q, R]
                    }],
                    "font-smoothing": ["antialiased", "subpixel-antialiased"],
                    "font-style": ["italic", "not-italic"],
                    "font-weight": [{
                        font: [t, er, _]
                    }],
                    "font-stretch": [{
                        "font-stretch": ["ultra-condensed", "extra-condensed", "condensed", "semi-condensed", "normal", "semi-expanded", "expanded", "extra-expanded", "ultra-expanded", N, K]
                    }],
                    "font-family": [{
                        font: [V, E, r]
                    }],
                    "font-features": [{
                        "font-features": [K]
                    }],
                    "fvn-normal": ["normal-nums"],
                    "fvn-ordinal": ["ordinal"],
                    "fvn-slashed-zero": ["slashed-zero"],
                    "fvn-figure": ["lining-nums", "oldstyle-nums"],
                    "fvn-spacing": ["proportional-nums", "tabular-nums"],
                    "fvn-fraction": ["diagonal-fractions", "stacked-fractions"],
                    tracking: [{
                        tracking: [l, J, K]
                    }],
                    "line-clamp": [{
                        "line-clamp": [W, "none", J, U]
                    }],
                    leading: [{
                        leading: [s, ...G()]
                    }],
                    "list-image": [{
                        "list-image": ["none", J, K]
                    }],
                    "list-style-position": [{
                        list: ["inside", "outside"]
                    }],
                    "list-style-type": [{
                        list: ["disc", "decimal", "none", J, K]
                    }],
                    "text-alignment": [{
                        text: ["left", "center", "right", "justify", "start", "end"]
                    }],
                    "placeholder-color": [{
                        placeholder: ei()
                    }],
                    "text-color": [{
                        text: ei()
                    }],
                    "text-decoration": ["underline", "overline", "line-through", "no-underline"],
                    "text-decoration-style": [{
                        decoration: [...ef(), "wavy"]
                    }],
                    "text-decoration-thickness": [{
                        decoration: [W, "from-font", "auto", J, R]
                    }],
                    "text-decoration-color": [{
                        decoration: ei()
                    }],
                    "underline-offset": [{
                        "underline-offset": [W, "auto", J, K]
                    }],
                    "text-transform": ["uppercase", "lowercase", "capitalize", "normal-case"],
                    "text-overflow": ["truncate", "text-ellipsis", "text-clip"],
                    "text-wrap": [{
                        text: ["wrap", "nowrap", "balance", "pretty"]
                    }],
                    indent: [{
                        indent: G()
                    }],
                    "tab-size": [{
                        tab: [I, J, K]
                    }],
                    "vertical-align": [{
                        align: ["baseline", "top", "middle", "bottom", "text-top", "text-bottom", "sub", "super", J, K]
                    }],
                    whitespace: [{
                        whitespace: ["normal", "nowrap", "pre", "pre-line", "pre-wrap", "break-spaces"]
                    }],
                    break: [{
                        break: ["normal", "words", "all", "keep"]
                    }],
                    wrap: [{
                        wrap: ["break-word", "anywhere", "normal"]
                    }],
                    hyphens: [{
                        hyphens: ["none", "manual", "auto"]
                    }],
                    content: [{
                        content: ["none", J, K]
                    }],
                    "bg-attachment": [{
                        bg: ["fixed", "local", "scroll"]
                    }],
                    "bg-clip": [{
                        "bg-clip": ["border", "padding", "content", "text"]
                    }],
                    "bg-origin": [{
                        "bg-origin": ["border", "padding", "content"]
                    }],
                    "bg-position": [{
                        bg: ec()
                    }],
                    "bg-repeat": [{
                        bg: ed()
                    }],
                    "bg-size": [{
                        bg: em()
                    }],
                    "bg-image": [{
                        bg: ["none", {
                            linear: [{
                                to: ["t", "tr", "r", "br", "b", "bl", "l", "tl"]
                            }, I, J, K],
                            radial: ["", J, K],
                            conic: [I, J, K]
                        }, Z, F]
                    }],
                    "bg-color": [{
                        bg: ei()
                    }],
                    "gradient-from-pos": [{
                        from: ep()
                    }],
                    "gradient-via-pos": [{
                        via: ep()
                    }],
                    "gradient-to-pos": [{
                        to: ep()
                    }],
                    "gradient-from": [{
                        from: ei()
                    }],
                    "gradient-via": [{
                        via: ei()
                    }],
                    "gradient-to": [{
                        to: ei()
                    }],
                    rounded: [{
                        rounded: eb()
                    }],
                    "rounded-s": [{
                        "rounded-s": eb()
                    }],
                    "rounded-e": [{
                        "rounded-e": eb()
                    }],
                    "rounded-t": [{
                        "rounded-t": eb()
                    }],
                    "rounded-r": [{
                        "rounded-r": eb()
                    }],
                    "rounded-b": [{
                        "rounded-b": eb()
                    }],
                    "rounded-l": [{
                        "rounded-l": eb()
                    }],
                    "rounded-ss": [{
                        "rounded-ss": eb()
                    }],
                    "rounded-se": [{
                        "rounded-se": eb()
                    }],
                    "rounded-ee": [{
                        "rounded-ee": eb()
                    }],
                    "rounded-es": [{
                        "rounded-es": eb()
                    }],
                    "rounded-tl": [{
                        "rounded-tl": eb()
                    }],
                    "rounded-tr": [{
                        "rounded-tr": eb()
                    }],
                    "rounded-br": [{
                        "rounded-br": eb()
                    }],
                    "rounded-bl": [{
                        "rounded-bl": eb()
                    }],
                    "border-w": [{
                        border: eu()
                    }],
                    "border-w-x": [{
                        "border-x": eu()
                    }],
                    "border-w-y": [{
                        "border-y": eu()
                    }],
                    "border-w-s": [{
                        "border-s": eu()
                    }],
                    "border-w-e": [{
                        "border-e": eu()
                    }],
                    "border-w-bs": [{
                        "border-bs": eu()
                    }],
                    "border-w-be": [{
                        "border-be": eu()
                    }],
                    "border-w-t": [{
                        "border-t": eu()
                    }],
                    "border-w-r": [{
                        "border-r": eu()
                    }],
                    "border-w-b": [{
                        "border-b": eu()
                    }],
                    "border-w-l": [{
                        "border-l": eu()
                    }],
                    "divide-x": [{
                        "divide-x": eu()
                    }],
                    "divide-x-reverse": ["divide-x-reverse"],
                    "divide-y": [{
                        "divide-y": eu()
                    }],
                    "divide-y-reverse": ["divide-y-reverse"],
                    "border-style": [{
                        border: [...ef(), "hidden", "none"]
                    }],
                    "divide-style": [{
                        divide: [...ef(), "hidden", "none"]
                    }],
                    "border-color": [{
                        border: ei()
                    }],
                    "border-color-x": [{
                        "border-x": ei()
                    }],
                    "border-color-y": [{
                        "border-y": ei()
                    }],
                    "border-color-s": [{
                        "border-s": ei()
                    }],
                    "border-color-e": [{
                        "border-e": ei()
                    }],
                    "border-color-bs": [{
                        "border-bs": ei()
                    }],
                    "border-color-be": [{
                        "border-be": ei()
                    }],
                    "border-color-t": [{
                        "border-t": ei()
                    }],
                    "border-color-r": [{
                        "border-r": ei()
                    }],
                    "border-color-b": [{
                        "border-b": ei()
                    }],
                    "border-color-l": [{
                        "border-l": ei()
                    }],
                    "divide-color": [{
                        divide: ei()
                    }],
                    "outline-style": [{
                        outline: [...ef(), "none", "hidden"]
                    }],
                    "outline-offset": [{
                        "outline-offset": [W, J, K]
                    }],
                    "outline-w": [{
                        outline: ["", W, Q, R]
                    }],
                    "outline-color": [{
                        outline: ei()
                    }],
                    shadow: [{
                        shadow: ["", "none", d, ee, H]
                    }],
                    "shadow-color": [{
                        shadow: ei()
                    }],
                    "inset-shadow": [{
                        "inset-shadow": ["none", m, ee, H]
                    }],
                    "inset-shadow-color": [{
                        "inset-shadow": ei()
                    }],
                    "ring-w": [{
                        ring: eu()
                    }],
                    "ring-w-inset": ["ring-inset"],
                    "ring-color": [{
                        ring: ei()
                    }],
                    "ring-offset-w": [{
                        "ring-offset": [W, R]
                    }],
                    "ring-offset-color": [{
                        "ring-offset": ei()
                    }],
                    "inset-ring-w": [{
                        "inset-ring": eu()
                    }],
                    "inset-ring-color": [{
                        "inset-ring": ei()
                    }],
                    "text-shadow": [{
                        "text-shadow": ["none", p, ee, H]
                    }],
                    "text-shadow-color": [{
                        "text-shadow": ei()
                    }],
                    opacity: [{
                        opacity: [W, J, K]
                    }],
                    "mix-blend": [{
                        "mix-blend": [...eg(), "plus-darker", "plus-lighter"]
                    }],
                    "bg-blend": [{
                        "bg-blend": eg()
                    }],
                    "mask-clip": [{
                        "mask-clip": ["border", "padding", "content", "fill", "stroke", "view"]
                    }, "mask-no-clip"],
                    "mask-composite": [{
                        mask: ["add", "subtract", "intersect", "exclude"]
                    }],
                    "mask-image-linear-pos": [{
                        "mask-linear": [W]
                    }],
                    "mask-image-linear-from-pos": [{
                        "mask-linear-from": eh()
                    }],
                    "mask-image-linear-to-pos": [{
                        "mask-linear-to": eh()
                    }],
                    "mask-image-linear-from-color": [{
                        "mask-linear-from": ei()
                    }],
                    "mask-image-linear-to-color": [{
                        "mask-linear-to": ei()
                    }],
                    "mask-image-t-from-pos": [{
                        "mask-t-from": eh()
                    }],
                    "mask-image-t-to-pos": [{
                        "mask-t-to": eh()
                    }],
                    "mask-image-t-from-color": [{
                        "mask-t-from": ei()
                    }],
                    "mask-image-t-to-color": [{
                        "mask-t-to": ei()
                    }],
                    "mask-image-r-from-pos": [{
                        "mask-r-from": eh()
                    }],
                    "mask-image-r-to-pos": [{
                        "mask-r-to": eh()
                    }],
                    "mask-image-r-from-color": [{
                        "mask-r-from": ei()
                    }],
                    "mask-image-r-to-color": [{
                        "mask-r-to": ei()
                    }],
                    "mask-image-b-from-pos": [{
                        "mask-b-from": eh()
                    }],
                    "mask-image-b-to-pos": [{
                        "mask-b-to": eh()
                    }],
                    "mask-image-b-from-color": [{
                        "mask-b-from": ei()
                    }],
                    "mask-image-b-to-color": [{
                        "mask-b-to": ei()
                    }],
                    "mask-image-l-from-pos": [{
                        "mask-l-from": eh()
                    }],
                    "mask-image-l-to-pos": [{
                        "mask-l-to": eh()
                    }],
                    "mask-image-l-from-color": [{
                        "mask-l-from": ei()
                    }],
                    "mask-image-l-to-color": [{
                        "mask-l-to": ei()
                    }],
                    "mask-image-x-from-pos": [{
                        "mask-x-from": eh()
                    }],
                    "mask-image-x-to-pos": [{
                        "mask-x-to": eh()
                    }],
                    "mask-image-x-from-color": [{
                        "mask-x-from": ei()
                    }],
                    "mask-image-x-to-color": [{
                        "mask-x-to": ei()
                    }],
                    "mask-image-y-from-pos": [{
                        "mask-y-from": eh()
                    }],
                    "mask-image-y-to-pos": [{
                        "mask-y-to": eh()
                    }],
                    "mask-image-y-from-color": [{
                        "mask-y-from": ei()
                    }],
                    "mask-image-y-to-color": [{
                        "mask-y-to": ei()
                    }],
                    "mask-image-radial": [{
                        "mask-radial": [J, K]
                    }],
                    "mask-image-radial-from-pos": [{
                        "mask-radial-from": eh()
                    }],
                    "mask-image-radial-to-pos": [{
                        "mask-radial-to": eh()
                    }],
                    "mask-image-radial-from-color": [{
                        "mask-radial-from": ei()
                    }],
                    "mask-image-radial-to-color": [{
                        "mask-radial-to": ei()
                    }],
                    "mask-image-radial-shape": [{
                        "mask-radial": ["circle", "ellipse"]
                    }],
                    "mask-image-radial-size": [{
                        "mask-radial": [{
                            closest: ["side", "corner"],
                            farthest: ["side", "corner"]
                        }]
                    }],
                    "mask-image-radial-pos": [{
                        "mask-radial-at": v()
                    }],
                    "mask-image-conic-pos": [{
                        "mask-conic": [W]
                    }],
                    "mask-image-conic-from-pos": [{
                        "mask-conic-from": eh()
                    }],
                    "mask-image-conic-to-pos": [{
                        "mask-conic-to": eh()
                    }],
                    "mask-image-conic-from-color": [{
                        "mask-conic-from": ei()
                    }],
                    "mask-image-conic-to-color": [{
                        "mask-conic-to": ei()
                    }],
                    "mask-mode": [{
                        mask: ["alpha", "luminance", "match"]
                    }],
                    "mask-origin": [{
                        "mask-origin": ["border", "padding", "content", "fill", "stroke", "view"]
                    }],
                    "mask-position": [{
                        mask: ec()
                    }],
                    "mask-repeat": [{
                        mask: ed()
                    }],
                    "mask-size": [{
                        mask: em()
                    }],
                    "mask-type": [{
                        "mask-type": ["alpha", "luminance"]
                    }],
                    "mask-image": [{
                        mask: ["none", J, K]
                    }],
                    filter: [{
                        filter: ["", "none", J, K]
                    }],
                    blur: [{
                        blur: ek()
                    }],
                    brightness: [{
                        brightness: [W, J, K]
                    }],
                    contrast: [{
                        contrast: [W, J, K]
                    }],
                    "drop-shadow": [{
                        "drop-shadow": ["", "none", b, ee, H]
                    }],
                    "drop-shadow-color": [{
                        "drop-shadow": ei()
                    }],
                    grayscale: [{
                        grayscale: ["", W, J, K]
                    }],
                    "hue-rotate": [{
                        "hue-rotate": [W, J, K]
                    }],
                    invert: [{
                        invert: ["", W, J, K]
                    }],
                    saturate: [{
                        saturate: [W, J, K]
                    }],
                    sepia: [{
                        sepia: ["", W, J, K]
                    }],
                    "backdrop-filter": [{
                        "backdrop-filter": ["", "none", J, K]
                    }],
                    "backdrop-blur": [{
                        "backdrop-blur": ek()
                    }],
                    "backdrop-brightness": [{
                        "backdrop-brightness": [W, J, K]
                    }],
                    "backdrop-contrast": [{
                        "backdrop-contrast": [W, J, K]
                    }],
                    "backdrop-grayscale": [{
                        "backdrop-grayscale": ["", W, J, K]
                    }],
                    "backdrop-hue-rotate": [{
                        "backdrop-hue-rotate": [W, J, K]
                    }],
                    "backdrop-invert": [{
                        "backdrop-invert": ["", W, J, K]
                    }],
                    "backdrop-opacity": [{
                        "backdrop-opacity": [W, J, K]
                    }],
                    "backdrop-saturate": [{
                        "backdrop-saturate": [W, J, K]
                    }],
                    "backdrop-sepia": [{
                        "backdrop-sepia": ["", W, J, K]
                    }],
                    "border-collapse": [{
                        border: ["collapse", "separate"]
                    }],
                    "border-spacing": [{
                        "border-spacing": G()
                    }],
                    "border-spacing-x": [{
                        "border-spacing-x": G()
                    }],
                    "border-spacing-y": [{
                        "border-spacing-y": G()
                    }],
                    "table-layout": [{
                        table: ["auto", "fixed"]
                    }],
                    caption: [{
                        caption: ["top", "bottom"]
                    }],
                    transition: [{
                        transition: ["", "all", "colors", "opacity", "shadow", "transform", "none", J, K]
                    }],
                    "transition-behavior": [{
                        transition: ["normal", "discrete"]
                    }],
                    duration: [{
                        duration: [W, "initial", J, K]
                    }],
                    ease: [{
                        ease: ["linear", "initial", h, J, K]
                    }],
                    delay: [{
                        delay: [W, J, K]
                    }],
                    animate: [{
                        animate: ["none", x, J, K]
                    }],
                    backface: [{
                        backface: ["hidden", "visible"]
                    }],
                    perspective: [{
                        perspective: [f, J, K]
                    }],
                    "perspective-origin": [{
                        "perspective-origin": y()
                    }],
                    rotate: [{
                        rotate: ex()
                    }],
                    "rotate-x": [{
                        "rotate-x": ex()
                    }],
                    "rotate-y": [{
                        "rotate-y": ex()
                    }],
                    "rotate-z": [{
                        "rotate-z": ex()
                    }],
                    scale: [{
                        scale: ew()
                    }],
                    "scale-x": [{
                        "scale-x": ew()
                    }],
                    "scale-y": [{
                        "scale-y": ew()
                    }],
                    "scale-z": [{
                        "scale-z": ew()
                    }],
                    "scale-3d": ["scale-3d"],
                    skew: [{
                        skew: ev()
                    }],
                    "skew-x": [{
                        "skew-x": ev()
                    }],
                    "skew-y": [{
                        "skew-y": ev()
                    }],
                    transform: [{
                        transform: [J, K, "", "none", "gpu", "cpu"]
                    }],
                    "transform-origin": [{
                        origin: y()
                    }],
                    "transform-style": [{
                        transform: ["3d", "flat"]
                    }],
                    translate: [{
                        translate: ey()
                    }],
                    "translate-x": [{
                        "translate-x": ey()
                    }],
                    "translate-y": [{
                        "translate-y": ey()
                    }],
                    "translate-z": [{
                        "translate-z": ey()
                    }],
                    "translate-none": ["translate-none"],
                    zoom: [{
                        zoom: [I, J, K]
                    }],
                    accent: [{
                        accent: ei()
                    }],
                    appearance: [{
                        appearance: ["none", "auto"]
                    }],
                    "caret-color": [{
                        caret: ei()
                    }],
                    "color-scheme": [{
                        scheme: ["normal", "dark", "light", "light-dark", "only-dark", "only-light"]
                    }],
                    cursor: [{
                        cursor: ["auto", "default", "pointer", "wait", "text", "move", "help", "not-allowed", "none", "context-menu", "progress", "cell", "crosshair", "vertical-text", "alias", "copy", "no-drop", "grab", "grabbing", "all-scroll", "col-resize", "row-resize", "n-resize", "e-resize", "s-resize", "w-resize", "ne-resize", "nw-resize", "se-resize", "sw-resize", "ew-resize", "ns-resize", "nesw-resize", "nwse-resize", "zoom-in", "zoom-out", J, K]
                    }],
                    "field-sizing": [{
                        "field-sizing": ["fixed", "content"]
                    }],
                    "pointer-events": [{
                        "pointer-events": ["auto", "none"]
                    }],
                    resize: [{
                        resize: ["none", "", "y", "x"]
                    }],
                    "scroll-behavior": [{
                        scroll: ["auto", "smooth"]
                    }],
                    "scrollbar-thumb-color": [{
                        "scrollbar-thumb": ei()
                    }],
                    "scrollbar-track-color": [{
                        "scrollbar-track": ei()
                    }],
                    "scrollbar-gutter": [{
                        "scrollbar-gutter": ["auto", "stable", "both"]
                    }],
                    "scrollbar-w": [{
                        scrollbar: ["auto", "thin", "none"]
                    }],
                    "scroll-m": [{
                        "scroll-m": G()
                    }],
                    "scroll-mx": [{
                        "scroll-mx": G()
                    }],
                    "scroll-my": [{
                        "scroll-my": G()
                    }],
                    "scroll-ms": [{
                        "scroll-ms": G()
                    }],
                    "scroll-me": [{
                        "scroll-me": G()
                    }],
                    "scroll-mbs": [{
                        "scroll-mbs": G()
                    }],
                    "scroll-mbe": [{
                        "scroll-mbe": G()
                    }],
                    "scroll-mt": [{
                        "scroll-mt": G()
                    }],
                    "scroll-mr": [{
                        "scroll-mr": G()
                    }],
                    "scroll-mb": [{
                        "scroll-mb": G()
                    }],
                    "scroll-ml": [{
                        "scroll-ml": G()
                    }],
                    "scroll-p": [{
                        "scroll-p": G()
                    }],
                    "scroll-px": [{
                        "scroll-px": G()
                    }],
                    "scroll-py": [{
                        "scroll-py": G()
                    }],
                    "scroll-ps": [{
                        "scroll-ps": G()
                    }],
                    "scroll-pe": [{
                        "scroll-pe": G()
                    }],
                    "scroll-pbs": [{
                        "scroll-pbs": G()
                    }],
                    "scroll-pbe": [{
                        "scroll-pbe": G()
                    }],
                    "scroll-pt": [{
                        "scroll-pt": G()
                    }],
                    "scroll-pr": [{
                        "scroll-pr": G()
                    }],
                    "scroll-pb": [{
                        "scroll-pb": G()
                    }],
                    "scroll-pl": [{
                        "scroll-pl": G()
                    }],
                    "snap-align": [{
                        snap: ["start", "end", "center", "align-none"]
                    }],
                    "snap-stop": [{
                        snap: ["normal", "always"]
                    }],
                    "snap-type": [{
                        snap: ["none", "x", "y", "both"]
                    }],
                    "snap-strictness": [{
                        snap: ["mandatory", "proximity"]
                    }],
                    touch: [{
                        touch: ["auto", "none", "manipulation"]
                    }],
                    "touch-x": [{
                        "touch-pan": ["x", "left", "right"]
                    }],
                    "touch-y": [{
                        "touch-pan": ["y", "up", "down"]
                    }],
                    "touch-pz": ["touch-pinch-zoom"],
                    select: [{
                        select: ["none", "text", "all", "auto"]
                    }],
                    "will-change": [{
                        "will-change": ["auto", "scroll", "contents", "transform", J, K]
                    }],
                    fill: [{
                        fill: ["none", ...ei()]
                    }],
                    "stroke-w": [{
                        stroke: [W, Q, R, U]
                    }],
                    stroke: [{
                        stroke: ["none", ...ei()]
                    }],
                    "forced-color-adjust": [{
                        "forced-color-adjust": ["auto", "none"]
                    }]
                },
                conflictingClassGroups: {
                    "container-named": ["container-type"],
                    overflow: ["overflow-x", "overflow-y"],
                    overscroll: ["overscroll-x", "overscroll-y"],
                    inset: ["inset-x", "inset-y", "inset-bs", "inset-be", "start", "end", "top", "right", "bottom", "left"],
                    "inset-x": ["right", "left"],
                    "inset-y": ["top", "bottom"],
                    flex: ["basis", "grow", "shrink"],
                    gap: ["gap-x", "gap-y"],
                    p: ["px", "py", "ps", "pe", "pbs", "pbe", "pt", "pr", "pb", "pl"],
                    px: ["pr", "pl"],
                    py: ["pt", "pb"],
                    m: ["mx", "my", "ms", "me", "mbs", "mbe", "mt", "mr", "mb", "ml"],
                    mx: ["mr", "ml"],
                    my: ["mt", "mb"],
                    size: ["w", "h"],
                    "font-size": ["leading"],
                    "fvn-normal": ["fvn-ordinal", "fvn-slashed-zero", "fvn-figure", "fvn-spacing", "fvn-fraction"],
                    "fvn-ordinal": ["fvn-normal"],
                    "fvn-slashed-zero": ["fvn-normal"],
                    "fvn-figure": ["fvn-normal"],
                    "fvn-spacing": ["fvn-normal"],
                    "fvn-fraction": ["fvn-normal"],
                    "line-clamp": ["display", "overflow"],
                    rounded: ["rounded-s", "rounded-e", "rounded-t", "rounded-r", "rounded-b", "rounded-l", "rounded-ss", "rounded-se", "rounded-ee", "rounded-es", "rounded-tl", "rounded-tr", "rounded-br", "rounded-bl"],
                    "rounded-s": ["rounded-ss", "rounded-es"],
                    "rounded-e": ["rounded-se", "rounded-ee"],
                    "rounded-t": ["rounded-tl", "rounded-tr"],
                    "rounded-r": ["rounded-tr", "rounded-br"],
                    "rounded-b": ["rounded-br", "rounded-bl"],
                    "rounded-l": ["rounded-tl", "rounded-bl"],
                    "border-spacing": ["border-spacing-x", "border-spacing-y"],
                    "border-w": ["border-w-x", "border-w-y", "border-w-s", "border-w-e", "border-w-bs", "border-w-be", "border-w-t", "border-w-r", "border-w-b", "border-w-l"],
                    "border-w-x": ["border-w-r", "border-w-l"],
                    "border-w-y": ["border-w-t", "border-w-b"],
                    "border-color": ["border-color-x", "border-color-y", "border-color-s", "border-color-e", "border-color-bs", "border-color-be", "border-color-t", "border-color-r", "border-color-b", "border-color-l"],
                    "border-color-x": ["border-color-r", "border-color-l"],
                    "border-color-y": ["border-color-t", "border-color-b"],
                    translate: ["translate-x", "translate-y", "translate-none"],
                    "translate-none": ["translate", "translate-x", "translate-y", "translate-z"],
                    "scroll-m": ["scroll-mx", "scroll-my", "scroll-ms", "scroll-me", "scroll-mbs", "scroll-mbe", "scroll-mt", "scroll-mr", "scroll-mb", "scroll-ml"],
                    "scroll-mx": ["scroll-mr", "scroll-ml"],
                    "scroll-my": ["scroll-mt", "scroll-mb"],
                    "scroll-p": ["scroll-px", "scroll-py", "scroll-ps", "scroll-pe", "scroll-pbs", "scroll-pbe", "scroll-pt", "scroll-pr", "scroll-pb", "scroll-pl"],
                    "scroll-px": ["scroll-pr", "scroll-pl"],
                    "scroll-py": ["scroll-pt", "scroll-pb"],
                    touch: ["touch-x", "touch-y", "touch-pz"],
                    "touch-x": ["touch"],
                    "touch-y": ["touch"],
                    "touch-pz": ["touch"]
                },
                conflictingClassGroupModifiers: {
                    "font-size": ["leading"]
                },
                postfixLookupClassGroups: ["container-type"],
                orderSensitiveModifiers: ["*", "**", "after", "backdrop", "before", "details-content", "file", "first-letter", "first-line", "marker", "placeholder", "selection"]
            }
        });
    e.s(["cn", 0, function(...e) {
        return ep(r(e))
    }], 975157)
}]);