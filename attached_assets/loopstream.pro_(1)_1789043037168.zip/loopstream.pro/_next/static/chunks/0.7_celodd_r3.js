(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 818581, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "useMergedRef", {
        enumerable: !0,
        get: function() {
            return i
        }
    });
    let n = e.r(271645);

    function i(e, t) {
        let r = (0, n.useRef)(null),
            i = (0, n.useRef)(null);
        return (0, n.useCallback)(n => {
            if (null === n) {
                let e = r.current;
                e && (r.current = null, e());
                let t = i.current;
                t && (i.current = null, t())
            } else e && (r.current = o(e, n)), t && (i.current = o(t, n))
        }, [e, t])
    }

    function o(e, t) {
        if ("function" != typeof e) return e.current = t, () => {
            e.current = null
        }; {
            let r = e(t);
            return "function" == typeof r ? r : () => e(null)
        }
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 195057, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        formatUrl: function() {
            return l
        },
        formatWithValidation: function() {
            return u
        },
        urlObjectKeys: function() {
            return s
        }
    };
    for (var i in n) Object.defineProperty(r, i, {
        enumerable: !0,
        get: n[i]
    });
    let o = e.r(190809)._(e.r(998183)),
        a = /https?|ftp|gopher|file/;

    function l(e) {
        let {
            auth: t,
            hostname: r
        } = e, n = e.protocol || "", i = e.pathname || "", l = e.hash || "", s = e.query || "", u = !1;
        t = t ? encodeURIComponent(t).replace(/%3A/i, ":") + "@" : "", e.host ? u = t + e.host : r && (u = t + (~r.indexOf(":") ? `[${r}]` : r), e.port && (u += ":" + e.port)), s && "object" == typeof s && (s = String(o.urlQueryToSearchParams(s)));
        let d = e.search || s && `?${s}` || "";
        return n && !n.endsWith(":") && (n += ":"), e.slashes || (!n || a.test(n)) && !1 !== u ? (u = "//" + (u || ""), i && "/" !== i[0] && (i = "/" + i)) : u || (u = ""), l && "#" !== l[0] && (l = "#" + l), d && "?" !== d[0] && (d = "?" + d), i = i.replace(/[?#]/g, encodeURIComponent), d = d.replace("#", "%23"), `${n}${u}${i}${d}${l}`
    }
    let s = ["auth", "hash", "host", "hostname", "href", "path", "pathname", "port", "protocol", "query", "search", "slashes"];

    function u(e) {
        return l(e)
    }
}, 573668, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "isLocalURL", {
        enumerable: !0,
        get: function() {
            return o
        }
    });
    let n = e.r(718967),
        i = e.r(652817);

    function o(e) {
        if (!(0, n.isAbsoluteUrl)(e)) return !0;
        try {
            let t = (0, n.getLocationOrigin)(),
                r = new URL(e, t);
            return r.origin === t && (0, i.hasBasePath)(r.pathname)
        } catch (e) {
            return !1
        }
    }
}, 284508, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "errorOnce", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = e => {}
}, 522016, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        default: function() {
            return v
        },
        useLinkStatus: function() {
            return y
        }
    };
    for (var i in n) Object.defineProperty(r, i, {
        enumerable: !0,
        get: n[i]
    });
    let o = e.r(190809),
        a = e.r(843476),
        l = o._(e.r(271645)),
        s = e.r(195057),
        u = e.r(8372),
        d = e.r(818581),
        c = e.r(718967),
        f = e.r(405550);
    e.r(233525);
    let p = e.r(388540),
        g = e.r(91949),
        h = e.r(573668),
        m = e.r(509396);

    function v(t) {
        var r, n;
        let i, o, v, [y, _] = (0, l.useOptimistic)(g.IDLE_LINK_STATUS),
            x = (0, l.useRef)(null),
            {
                href: P,
                as: w,
                children: j,
                prefetch: O = null,
                passHref: C,
                replace: S,
                shallow: E,
                scroll: R,
                onClick: k,
                onMouseEnter: M,
                onTouchStart: I,
                legacyBehavior: z = !1,
                onNavigate: T,
                transitionTypes: D,
                ref: U,
                unstable_dynamicOnHover: $,
                ...A
            } = t;
        i = j, z && ("string" == typeof i || "number" == typeof i) && (i = (0, a.jsx)("a", {
            children: i
        }));
        let L = l.default.useContext(u.AppRouterContext),
            N = !1 !== O,
            B = !1 !== O ? null === (n = O) || "auto" === n ? m.FetchStrategy.PPR : m.FetchStrategy.Full : m.FetchStrategy.PPR,
            F = "string" == typeof(r = w || P) ? r : (0, s.formatUrl)(r);
        if (z) {
            if (i ? .$$typeof === Symbol.for("react.lazy")) throw Object.defineProperty(Error("`<Link legacyBehavior>` received a direct child that is either a Server Component, or JSX that was loaded with React.lazy(). This is not supported. Either remove legacyBehavior, or make the direct child a Client Component that renders the Link's `<a>` tag."), "__NEXT_ERROR_CODE", {
                value: "E863",
                enumerable: !1,
                configurable: !0
            });
            o = l.default.Children.only(i)
        }
        let q = z ? o && "object" == typeof o && o.ref : U,
            K = l.default.useCallback(e => (null !== L && (x.current = (0, g.mountLinkInstance)(e, F, L, B, N, _)), () => {
                x.current && ((0, g.unmountLinkForCurrentNavigation)(x.current), x.current = null), (0, g.unmountPrefetchableInstance)(e)
            }), [N, F, L, B, _]),
            W = {
                ref: (0, d.useMergedRef)(K, q),
                onClick(t) {
                    z || "function" != typeof k || k(t), z && o.props && "function" == typeof o.props.onClick && o.props.onClick(t), !L || t.defaultPrevented || function(t, r, n, i, o, a, s) {
                        if ("u" > typeof window) {
                            let u, {
                                nodeName: d
                            } = t.currentTarget;
                            if ("A" === d.toUpperCase() && ((u = t.currentTarget.getAttribute("target")) && "_self" !== u || t.metaKey || t.ctrlKey || t.shiftKey || t.altKey || t.nativeEvent && 2 === t.nativeEvent.which) || t.currentTarget.hasAttribute("download")) return;
                            if (!(0, h.isLocalURL)(r)) {
                                i && (t.preventDefault(), location.replace(r));
                                return
                            }
                            if (t.preventDefault(), a) {
                                let e = !1;
                                if (a({
                                        preventDefault: () => {
                                            e = !0
                                        }
                                    }), e) return
                            }
                            let {
                                dispatchNavigateAction: c
                            } = e.r(699781);
                            l.default.startTransition(() => {
                                c(r, i ? "replace" : "push", !1 === o ? p.ScrollBehavior.NoScroll : p.ScrollBehavior.Default, n.current, s)
                            })
                        }
                    }(t, F, x, S, R, T, D)
                },
                onMouseEnter(e) {
                    z || "function" != typeof M || M(e), z && o.props && "function" == typeof o.props.onMouseEnter && o.props.onMouseEnter(e), L && N && (0, g.onNavigationIntent)(e.currentTarget, !0 === $)
                },
                onTouchStart: function(e) {
                    z || "function" != typeof I || I(e), z && o.props && "function" == typeof o.props.onTouchStart && o.props.onTouchStart(e), L && N && (0, g.onNavigationIntent)(e.currentTarget, !0 === $)
                }
            };
        return (0, c.isAbsoluteUrl)(F) ? W.href = F : z && !C && ("a" !== o.type || "href" in o.props) || (W.href = (0, f.addBasePath)(F)), v = z ? l.default.cloneElement(o, W) : (0, a.jsx)("a", { ...A,
            ...W,
            children: i
        }), (0, a.jsx)(b.Provider, {
            value: y,
            children: v
        })
    }
    e.r(284508);
    let b = (0, l.createContext)(g.IDLE_LINK_STATUS),
        y = () => (0, l.useContext)(b);
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 540886, 838452, e => {
    "use strict";
    e.i(247167);
    var t = e.i(271645),
        r = e.i(229315),
        n = e.i(667865),
        i = e.i(146376),
        o = e.i(176782),
        a = e.i(733332);
    let l = t.createContext(void 0);

    function s(e = !1) {
        let r = t.useContext(l);
        if (void 0 === r && !e) throw Error((0, a.default)(16));
        return r
    }

    function u(e) {
        return (0, r.isHTMLElement)(e) && "BUTTON" === e.tagName
    }
    e.s(["CompositeRootContext", 0, l, "useCompositeRootContext", 0, s], 838452), e.s(["useButton", 0, function(e = {}) {
        let {
            disabled: r = !1,
            focusableWhenDisabled: a,
            tabIndex: l = 0,
            native: d = !0,
            composite: c
        } = e, f = t.useRef(null), p = s(!0), g = c ? ? void 0 !== p, {
            props: h
        } = function(e) {
            let {
                focusableWhenDisabled: r,
                disabled: n,
                composite: i = !1,
                tabIndex: o = 0,
                isNativeButton: a
            } = e, l = i && !1 !== r, s = i && !1 === r;
            return {
                props: t.useMemo(() => {
                    let e = {
                        onKeyDown(e) {
                            n && r && "Tab" !== e.key && e.preventDefault()
                        }
                    };
                    return i || (e.tabIndex = o, !a && n && (e.tabIndex = r ? o : -1)), (a && (r || l) || !a && n) && (e["aria-disabled"] = n), a && (!r || s) && (e.disabled = n), e
                }, [i, n, r, l, s, a, o])
            }
        }({
            focusableWhenDisabled: a,
            disabled: r,
            composite: g,
            tabIndex: l,
            isNativeButton: d
        }), m = t.useCallback(() => {
            let e = f.current;
            u(e) && g && r && void 0 === h.disabled && e.disabled && (e.disabled = !1)
        }, [r, h.disabled, g]);
        return (0, i.useIsoLayoutEffect)(m, [m]), {
            getButtonProps: t.useCallback((e = {}) => {
                let {
                    onClick: t,
                    onMouseDown: n,
                    onKeyUp: i,
                    onKeyDown: a,
                    onPointerDown: l,
                    ...s
                } = e;
                return (0, o.mergeProps)({
                    onClick(e) {
                        r ? e.preventDefault() : t ? .(e)
                    },
                    onMouseDown(e) {
                        r || n ? .(e)
                    },
                    onKeyDown(e) {
                        var n;
                        if (r || ((0, o.makeEventPreventable)(e), a ? .(e), e.baseUIHandlerPrevented)) return;
                        let i = e.target === e.currentTarget,
                            l = e.currentTarget,
                            s = u(l),
                            c = !d && (n = l, !!(n ? .tagName === "A" && n ? .href)),
                            f = i && (d ? s : !c),
                            p = "Enter" === e.key,
                            h = " " === e.key,
                            m = l.getAttribute("role"),
                            v = m ? .startsWith("menuitem") || "option" === m || "gridcell" === m;
                        if (i && g && h) {
                            if (e.defaultPrevented && v) return;
                            e.preventDefault(), c || d && s ? (l.click(), e.preventBaseUIHandler()) : f && (t ? .(e), e.preventBaseUIHandler());
                            return
                        }
                        f && (!d && (h || p) && e.preventDefault(), !d && p && t ? .(e))
                    },
                    onKeyUp(e) {
                        r || (((0, o.makeEventPreventable)(e), i ? .(e), e.target === e.currentTarget && d && g && u(e.currentTarget) && " " === e.key) ? e.preventDefault() : !e.baseUIHandlerPrevented && (e.target !== e.currentTarget || d || g || " " !== e.key || t ? .(e)))
                    },
                    onPointerDown(e) {
                        r ? e.preventDefault() : l ? .(e)
                    }
                }, d ? {
                    type: "button"
                } : {
                    role: "button"
                }, h, s)
            }, [r, h, g, d]),
            buttonRef: (0, n.useStableCallback)(e => {
                f.current = e, m()
            })
        }
    }], 540886)
}, 527930, e => {
    "use strict";
    var t = e.i(271645),
        r = e.i(540886),
        n = e.i(552245);
    let i = t.forwardRef(function(e, t) {
        let {
            render: i,
            className: o,
            disabled: a = !1,
            focusableWhenDisabled: l = !1,
            nativeButton: s = !0,
            style: u,
            ...d
        } = e, {
            getButtonProps: c,
            buttonRef: f
        } = (0, r.useButton)({
            disabled: a,
            focusableWhenDisabled: l,
            native: s
        });
        return (0, n.useRenderElement)("button", e, {
            state: {
                disabled: a
            },
            ref: [t, f],
            props: [d, c]
        })
    });
    e.s(["Button", 0, i])
}, 225913, e => {
    "use strict";
    var t = e.i(207670);
    let r = e => "boolean" == typeof e ? `${e}` : 0 === e ? "0" : e,
        n = t.clsx;
    e.s(["cva", 0, (e, t) => i => {
        var o;
        if ((null == t ? void 0 : t.variants) == null) return n(e, null == i ? void 0 : i.class, null == i ? void 0 : i.className);
        let {
            variants: a,
            defaultVariants: l
        } = t, s = Object.keys(a).map(e => {
            let t = null == i ? void 0 : i[e],
                n = null == l ? void 0 : l[e];
            if (null === t) return null;
            let o = r(t) || r(n);
            return a[e][o]
        }), u = i && Object.entries(i).reduce((e, t) => {
            let [r, n] = t;
            return void 0 === n || (e[r] = n), e
        }, {});
        return n(e, s, null == t || null == (o = t.compoundVariants) ? void 0 : o.reduce((e, t) => {
            let {
                class: r,
                className: n,
                ...i
            } = t;
            return Object.entries(i).every(e => {
                let [t, r] = e;
                return Array.isArray(r) ? r.includes({ ...l,
                    ...u
                }[t]) : ({ ...l,
                    ...u
                })[t] === r
            }) ? [...e, r, n] : e
        }, []), null == i ? void 0 : i.class, null == i ? void 0 : i.className)
    }])
}, 519455, e => {
    "use strict";
    var t = e.i(843476),
        r = e.i(527930),
        n = e.i(225913),
        i = e.i(975157);
    let o = (0, n.cva)("group/button inline-flex shrink-0 items-center justify-center rounded-full border border-transparent bg-clip-padding text-sm font-medium whitespace-nowrap transition-all outline-none select-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 active:not-aria-[haspopup]:translate-y-px disabled:pointer-events-none disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-3 aria-invalid:ring-destructive/20 dark:aria-invalid:border-destructive/50 dark:aria-invalid:ring-destructive/40 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4", {
        variants: {
            variant: {
                default: "bg-primary text-primary-foreground hover:bg-primary/80",
                outline: "border-border bg-background shadow-xs hover:bg-muted hover:text-foreground aria-expanded:bg-muted aria-expanded:text-foreground dark:border-input dark:bg-input/30 dark:hover:bg-input/50",
                secondary: "bg-secondary text-secondary-foreground hover:bg-[color-mix(in_oklch,var(--secondary),var(--foreground)_5%)] aria-expanded:bg-secondary aria-expanded:text-secondary-foreground",
                ghost: "hover:bg-muted hover:text-foreground aria-expanded:bg-muted aria-expanded:text-foreground dark:hover:bg-muted/50",
                destructive: "bg-destructive/10 text-destructive hover:bg-destructive/20 focus-visible:border-destructive/40 focus-visible:ring-destructive/20 dark:bg-destructive/20 dark:hover:bg-destructive/30 dark:focus-visible:ring-destructive/40",
                link: "text-primary underline-offset-4 hover:underline"
            },
            size: {
                default: "h-9 gap-1.5 px-2.5 has-data-[icon=inline-end]:pr-2 has-data-[icon=inline-start]:pl-2",
                xs: "h-6 gap-1 px-2 text-xs has-data-[icon=inline-end]:pr-1.5 has-data-[icon=inline-start]:pl-1.5 [&_svg:not([class*='size-'])]:size-3",
                sm: "h-8 gap-1 px-2.5 has-data-[icon=inline-end]:pr-1.5 has-data-[icon=inline-start]:pl-1.5",
                lg: "h-9 gap-1.5 px-2.5 has-data-[icon=inline-end]:pr-2 has-data-[icon=inline-start]:pl-2",
                icon: "size-9",
                "icon-xs": "size-6 [&_svg:not([class*='size-'])]:size-3",
                "icon-sm": "size-8",
                "icon-lg": "size-9"
            }
        },
        defaultVariants: {
            variant: "default",
            size: "default"
        }
    });
    e.s(["Button", 0, function({
        className: e,
        variant: n = "default",
        size: a = "default",
        ...l
    }) {
        return (0, t.jsx)(r.Button, {
            "data-slot": "button",
            className: (0, i.cn)(o({
                variant: n,
                size: a,
                className: e
            })),
            ...l
        })
    }, "buttonVariants", 0, o])
}, 488143, (e, t, r) => {
    "use strict";

    function n({
        widthInt: e,
        heightInt: t,
        blurWidth: r,
        blurHeight: i,
        blurDataURL: o,
        objectFit: a
    }) {
        let l = r ? 40 * r : e,
            s = i ? 40 * i : t,
            u = l && s ? `viewBox='0 0 ${l} ${s}'` : "";
        return `%3Csvg xmlns='http://www.w3.org/2000/svg' ${u}%3E%3Cfilter id='b' color-interpolation-filters='sRGB'%3E%3CfeGaussianBlur stdDeviation='20'/%3E%3CfeColorMatrix values='1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 100 -1' result='s'/%3E%3CfeFlood x='0' y='0' width='100%25' height='100%25'/%3E%3CfeComposite operator='out' in='s'/%3E%3CfeComposite in2='SourceGraphic'/%3E%3CfeGaussianBlur stdDeviation='20'/%3E%3C/filter%3E%3Cimage width='100%25' height='100%25' x='0' y='0' preserveAspectRatio='${u?"none":"contain"===a?"xMidYMid":"cover"===a?"xMidYMid slice":"none"}' style='filter: url(%23b);' href='${o}'/%3E%3C/svg%3E`
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "getImageBlurSvg", {
        enumerable: !0,
        get: function() {
            return n
        }
    })
}, 987690, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        VALID_LOADERS: function() {
            return o
        },
        imageConfigDefault: function() {
            return a
        }
    };
    for (var i in n) Object.defineProperty(r, i, {
        enumerable: !0,
        get: n[i]
    });
    let o = ["default", "imgix", "cloudinary", "akamai", "custom"],
        a = {
            deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
            imageSizes: [32, 48, 64, 96, 128, 256, 384],
            path: "/_next/image",
            loader: "default",
            loaderFile: "",
            domains: [],
            disableStaticImages: !1,
            minimumCacheTTL: 14400,
            formats: ["image/webp"],
            maximumDiskCacheSize: void 0,
            maximumRedirects: 3,
            maximumResponseBody: 5e7,
            dangerouslyAllowLocalIP: !1,
            dangerouslyAllowSVG: !1,
            contentSecurityPolicy: "script-src 'none'; frame-src 'none'; sandbox;",
            contentDispositionType: "attachment",
            localPatterns: void 0,
            remotePatterns: [],
            qualities: [75],
            unoptimized: !1,
            customCacheHandler: !1
        }
}, 908927, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "getImgProps", {
        enumerable: !0,
        get: function() {
            return u
        }
    }), e.r(233525);
    let n = e.r(543369),
        i = e.r(488143),
        o = e.r(987690),
        a = ["-moz-initial", "fill", "none", "scale-down", void 0];

    function l(e) {
        return void 0 !== e.default
    }

    function s(e) {
        return void 0 === e ? e : "number" == typeof e ? Number.isFinite(e) ? e : NaN : "string" == typeof e && /^[0-9]+$/.test(e) ? parseInt(e, 10) : NaN
    }

    function u({
        src: e,
        sizes: t,
        unoptimized: r = !1,
        priority: d = !1,
        preload: c = !1,
        loading: f,
        className: p,
        quality: g,
        width: h,
        height: m,
        fill: v = !1,
        style: b,
        overrideSrc: y,
        onLoad: _,
        onLoadingComplete: x,
        placeholder: P = "empty",
        blurDataURL: w,
        fetchPriority: j,
        decoding: O = "async",
        layout: C,
        objectFit: S,
        objectPosition: E,
        lazyBoundary: R,
        lazyRoot: k,
        ...M
    }, I) {
        var z;
        let T, D, U, {
                imgConf: $,
                showAltText: A,
                blurComplete: L,
                defaultLoader: N
            } = I,
            B = $ || o.imageConfigDefault;
        if ("allSizes" in B) T = B;
        else {
            let e = [...B.deviceSizes, ...B.imageSizes].sort((e, t) => e - t),
                t = B.deviceSizes.sort((e, t) => e - t),
                r = B.qualities ? .sort((e, t) => e - t);
            T = { ...B,
                allSizes: e,
                deviceSizes: t,
                qualities: r
            }
        }
        if (void 0 === N) throw Object.defineProperty(Error("images.loaderFile detected but the file is missing default export.\nRead more: https://nextjs.org/docs/messages/invalid-images-config"), "__NEXT_ERROR_CODE", {
            value: "E163",
            enumerable: !1,
            configurable: !0
        });
        let F = M.loader || N;
        delete M.loader, delete M.srcSet;
        let q = "__next_img_default" in F;
        if (q) {
            if ("custom" === T.loader) throw Object.defineProperty(Error(`Image with src "${e}" is missing "loader" prop.
Read more: https://nextjs.org/docs/messages/next-image-missing-loader`), "__NEXT_ERROR_CODE", {
                value: "E252",
                enumerable: !1,
                configurable: !0
            })
        } else {
            let e = F;
            F = t => {
                let {
                    config: r,
                    ...n
                } = t;
                return e(n)
            }
        }
        if (C) {
            "fill" === C && (v = !0);
            let e = {
                intrinsic: {
                    maxWidth: "100%",
                    height: "auto"
                },
                responsive: {
                    width: "100%",
                    height: "auto"
                }
            }[C];
            e && (b = { ...b,
                ...e
            });
            let r = {
                responsive: "100vw",
                fill: "100vw"
            }[C];
            r && !t && (t = r)
        }
        let K = "",
            W = s(h),
            H = s(m);
        if ((z = e) && "object" == typeof z && (l(z) || void 0 !== z.src)) {
            let t = l(e) ? e.default : e;
            if (!t.src) throw Object.defineProperty(Error(`An object should only be passed to the image component src parameter if it comes from a static image import. It must include src. Received ${JSON.stringify(t)}`), "__NEXT_ERROR_CODE", {
                value: "E460",
                enumerable: !1,
                configurable: !0
            });
            if (!t.height || !t.width) throw Object.defineProperty(Error(`An object should only be passed to the image component src parameter if it comes from a static image import. It must include height and width. Received ${JSON.stringify(t)}`), "__NEXT_ERROR_CODE", {
                value: "E48",
                enumerable: !1,
                configurable: !0
            });
            if (D = t.blurWidth, U = t.blurHeight, w = w || t.blurDataURL, K = t.src, !v)
                if (W || H) {
                    if (W && !H) {
                        let e = W / t.width;
                        H = Math.round(t.height * e)
                    } else if (!W && H) {
                        let e = H / t.height;
                        W = Math.round(t.width * e)
                    }
                } else W = t.width, H = t.height
        }
        let G = !d && !c && ("lazy" === f || void 0 === f);
        (!(e = "string" == typeof e ? e : K) || e.startsWith("data:") || e.startsWith("blob:")) && (r = !0, G = !1), T.unoptimized && (r = !0), q && !T.dangerouslyAllowSVG && e.split("?", 1)[0].endsWith(".svg") && (r = !0);
        let V = s(g),
            X = Object.assign(v ? {
                position: "absolute",
                height: "100%",
                width: "100%",
                left: 0,
                top: 0,
                right: 0,
                bottom: 0,
                objectFit: S,
                objectPosition: E
            } : {}, A ? {} : {
                color: "transparent"
            }, b),
            J = L || "empty" === P ? null : "blur" === P ? `url("data:image/svg+xml;charset=utf-8,${(0,i.getImageBlurSvg)({widthInt:W,heightInt:H,blurWidth:D,blurHeight:U,blurDataURL:w||"",objectFit:X.objectFit})}")` : `url("${P}")`,
            Q = a.includes(X.objectFit) ? "fill" === X.objectFit ? "100% 100%" : "cover" : X.objectFit,
            Y = J ? {
                backgroundSize: Q,
                backgroundPosition: X.objectPosition || "50% 50%",
                backgroundRepeat: "no-repeat",
                backgroundImage: J
            } : {},
            Z = function({
                config: e,
                src: t,
                unoptimized: r,
                width: i,
                quality: o,
                sizes: a,
                loader: l
            }) {
                if (r) {
                    if (t.startsWith("/") && !t.startsWith("//")) {
                        let e = (0, n.getDeploymentId)();
                        if (e) {
                            let r = t.indexOf("?");
                            if (-1 !== r) {
                                let n = new URLSearchParams(t.slice(r + 1));
                                n.get("dpl") || (n.append("dpl", e), t = t.slice(0, r) + "?" + n.toString())
                            } else t += `?dpl=${e}`
                        }
                    }
                    return {
                        src: t,
                        srcSet: void 0,
                        sizes: void 0
                    }
                }
                let {
                    widths: s,
                    kind: u
                } = function({
                    deviceSizes: e,
                    allSizes: t
                }, r, n) {
                    if (n) {
                        let r = /(^|\s)(1?\d?\d)vw/g,
                            i = [];
                        for (let e; e = r.exec(n);) i.push(parseInt(e[2]));
                        if (i.length) {
                            let r = .01 * Math.min(...i);
                            return {
                                widths: t.filter(t => t >= e[0] * r),
                                kind: "w"
                            }
                        }
                        return {
                            widths: t,
                            kind: "w"
                        }
                    }
                    return "number" != typeof r ? {
                        widths: e,
                        kind: "w"
                    } : {
                        widths: [...new Set([r, 2 * r].map(e => t.find(t => t >= e) || t[t.length - 1]))],
                        kind: "x"
                    }
                }(e, i, a), d = s.length - 1;
                return {
                    sizes: a || "w" !== u ? a : "100vw",
                    srcSet: s.map((r, n) => `${l({config:e,src:t,quality:o,width:r})} ${"w"===u?r:n+1}${u}`).join(", "),
                    src: l({
                        config: e,
                        src: t,
                        quality: o,
                        width: s[d]
                    })
                }
            }({
                config: T,
                src: e,
                unoptimized: r,
                width: W,
                quality: V,
                sizes: t,
                loader: F
            }),
            ee = G ? "lazy" : f;
        return {
            props: { ...M,
                loading: ee,
                fetchPriority: j,
                width: W,
                height: H,
                decoding: O,
                className: p,
                style: { ...X,
                    ...Y
                },
                sizes: Z.sizes,
                srcSet: Z.srcSet,
                src: y || Z.src
            },
            meta: {
                unoptimized: r,
                preload: c || d,
                placeholder: P,
                fill: v
            }
        }
    }
}, 898879, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "default", {
        enumerable: !0,
        get: function() {
            return l
        }
    });
    let n = e.r(271645),
        i = "u" < typeof window,
        o = i ? () => {} : n.useLayoutEffect,
        a = i ? () => {} : n.useEffect;

    function l(e) {
        let {
            headManager: t,
            reduceComponentsToState: r
        } = e;

        function l() {
            if (t && t.mountedInstances) {
                let e = n.Children.toArray(Array.from(t.mountedInstances).filter(Boolean));
                t.updateHead(r(e))
            }
        }
        return i && (t ? .mountedInstances ? .add(e.children), l()), o(() => (t ? .mountedInstances ? .add(e.children), () => {
            t ? .mountedInstances ? .delete(e.children)
        })), o(() => (t && (t._pendingUpdate = l), () => {
            t && (t._pendingUpdate = l)
        })), a(() => (t && t._pendingUpdate && (t._pendingUpdate(), t._pendingUpdate = null), () => {
            t && t._pendingUpdate && (t._pendingUpdate(), t._pendingUpdate = null)
        })), null
    }
}, 325633, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        default: function() {
            return h
        },
        defaultHead: function() {
            return c
        }
    };
    for (var i in n) Object.defineProperty(r, i, {
        enumerable: !0,
        get: n[i]
    });
    let o = e.r(555682),
        a = e.r(190809),
        l = e.r(843476),
        s = a._(e.r(271645)),
        u = o._(e.r(898879)),
        d = e.r(742732);

    function c() {
        return [(0, l.jsx)("meta", {
            charSet: "utf-8"
        }, "charset"), (0, l.jsx)("meta", {
            name: "viewport",
            content: "width=device-width"
        }, "viewport")]
    }

    function f(e, t) {
        return "string" == typeof t || "number" == typeof t ? e : t.type === s.default.Fragment ? e.concat(s.default.Children.toArray(t.props.children).reduce((e, t) => "string" == typeof t || "number" == typeof t ? e : e.concat(t), [])) : e.concat(t)
    }
    e.r(233525);
    let p = ["name", "httpEquiv", "charSet", "itemProp"];

    function g(e) {
        let t, r, n, i;
        return e.reduce(f, []).reverse().concat(c().reverse()).filter((t = new Set, r = new Set, n = new Set, i = {}, e => {
            let o = !0,
                a = !1;
            if (e.key && "number" != typeof e.key && e.key.indexOf("$") > 0) {
                a = !0;
                let r = e.key.slice(e.key.indexOf("$") + 1);
                t.has(r) ? o = !1 : t.add(r)
            }
            switch (e.type) {
                case "title":
                case "base":
                    r.has(e.type) ? o = !1 : r.add(e.type);
                    break;
                case "meta":
                    for (let t = 0, r = p.length; t < r; t++) {
                        let r = p[t];
                        if (e.props.hasOwnProperty(r))
                            if ("charSet" === r) n.has(r) ? o = !1 : n.add(r);
                            else {
                                let t = e.props[r],
                                    n = i[r] || new Set;
                                ("name" !== r || !a) && n.has(t) ? o = !1 : (n.add(t), i[r] = n)
                            }
                    }
            }
            return o
        })).reverse().map((e, t) => {
            let r = e.key || t;
            return s.default.cloneElement(e, {
                key: r
            })
        })
    }
    let h = function({
        children: e
    }) {
        let t = (0, s.useContext)(d.HeadManagerContext);
        return (0, l.jsx)(u.default, {
            reduceComponentsToState: g,
            headManager: t,
            children: e
        })
    };
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 918556, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "ImageConfigContext", {
        enumerable: !0,
        get: function() {
            return o
        }
    });
    let n = e.r(555682)._(e.r(271645)),
        i = e.r(987690),
        o = n.default.createContext(i.imageConfigDefault)
}, 65856, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "RouterContext", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = e.r(555682)._(e.r(271645)).default.createContext(null)
}, 670965, (e, t, r) => {
    "use strict";

    function n(e, t) {
        let r = e || 75;
        return t ? .qualities ? .length ? t.qualities.reduce((e, t) => Math.abs(t - r) < Math.abs(e - r) ? t : e, t.qualities[0]) : r
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "findClosestQuality", {
        enumerable: !0,
        get: function() {
            return n
        }
    })
}, 1948, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "default", {
        enumerable: !0,
        get: function() {
            return a
        }
    });
    let n = e.r(670965),
        i = e.r(543369);

    function o({
        config: e,
        src: t,
        width: r,
        quality: a
    }) {
        let l = (0, i.getDeploymentId)();
        if (t.startsWith("/") && !t.startsWith("//")) {
            let e = t.indexOf("?");
            if (-1 !== e) {
                let r = new URLSearchParams(t.slice(e + 1)),
                    n = r.get("dpl");
                if (n) {
                    l = n, r.delete("dpl");
                    let i = r.toString();
                    t = t.slice(0, e) + (i ? "?" + i : "")
                }
            }
        }
        if (t.startsWith("/") && t.includes("?") && e.localPatterns ? .length === 1 && "**" === e.localPatterns[0].pathname && "" === e.localPatterns[0].search) throw Object.defineProperty(Error(`Image with src "${t}" is using a query string which is not configured in images.localPatterns.
Read more: https://nextjs.org/docs/messages/next-image-unconfigured-localpatterns`), "__NEXT_ERROR_CODE", {
            value: "E871",
            enumerable: !1,
            configurable: !0
        });
        let s = (0, n.findClosestQuality)(a, e);
        return `${e.path}?url=${encodeURIComponent(t)}&w=${r}&q=${s}${t.startsWith("/")&&l?`&dpl=${l}`:""}`
    }
    o.__next_img_default = !0;
    let a = o
}, 605500, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "Image", {
        enumerable: !0,
        get: function() {
            return _
        }
    });
    let n = e.r(555682),
        i = e.r(190809),
        o = e.r(843476),
        a = i._(e.r(271645)),
        l = n._(e.r(174080)),
        s = n._(e.r(325633)),
        u = e.r(908927),
        d = e.r(987690),
        c = e.r(918556);
    e.r(233525);
    let f = e.r(65856),
        p = n._(e.r(1948)),
        g = e.r(818581),
        h = {
            deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
            imageSizes: [32, 48, 64, 96, 128, 256, 384],
            qualities: [75],
            path: "/_next/image",
            loader: "default",
            dangerouslyAllowSVG: !1,
            unoptimized: !1
        };

    function m(e, t, r, n, i, o, a) {
        let l = e ? .src;
        e && e["data-loaded-src"] !== l && (e["data-loaded-src"] = l, ("decode" in e ? e.decode() : Promise.resolve()).catch(() => {}).then(() => {
            if (e.parentElement && e.isConnected) {
                if ("empty" !== t && i(!0), r ? .current) {
                    let t = new Event("load");
                    Object.defineProperty(t, "target", {
                        writable: !1,
                        value: e
                    });
                    let n = !1,
                        i = !1;
                    r.current({ ...t,
                        nativeEvent: t,
                        currentTarget: e,
                        target: e,
                        isDefaultPrevented: () => n,
                        isPropagationStopped: () => i,
                        persist: () => {},
                        preventDefault: () => {
                            n = !0, t.preventDefault()
                        },
                        stopPropagation: () => {
                            i = !0, t.stopPropagation()
                        }
                    })
                }
                n ? .current && n.current(e)
            }
        }))
    }

    function v(e) {
        return a.use ? {
            fetchPriority: e
        } : {
            fetchpriority: e
        }
    }
    "u" < typeof window && (globalThis.__NEXT_IMAGE_IMPORTED = !0);
    let b = (0, a.forwardRef)(({
        src: e,
        srcSet: t,
        sizes: r,
        height: n,
        width: i,
        decoding: l,
        className: s,
        style: u,
        fetchPriority: d,
        placeholder: c,
        loading: f,
        unoptimized: p,
        fill: h,
        onLoadRef: b,
        onLoadingCompleteRef: y,
        setBlurComplete: _,
        setShowAltText: x,
        sizesInput: P,
        onLoad: w,
        onError: j,
        ...O
    }, C) => {
        let S = (0, a.useCallback)(e => {
                e && (j && (e.src = e.src), e.complete && m(e, c, b, y, _, p, P))
            }, [e, c, b, y, _, j, p, P]),
            E = (0, g.useMergedRef)(C, S);
        return (0, o.jsx)("img", { ...O,
            ...v(d),
            loading: f,
            width: i,
            height: n,
            decoding: l,
            "data-nimg": h ? "fill" : "1",
            className: s,
            style: u,
            sizes: r,
            srcSet: t,
            src: e,
            ref: E,
            onLoad: e => {
                m(e.currentTarget, c, b, y, _, p, P)
            },
            onError: e => {
                x(!0), "empty" !== c && _(!0), j && j(e)
            }
        })
    });

    function y({
        isAppRouter: e,
        imgAttributes: t
    }) {
        let r = {
            as: "image",
            imageSrcSet: t.srcSet,
            imageSizes: t.sizes,
            crossOrigin: t.crossOrigin,
            referrerPolicy: t.referrerPolicy,
            ...v(t.fetchPriority)
        };
        return e && l.default.preload ? (l.default.preload(t.src, r), null) : (0, o.jsx)(s.default, {
            children: (0, o.jsx)("link", {
                rel: "preload",
                href: t.srcSet ? void 0 : t.src,
                ...r
            }, "__nimg-" + t.src + t.srcSet + t.sizes)
        })
    }
    let _ = (0, a.forwardRef)((e, t) => {
        let r = (0, a.useContext)(f.RouterContext),
            n = (0, a.useContext)(c.ImageConfigContext),
            i = (0, a.useMemo)(() => {
                let e = h || n || d.imageConfigDefault,
                    t = [...e.deviceSizes, ...e.imageSizes].sort((e, t) => e - t),
                    r = e.deviceSizes.sort((e, t) => e - t),
                    i = e.qualities ? .sort((e, t) => e - t);
                return { ...e,
                    allSizes: t,
                    deviceSizes: r,
                    qualities: i,
                    localPatterns: "u" < typeof window ? n ? .localPatterns : e.localPatterns
                }
            }, [n]),
            {
                onLoad: l,
                onLoadingComplete: s
            } = e,
            g = (0, a.useRef)(l);
        (0, a.useEffect)(() => {
            g.current = l
        }, [l]);
        let m = (0, a.useRef)(s);
        (0, a.useEffect)(() => {
            m.current = s
        }, [s]);
        let [v, _] = (0, a.useState)(!1), [x, P] = (0, a.useState)(!1), {
            props: w,
            meta: j
        } = (0, u.getImgProps)(e, {
            defaultLoader: p.default,
            imgConf: i,
            blurComplete: v,
            showAltText: x
        });
        return (0, o.jsxs)(o.Fragment, {
            children: [(0, o.jsx)(b, { ...w,
                unoptimized: j.unoptimized,
                placeholder: j.placeholder,
                fill: j.fill,
                onLoadRef: g,
                onLoadingCompleteRef: m,
                setBlurComplete: _,
                setShowAltText: P,
                sizesInput: e.sizes,
                ref: t
            }), j.preload ? (0, o.jsx)(y, {
                isAppRouter: !r,
                imgAttributes: w
            }) : null]
        })
    });
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 794909, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        default: function() {
            return d
        },
        getImageProps: function() {
            return u
        }
    };
    for (var i in n) Object.defineProperty(r, i, {
        enumerable: !0,
        get: n[i]
    });
    let o = e.r(555682),
        a = e.r(908927),
        l = e.r(605500),
        s = o._(e.r(1948));

    function u(e) {
        let {
            props: t
        } = (0, a.getImgProps)(e, {
            defaultLoader: s.default,
            imgConf: {
                deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
                imageSizes: [32, 48, 64, 96, 128, 256, 384],
                qualities: [75],
                path: "/_next/image",
                loader: "default",
                dangerouslyAllowSVG: !1,
                unoptimized: !1
            }
        });
        for (let [e, r] of Object.entries(t)) void 0 === r && delete t[e];
        return {
            props: t
        }
    }
    let d = l.Image
}, 657688, (e, t, r) => {
    t.exports = e.r(794909)
}]);