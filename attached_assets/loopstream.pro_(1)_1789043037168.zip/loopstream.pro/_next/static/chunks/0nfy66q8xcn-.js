(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 652225, e => {
    "use strict";
    var t = e.i(271645),
        r = e.i(552245);
    let a = t.forwardRef(function(e, t) {
        let {
            className: a,
            render: s,
            orientation: i = "horizontal",
            style: n,
            ...l
        } = e;
        return (0, r.useRenderElement)("div", e, {
            state: {
                orientation: i
            },
            ref: t,
            props: [{
                role: "separator",
                "aria-orientation": i
            }, l]
        })
    });
    e.s(["Separator", 0, a])
}, 772436, e => {
    "use strict";
    var t = e.i(843476),
        r = e.i(652225),
        a = e.i(975157);
    e.s(["Separator", 0, function({
        className: e,
        orientation: s = "horizontal",
        ...i
    }) {
        return (0, t.jsx)(r.Separator, {
            "data-slot": "separator",
            orientation: s,
            className: (0, a.cn)("shrink-0 bg-border data-horizontal:h-px data-horizontal:w-full data-vertical:w-px data-vertical:self-stretch", e),
            ...i
        })
    }])
}, 285595, e => {
    "use strict";
    var t = e.i(616933);
    e.s(["CircleCheck", () => t.default])
}, 746336, e => {
    "use strict";
    var t = e.i(986253);
    e.s(["ChevronRightIcon", () => t.default])
}, 619928, e => {
    "use strict";
    let t = (0, e.i(456420).default)("ellipsis", [
        ["circle", {
            cx: "12",
            cy: "12",
            r: "1",
            key: "41hilf"
        }],
        ["circle", {
            cx: "19",
            cy: "12",
            r: "1",
            key: "1wjl8i"
        }],
        ["circle", {
            cx: "5",
            cy: "12",
            r: "1",
            key: "1pcz8c"
        }]
    ]);
    e.s(["MoreHorizontalIcon", 0, t], 619928)
}, 986253, e => {
    "use strict";
    let t = (0, e.i(456420).default)("chevron-right", [
        ["path", {
            d: "m9 18 6-6-6-6",
            key: "mthhwq"
        }]
    ]);
    e.s(["default", 0, t])
}, 856423, e => {
    "use strict";
    let t = (0, e.i(456420).default)("book-open", [
        ["path", {
            d: "M12 7v14",
            key: "1akyts"
        }],
        ["path", {
            d: "M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z",
            key: "ruj8y"
        }]
    ]);
    e.s(["BookOpen", 0, t], 856423)
}, 564346, e => {
    "use strict";
    let t = (0, e.i(456420).default)("circle", [
        ["circle", {
            cx: "12",
            cy: "12",
            r: "10",
            key: "1mglay"
        }]
    ]);
    e.s(["Circle", 0, t], 564346)
}, 422768, e => {
    "use strict";
    let t = (0, e.i(456420).default)("circle-alert", [
        ["circle", {
            cx: "12",
            cy: "12",
            r: "10",
            key: "1mglay"
        }],
        ["line", {
            x1: "12",
            x2: "12",
            y1: "8",
            y2: "12",
            key: "1pkeuh"
        }],
        ["line", {
            x1: "12",
            x2: "12.01",
            y1: "16",
            y2: "16",
            key: "4dfq90"
        }]
    ]);
    e.s(["CircleAlert", 0, t], 422768)
}, 702598, e => {
    "use strict";
    var t = e.i(843476);
    e.s(["CircularProgress", 0, function({
        percentage: e,
        size: r = 40,
        strokeWidth: a = 4
    }) {
        let s = (r - a) / 2,
            i = 2 * Math.PI * s;
        return (0, t.jsxs)("div", {
            className: "relative shrink-0",
            style: {
                width: r,
                height: r
            },
            children: [(0, t.jsxs)("svg", {
                width: r,
                height: r,
                className: "-rotate-90",
                children: [(0, t.jsx)("circle", {
                    cx: r / 2,
                    cy: r / 2,
                    r: s,
                    fill: "none",
                    strokeWidth: a,
                    className: "stroke-primary/20"
                }), (0, t.jsx)("circle", {
                    cx: r / 2,
                    cy: r / 2,
                    r: s,
                    fill: "none",
                    strokeWidth: a,
                    strokeDasharray: i,
                    strokeDashoffset: i - e / 100 * i,
                    strokeLinecap: "round",
                    className: "stroke-primary transition-all"
                })]
            }), (0, t.jsxs)("div", {
                className: "absolute inset-0 flex items-center justify-center font-bold text-primary",
                style: {
                    fontSize: r <= 40 ? "0.7rem" : "0.875rem"
                },
                children: [e, "%"]
            })]
        })
    }])
}, 83611, e => {
    "use strict";
    var t = e.i(843476),
        r = e.i(271645),
        a = e.i(618566),
        s = e.i(632781),
        i = e.i(350854);
    e.s(["PrivateRoute", 0, function({
        children: e
    }) {
        let n = (0, a.useRouter)(),
            l = (0, a.usePathname)(),
            o = (0, a.useSearchParams)(),
            [d, u] = (0, r.useState)(!1),
            [c, f] = (0, r.useState)(!1);
        return ((0, r.useEffect)(() => {
            i.default.authService.isAuthenticated().then(f).catch(e => {
                console.error(e)
            }).finally(() => u(!0))
        }, []), (0, r.useEffect)(() => {
            if (!d || c) return;
            if ("/login" === l) return void n.replace("/login");
            let e = o.toString(),
                t = "/dashboard" === l ? l : `${l}${e?`?${e}`:""}`;
            n.replace(`/login?redirectTo=${encodeURIComponent(t)}`)
        }, [d, c, l, o, n]), d && c) ? (0, t.jsx)(t.Fragment, {
            children: e
        }) : (0, t.jsx)("div", {
            className: "flex h-screen items-center justify-center",
            children: (0, t.jsx)(s.Loader2, {
                className: "size-6 animate-spin text-primary"
            })
        })
    }])
}, 302747, e => {
    "use strict";
    var t = e.i(843476),
        r = e.i(975157);
    e.s(["Skeleton", 0, function({
        className: e,
        ...a
    }) {
        return (0, t.jsx)("div", {
            "data-slot": "skeleton",
            className: (0, r.cn)("animate-pulse rounded-md bg-muted", e),
            ...a
        })
    }])
}, 438583, e => {
    "use strict";
    let t = (0, e.i(456420).default)("video", [
        ["path", {
            d: "m16 13 5.223 3.482a.5.5 0 0 0 .777-.416V7.87a.5.5 0 0 0-.752-.432L16 10.5",
            key: "ftymec"
        }],
        ["rect", {
            x: "2",
            y: "6",
            width: "14",
            height: "12",
            rx: "2",
            key: "158x01"
        }]
    ]);
    e.s(["Video", 0, t], 438583)
}, 27770, e => {
    "use strict";
    let t = (0, e.i(456420).default)("list-video", [
        ["path", {
            d: "M21 5H3",
            key: "1fi0y6"
        }],
        ["path", {
            d: "M10 12H3",
            key: "1ulcyk"
        }],
        ["path", {
            d: "M10 19H3",
            key: "108z41"
        }],
        ["path", {
            d: "M15 12.003a1 1 0 0 1 1.517-.859l4.997 2.997a1 1 0 0 1 0 1.718l-4.997 2.997a1 1 0 0 1-1.517-.86z",
            key: "ms4nik"
        }]
    ]);
    e.s(["ListVideo", 0, t], 27770)
}, 263676, e => {
    "use strict";
    var t = e.i(814387);
    e.s(["X", () => t.default])
}, 348990, 346570, e => {
    "use strict";
    var t = e.i(956789),
        r = e.i(552245),
        a = e.i(395530);
    e.s(["CompositeItem", 0, function(e) {
        let {
            render: s,
            className: i,
            style: n,
            state: l = t.EMPTY_OBJECT,
            props: o = t.EMPTY_ARRAY,
            refs: d = t.EMPTY_ARRAY,
            metadata: u,
            stateAttributesMapping: c,
            tag: f = "div",
            ...h
        } = e, {
            compositeProps: p,
            compositeRef: g
        } = (0, a.useCompositeItem)({
            metadata: u
        });
        return (0, r.useRenderElement)(f, e, {
            state: l,
            ref: [...d, g],
            props: [p, ...o, h],
            stateAttributesMapping: c
        })
    }], 348990);
    var s = e.i(271645),
        i = e.i(174080),
        n = e.i(647554),
        l = e.i(383976),
        o = e.i(675606),
        d = e.i(56434);
    e.s(["useTriggerFocusGuards", 0, function(e, t) {
        let r = s.useRef(null);
        return {
            preFocusGuardRef: r,
            handlePreFocusGuardFocus: function(t) {
                i.flushSync(() => {
                    e.setOpen(!1, (0, o.createChangeEventDetails)(d.REASONS.focusOut, t.nativeEvent, t.currentTarget))
                });
                let a = (0, l.getTabbableBeforeElement)(r.current);
                a ? .focus()
            },
            handleFocusTargetFocus: function(r) {
                let a = e.select("positionerElement");
                if (a && (0, l.isOutsideEvent)(r, a)) e.context.beforeContentFocusGuardRef.current ? .focus();
                else {
                    i.flushSync(() => {
                        e.setOpen(!1, (0, o.createChangeEventDetails)(d.REASONS.focusOut, r.nativeEvent, r.currentTarget))
                    });
                    let s = (0, l.getTabbableAfterElement)(e.context.triggerFocusTargetRef.current || t.current);
                    for (; null !== s && (0, n.contains)(a, s);) {
                        let e = s;
                        if ((s = (0, l.getNextTabbable)(s)) === e) break
                    }
                    s ? .focus()
                }
            }
        }
    }], 346570)
}, 294105, e => {
    "use strict";
    let t = (0, e.i(456420).default)("layout-dashboard", [
        ["rect", {
            width: "7",
            height: "9",
            x: "3",
            y: "3",
            rx: "1",
            key: "10lvy0"
        }],
        ["rect", {
            width: "7",
            height: "5",
            x: "14",
            y: "3",
            rx: "1",
            key: "16une8"
        }],
        ["rect", {
            width: "7",
            height: "9",
            x: "14",
            y: "12",
            rx: "1",
            key: "1hutg5"
        }],
        ["rect", {
            width: "7",
            height: "5",
            x: "3",
            y: "16",
            rx: "1",
            key: "ldoo1y"
        }]
    ]);
    e.s(["LayoutDashboard", 0, t], 294105)
}, 980376, e => {
    "use strict";
    var t = e.i(843476),
        r = e.i(353753),
        a = e.i(975157),
        s = e.i(519455),
        i = e.i(560964);

    function n({ ...e
    }) {
        return (0, t.jsx)(r.Dialog.Portal, {
            "data-slot": "sheet-portal",
            ...e
        })
    }

    function l({
        className: e,
        ...s
    }) {
        return (0, t.jsx)(r.Dialog.Backdrop, {
            "data-slot": "sheet-overlay",
            className: (0, a.cn)("fixed inset-0 z-50 bg-black/10 transition-opacity duration-150 data-ending-style:opacity-0 data-starting-style:opacity-0 supports-backdrop-filter:backdrop-blur-xs", e),
            ...s
        })
    }
    e.s(["Sheet", 0, function({ ...e
    }) {
        return (0, t.jsx)(r.Dialog.Root, {
            "data-slot": "sheet",
            ...e
        })
    }, "SheetContent", 0, function({
        className: e,
        children: o,
        side: d = "right",
        showCloseButton: u = !0,
        ...c
    }) {
        return (0, t.jsxs)(n, {
            children: [(0, t.jsx)(l, {}), (0, t.jsxs)(r.Dialog.Popup, {
                "data-slot": "sheet-content",
                "data-side": d,
                className: (0, a.cn)("fixed z-50 flex flex-col gap-4 bg-popover bg-clip-padding text-sm text-popover-foreground shadow-lg transition duration-200 ease-in-out data-ending-style:opacity-0 data-starting-style:opacity-0 data-[side=bottom]:inset-x-0 data-[side=bottom]:bottom-0 data-[side=bottom]:h-auto data-[side=bottom]:border-t data-[side=bottom]:data-ending-style:translate-y-[2.5rem] data-[side=bottom]:data-starting-style:translate-y-[2.5rem] data-[side=left]:inset-y-0 data-[side=left]:left-0 data-[side=left]:h-full data-[side=left]:w-3/4 data-[side=left]:border-r data-[side=left]:data-ending-style:translate-x-[-2.5rem] data-[side=left]:data-starting-style:translate-x-[-2.5rem] data-[side=right]:inset-y-0 data-[side=right]:right-0 data-[side=right]:h-full data-[side=right]:w-3/4 data-[side=right]:border-l data-[side=right]:data-ending-style:translate-x-[2.5rem] data-[side=right]:data-starting-style:translate-x-[2.5rem] data-[side=top]:inset-x-0 data-[side=top]:top-0 data-[side=top]:h-auto data-[side=top]:border-b data-[side=top]:data-ending-style:translate-y-[-2.5rem] data-[side=top]:data-starting-style:translate-y-[-2.5rem] data-[side=left]:sm:max-w-sm data-[side=right]:sm:max-w-sm", e),
                ...c,
                children: [o, u && (0, t.jsxs)(r.Dialog.Close, {
                    "data-slot": "sheet-close",
                    render: (0, t.jsx)(s.Button, {
                        variant: "ghost",
                        className: "absolute top-4 right-4",
                        size: "icon-sm"
                    }),
                    children: [(0, t.jsx)(i.XIcon, {}), (0, t.jsx)("span", {
                        className: "sr-only",
                        children: "Close"
                    })]
                })]
            })]
        })
    }, "SheetDescription", 0, function({
        className: e,
        ...s
    }) {
        return (0, t.jsx)(r.Dialog.Description, {
            "data-slot": "sheet-description",
            className: (0, a.cn)("text-sm text-muted-foreground", e),
            ...s
        })
    }, "SheetHeader", 0, function({
        className: e,
        ...r
    }) {
        return (0, t.jsx)("div", {
            "data-slot": "sheet-header",
            className: (0, a.cn)("flex flex-col gap-1.5 p-4", e),
            ...r
        })
    }, "SheetTitle", 0, function({
        className: e,
        ...s
    }) {
        return (0, t.jsx)(r.Dialog.Title, {
            "data-slot": "sheet-title",
            className: (0, a.cn)("font-heading font-medium text-foreground", e),
            ...s
        })
    }, "SheetTrigger", 0, function({ ...e
    }) {
        return (0, t.jsx)(r.Dialog.Trigger, {
            "data-slot": "sheet-trigger",
            ...e
        })
    }])
}, 168148, e => {
    "use strict";
    var t, r = e.i(843476);
    e.s([], 570109), e.i(570109), e.i(247167);
    var a = e.i(271645),
        s = e.i(446265),
        i = e.i(502077);
    let n = new Map;

    function l(e, t, r) {
        return null == e ? "" : (function(e, t) {
            let r = JSON.stringify({
                    locale: function e(t) {
                        return Array.isArray(t) ? t.map(t => e(t)).join(",") : null == t ? "" : String(t)
                    }(e),
                    options: t
                }),
                a = n.get(r);
            if (a) return a;
            let s = new Intl.NumberFormat(e, t);
            return n.set(r, s), s
        })(t, r).format(e)
    }
    var o = e.i(552245),
        d = e.i(733332);
    let u = a.createContext(void 0);

    function c() {
        let e = a.useContext(u);
        if (void 0 === e) throw Error((0, d.default)(51));
        return e
    }
    let f = ((t = {}).complete = "data-complete", t.indeterminate = "data-indeterminate", t.progressing = "data-progressing", t),
        h = {
            status: e => "progressing" === e ? {
                [f.progressing]: ""
            } : "complete" === e ? {
                [f.complete]: ""
            } : "indeterminate" === e ? {
                [f.indeterminate]: ""
            } : null
        };

    function p(e, t) {
        return null == t ? "indeterminate progress" : e || `${t}%`
    }
    let g = a.forwardRef(function(e, t) {
            var n;
            let {
                format: d,
                getAriaValueText: c = p,
                locale: f,
                max: g = 100,
                min: m = 0,
                value: x,
                render: y,
                className: v,
                children: b,
                style: k,
                ...j
            } = e, [R, w] = a.useState(), S = (0, s.useValueAsRef)(d), E = "indeterminate";
            Number.isFinite(x) && (E = x === g ? "complete" : "progressing");
            let N = (n = S.current, null == x ? "" : n ? l(x, f, n) : l(x / 100, f, {
                    style: "percent"
                })),
                C = a.useMemo(() => ({
                    status: E
                }), [E]),
                z = {
                    "aria-labelledby": R,
                    "aria-valuemax": g,
                    "aria-valuemin": m,
                    "aria-valuenow": x ? ? void 0,
                    "aria-valuetext": c(N, x),
                    role: "progressbar",
                    children: (0, r.jsxs)(a.Fragment, {
                        children: [b, (0, r.jsx)("span", {
                            role: "presentation",
                            style: i.visuallyHidden,
                            children: "x"
                        })]
                    })
                },
                T = a.useMemo(() => ({
                    formattedValue: N,
                    max: g,
                    min: m,
                    setLabelId: w,
                    state: C,
                    status: E,
                    value: x
                }), [N, g, m, w, C, E, x]),
                A = (0, o.useRenderElement)("div", e, {
                    state: C,
                    ref: t,
                    props: [z, j],
                    stateAttributesMapping: h
                });
            return (0, r.jsx)(u.Provider, {
                value: T,
                children: A
            })
        }),
        m = a.forwardRef(function(e, t) {
            let {
                render: r,
                className: a,
                style: s,
                ...i
            } = e, {
                state: n
            } = c();
            return (0, o.useRenderElement)("div", e, {
                state: n,
                ref: t,
                props: i,
                stateAttributesMapping: h
            })
        }),
        x = a.forwardRef(function(e, t) {
            let {
                render: r,
                className: a,
                style: s,
                ...i
            } = e, {
                max: n,
                min: l,
                value: d,
                state: u
            } = c(), f = Number.isFinite(d) && null !== d ? (d - l) * 100 / (n - l) : null, p = null == f ? {} : {
                insetInlineStart: 0,
                height: "inherit",
                width: `${f}%`
            };
            return (0, o.useRenderElement)("div", e, {
                state: u,
                ref: t,
                props: [{
                    style: p
                }, i],
                stateAttributesMapping: h
            })
        }),
        y = a.forwardRef(function(e, t) {
            let {
                className: r,
                render: a,
                children: s,
                style: i,
                ...n
            } = e, {
                value: l,
                formattedValue: d,
                state: u
            } = c(), f = null == l ? "indeterminate" : d, p = null == l ? null : d;
            return (0, o.useRenderElement)("span", e, {
                state: u,
                ref: t,
                props: [{
                    "aria-hidden": !0,
                    children: "function" == typeof s ? s(f, l) : p
                }, n],
                stateAttributesMapping: h
            })
        });
    var v = e.i(757337);
    let b = a.forwardRef(function(e, t) {
        let {
            render: r,
            className: a,
            style: s,
            id: i,
            ...n
        } = e, {
            setLabelId: l,
            state: d
        } = c(), u = (0, v.useRegisteredLabelId)(i, l);
        return (0, o.useRenderElement)("span", e, {
            state: d,
            ref: t,
            props: [{
                id: u,
                role: "presentation"
            }, n],
            stateAttributesMapping: h
        })
    });
    e.s(["Indicator", 0, x, "Label", 0, b, "Root", 0, g, "Track", 0, m, "Value", 0, y], 653452);
    var k = e.i(653452),
        k = k,
        j = e.i(975157);

    function R({
        className: e,
        ...t
    }) {
        return (0, r.jsx)(k.Track, {
            className: (0, j.cn)("relative flex h-1.5 w-full items-center overflow-x-hidden rounded-full bg-muted", e),
            "data-slot": "progress-track",
            ...t
        })
    }

    function w({
        className: e,
        ...t
    }) {
        return (0, r.jsx)(k.Indicator, {
            "data-slot": "progress-indicator",
            className: (0, j.cn)("h-full bg-primary transition-all", e),
            ...t
        })
    }
    e.s(["Progress", 0, function({
        className: e,
        children: t,
        value: a,
        ...s
    }) {
        return (0, r.jsxs)(k.Root, {
            value: a,
            "data-slot": "progress",
            className: (0, j.cn)("flex flex-wrap gap-3", e),
            ...s,
            children: [t, (0, r.jsx)(R, {
                children: (0, r.jsx)(w, {})
            })]
        })
    }], 168148)
}, 177490, e => {
    "use strict";
    var t = e.i(843476),
        r = e.i(271645);
    let a = (0, e.i(456420).default)("user-round", [
        ["circle", {
            cx: "12",
            cy: "8",
            r: "5",
            key: "1hypcn"
        }],
        ["path", {
            d: "M20 21a8 8 0 0 0-16 0",
            key: "rfgkzh"
        }]
    ]);
    e.s([], 704824), e.i(704824), e.i(247167);
    var s = e.i(552245),
        i = e.i(733332);
    let n = r.createContext(void 0);

    function l() {
        let e = r.useContext(n);
        if (void 0 === e) throw Error((0, i.default)(13));
        return e
    }
    let o = {
            imageLoadingStatus: () => null
        },
        d = r.forwardRef(function(e, a) {
            let {
                className: i,
                render: l,
                style: d,
                ...u
            } = e, [c, f] = r.useState("idle"), h = r.useMemo(() => ({
                imageLoadingStatus: c,
                setImageLoadingStatus: f
            }), [c, f]), p = (0, s.useRenderElement)("span", e, {
                state: {
                    imageLoadingStatus: c
                },
                ref: a,
                props: u,
                stateAttributesMapping: o
            });
            return (0, t.jsx)(n.Provider, {
                value: h,
                children: p
            })
        });
    var u = e.i(667865),
        c = e.i(146376),
        f = e.i(137584),
        h = e.i(209407),
        p = e.i(223910),
        g = e.i(956789);
    let m = { ...o,
            ...h.transitionStatusMapping
        },
        x = r.forwardRef(function(e, t) {
            let {
                className: a,
                render: i,
                onLoadingStatusChange: n,
                style: o,
                ...d
            } = e, {
                setImageLoadingStatus: h
            } = l(), x = function(e, {
                referrerPolicy: t,
                crossOrigin: a,
                sizes: s,
                srcSet: i
            }) {
                let [n, l] = r.useState("idle");
                return (0, c.useIsoLayoutEffect)(() => {
                    if (!e && !i) return l("error"), g.NOOP;
                    let r = !0,
                        n = new window.Image,
                        o = e => () => {
                            r && l(e)
                        };
                    return l("loading"), n.onload = o("loaded"), n.onerror = o("error"), t && (n.referrerPolicy = t), n.crossOrigin = a ? ? null, s && (n.sizes = s), i && (n.srcset = i), e && (n.src = e), n.complete && l(n.naturalWidth > 0 ? "loaded" : "error"), () => {
                        r = !1
                    }
                }, [e, i, s, a, t]), n
            }(d.src, d), y = "loaded" === x, {
                mounted: v,
                transitionStatus: b,
                setMounted: k
            } = (0, p.useTransitionStatus)(y), j = r.useRef(null), R = (0, u.useStableCallback)(e => {
                n ? .(e), h(e)
            });
            (0, c.useIsoLayoutEffect)(() => {
                "idle" !== x && R(x)
            }, [x, R]), (0, c.useIsoLayoutEffect)(() => () => h("idle"), [h]), (0, f.useOpenChangeComplete)({
                open: y,
                ref: j,
                onComplete() {
                    y || k(!1)
                }
            });
            let w = (0, s.useRenderElement)("img", e, {
                state: {
                    imageLoadingStatus: x,
                    transitionStatus: b
                },
                ref: [t, j],
                props: d,
                stateAttributesMapping: m,
                enabled: v
            });
            return v ? w : null
        });
    var y = e.i(439957);
    let v = r.forwardRef(function(e, t) {
        let {
            className: a,
            render: i,
            delay: n,
            style: d,
            ...u
        } = e, {
            imageLoadingStatus: c
        } = l(), [f, h] = r.useState(void 0 === n), p = (0, y.useTimeout)();
        return r.useEffect(() => (void 0 !== n ? p.start(n, () => h(!0)) : h(!0), p.clear), [p, n]), (0, s.useRenderElement)("span", e, {
            state: {
                imageLoadingStatus: c
            },
            ref: t,
            props: u,
            stateAttributesMapping: o,
            enabled: "loaded" !== c && (void 0 === n || f)
        })
    });
    e.s(["Fallback", 0, v, "Image", 0, x, "Root", 0, d], 514751);
    var b = e.i(514751),
        b = b,
        k = e.i(975157);

    function j({
        className: e,
        size: r = "default",
        ...a
    }) {
        return (0, t.jsx)(b.Root, {
            "data-slot": "avatar",
            "data-size": r,
            className: (0, k.cn)("group/avatar relative flex size-8 shrink-0 rounded-full select-none after:absolute after:inset-0 after:rounded-full after:border after:border-border after:mix-blend-darken data-[size=lg]:size-10 data-[size=sm]:size-6 dark:after:mix-blend-lighten", e),
            ...a
        })
    }

    function R({
        className: e,
        ...r
    }) {
        return (0, t.jsx)(b.Image, {
            "data-slot": "avatar-image",
            className: (0, k.cn)("aspect-square size-full rounded-full object-cover", e),
            ...r
        })
    }

    function w({
        className: e,
        ...r
    }) {
        return (0, t.jsx)(b.Fallback, {
            "data-slot": "avatar-fallback",
            className: (0, k.cn)("flex size-full items-center justify-center rounded-full bg-muted text-sm text-muted-foreground group-data-[size=sm]/avatar:text-xs", e),
            ...r
        })
    }
    var S = e.i(350854);
    e.s(["AvatarComponent", 0, function({
        data: e,
        size: s,
        className: i
    }) {
        let [n, l] = (0, r.useState)("");
        return (0, r.useEffect)(() => {
            e.avatar && S.default.userService.getAvatar(e.avatar.charAt(0), e.avatar.split(" ")[2], e.avatar.split(" ")[1]).then(e => l(e ? ? "")).catch(e => console.error("Failed to load avatar:", e))
        }, [e.avatar]), (0, t.jsxs)(j, {
            className: (0, k.cn)("bg-muted after:hidden", i),
            style: {
                width: s,
                height: s
            },
            children: [n && (0, t.jsx)(R, {
                src: n,
                alt: "Profile Picture"
            }), (0, t.jsx)(w, {
                children: (0, t.jsx)(a, {
                    className: "size-1/2 text-muted-foreground"
                })
            })]
        })
    }], 177490)
}]);