(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 870387, 576248, 901279, e => {
    "use strict";
    var t = e.i(456420);
    let a = (0, t.default)("credit-card", [
        ["rect", {
            width: "20",
            height: "14",
            x: "2",
            y: "5",
            rx: "2",
            key: "ynyp8z"
        }],
        ["line", {
            x1: "2",
            x2: "22",
            y1: "10",
            y2: "10",
            key: "1b3vmo"
        }]
    ]);
    e.s(["CreditCard", 0, a], 870387);
    let r = (0, t.default)("circle-question-mark", [
        ["circle", {
            cx: "12",
            cy: "12",
            r: "10",
            key: "1mglay"
        }],
        ["path", {
            d: "M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3",
            key: "1u773s"
        }],
        ["path", {
            d: "M12 17h.01",
            key: "p32p05"
        }]
    ]);
    e.s(["HelpCircle", 0, r], 576248);
    let n = (0, t.default)("user", [
        ["path", {
            d: "M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",
            key: "975kel"
        }],
        ["circle", {
            cx: "12",
            cy: "7",
            r: "4",
            key: "17ys0d"
        }]
    ]);
    e.s(["User", 0, n], 901279)
}, 911825, e => {
    "use strict";
    var t = e.i(552245);
    e.s(["useRender", 0, function(e) {
        return (0, t.useRenderElement)(e.defaultTagName ? ? "div", e, e)
    }])
}, 530909, e => {
    "use strict";
    var t = e.i(843476),
        a = e.i(271645),
        r = e.i(176782),
        n = e.i(911825),
        i = e.i(225913),
        s = e.i(975157),
        o = e.i(519455),
        l = e.i(793479),
        d = e.i(772436),
        u = e.i(980376),
        c = e.i(302747),
        p = e.i(746798);
    let f = (0, e.i(456420).default)("panel-left", [
            ["rect", {
                width: "18",
                height: "18",
                x: "3",
                y: "3",
                rx: "2",
                key: "afitv7"
            }],
            ["path", {
                d: "M9 3v18",
                key: "fh3hqa"
            }]
        ]),
        g = a.createContext(null);

    function m() {
        let e = a.useContext(g);
        if (!e) throw Error("useSidebar must be used within a SidebarProvider.");
        return e
    }
    let b = (0, i.cva)("peer/menu-button group/menu-button flex w-full items-center gap-2 overflow-hidden rounded-2xl py-2 px-3 text-left text-sm ring-sidebar-ring outline-hidden transition-[width,height,padding] group-has-data-[sidebar=menu-action]/menu-item:pr-8 group-data-[collapsible=icon]:size-10! group-data-[collapsible=icon]:justify-center! group-data-[collapsible=icon]:p-2! group-data-[hovered=true]:h-auto! group-data-[hovered=true]:w-full! group-data-[hovered=true]:justify-start! group-data-[hovered=true]:py-2! group-data-[hovered=true]:px-3! hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 active:bg-sidebar-accent active:text-sidebar-accent-foreground disabled:pointer-events-none disabled:opacity-50 aria-disabled:pointer-events-none aria-disabled:opacity-50 data-open:hover:bg-sidebar-accent data-open:hover:text-sidebar-accent-foreground data-active:bg-gradient-to-l data-active:from-sidebar-primary/70 data-active:to-sidebar-primary data-active:font-medium data-active:text-sidebar-primary-foreground data-active:shadow-[0_2px_6px_-1px_color-mix(in_srgb,var(--sidebar-primary)_45%,transparent)] data-active:hover:bg-gradient-to-l data-active:hover:from-sidebar-primary/70 data-active:hover:to-sidebar-primary [&_svg]:size-5 [&_svg]:shrink-0 [&>span:last-child]:truncate group-data-[collapsible=icon]:[&>span]:hidden group-data-[hovered=true]:[&>span]:inline!", {
        variants: {
            variant: {
                default: "hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
                outline: "bg-background shadow-[0_0_0_1px_var(--sidebar-border)] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground hover:shadow-[0_0_0_1px_var(--sidebar-accent)]"
            },
            size: {
                default: "h-auto min-h-9 text-sm",
                sm: "h-7 text-xs",
                lg: "h-12 text-sm group-data-[collapsible=icon]:p-0!"
            }
        },
        defaultVariants: {
            variant: "default",
            size: "default"
        }
    });
    e.s(["Sidebar", 0, function({
        side: e = "left",
        variant: r = "sidebar",
        collapsible: n = "offcanvas",
        className: i,
        children: o,
        dir: l,
        ...d
    }) {
        let {
            isMobile: c,
            state: p,
            openMobile: f,
            setOpenMobile: g
        } = m(), [b, h] = a.useState(!1), x = "icon" === n && "collapsed" === p;
        return (a.useEffect(() => {
            x || h(!1)
        }, [x]), "none" === n) ? (0, t.jsx)("div", {
            "data-slot": "sidebar",
            className: (0, s.cn)("flex h-full w-(--sidebar-width) flex-col bg-sidebar text-sidebar-foreground", i),
            ...d,
            children: o
        }) : c ? (0, t.jsx)(u.Sheet, {
            open: f,
            onOpenChange: g,
            ...d,
            children: (0, t.jsxs)(u.SheetContent, {
                dir: l,
                "data-sidebar": "sidebar",
                "data-slot": "sidebar",
                "data-mobile": "true",
                className: "w-(--sidebar-width) bg-sidebar p-0 text-sidebar-foreground [&>button]:hidden",
                style: {
                    "--sidebar-width": "18rem"
                },
                side: e,
                children: [(0, t.jsxs)(u.SheetHeader, {
                    className: "sr-only",
                    children: [(0, t.jsx)(u.SheetTitle, {
                        children: "Sidebar"
                    }), (0, t.jsx)(u.SheetDescription, {
                        children: "Displays the mobile sidebar."
                    })]
                }), (0, t.jsx)("div", {
                    className: "flex h-full w-full flex-col",
                    children: o
                })]
            })
        }) : (0, t.jsxs)("div", {
            className: "group peer hidden text-sidebar-foreground md:block",
            "data-state": p,
            "data-collapsible": "collapsed" === p ? n : "",
            "data-hovered": x && b ? "true" : "false",
            "data-variant": r,
            "data-side": e,
            "data-slot": "sidebar",
            children: [(0, t.jsx)("div", {
                "data-slot": "sidebar-gap",
                className: (0, s.cn)("relative w-(--sidebar-width) bg-transparent transition-[width] duration-200 ease-linear", "group-data-[collapsible=offcanvas]:w-0", "group-data-[side=right]:rotate-180", "floating" === r || "inset" === r ? "group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)+(--spacing(4)))]" : "group-data-[collapsible=icon]:w-(--sidebar-width-icon)")
            }), (0, t.jsx)("div", {
                "data-slot": "sidebar-container",
                "data-side": e,
                className: (0, s.cn)("fixed inset-y-0 z-10 hidden h-svh w-(--sidebar-width) transition-[left,right,width] duration-200 ease-linear data-[side=left]:left-0 data-[side=left]:group-data-[collapsible=offcanvas]:left-[calc(var(--sidebar-width)*-1)] data-[side=right]:right-0 data-[side=right]:group-data-[collapsible=offcanvas]:right-[calc(var(--sidebar-width)*-1)] md:flex", "floating" === r || "inset" === r ? "p-2 group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)+(--spacing(4))+2px)]" : "group-data-[collapsible=icon]:w-(--sidebar-width-icon) group-data-[side=left]:border-r group-data-[side=right]:border-l", "group-data-[hovered=true]:w-(--sidebar-width)! group-data-[hovered=true]:z-20 group-data-[hovered=true]:shadow-2xl", i),
                onMouseEnter: x ? () => h(!0) : void 0,
                onMouseLeave: x ? () => h(!1) : void 0,
                ...d,
                children: (0, t.jsx)("div", {
                    "data-sidebar": "sidebar",
                    "data-slot": "sidebar-inner",
                    className: "flex size-full flex-col bg-sidebar group-data-[variant=floating]:rounded-lg group-data-[variant=floating]:shadow-sm group-data-[variant=floating]:ring-1 group-data-[variant=floating]:ring-sidebar-border",
                    children: o
                })
            })]
        })
    }, "SidebarContent", 0, function({
        className: e,
        ...a
    }) {
        return (0, t.jsx)("div", {
            "data-slot": "sidebar-content",
            "data-sidebar": "content",
            className: (0, s.cn)("no-scrollbar flex min-h-0 flex-1 flex-col gap-2 overflow-auto group-data-[collapsible=icon]:overflow-hidden", e),
            ...a
        })
    }, "SidebarFooter", 0, function({
        className: e,
        ...a
    }) {
        return (0, t.jsx)("div", {
            "data-slot": "sidebar-footer",
            "data-sidebar": "footer",
            className: (0, s.cn)("flex flex-col gap-2 p-2", e),
            ...a
        })
    }, "SidebarGroup", 0, function({
        className: e,
        ...a
    }) {
        return (0, t.jsx)("div", {
            "data-slot": "sidebar-group",
            "data-sidebar": "group",
            className: (0, s.cn)("relative flex w-full min-w-0 flex-col p-2", e),
            ...a
        })
    }, "SidebarGroupAction", 0, function({
        className: e,
        render: t,
        ...a
    }) {
        return (0, n.useRender)({
            defaultTagName: "button",
            props: (0, r.mergeProps)({
                className: (0, s.cn)("absolute top-3.5 right-3 flex aspect-square w-5 items-center justify-center rounded-md p-0 text-sidebar-foreground ring-sidebar-ring outline-hidden transition-transform group-data-[collapsible=icon]:hidden after:absolute after:-inset-2 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 md:after:hidden [&>svg]:size-4 [&>svg]:shrink-0", e)
            }, a),
            render: t,
            state: {
                slot: "sidebar-group-action",
                sidebar: "group-action"
            }
        })
    }, "SidebarGroupContent", 0, function({
        className: e,
        ...a
    }) {
        return (0, t.jsx)("div", {
            "data-slot": "sidebar-group-content",
            "data-sidebar": "group-content",
            className: (0, s.cn)("w-full text-sm", e),
            ...a
        })
    }, "SidebarGroupLabel", 0, function({
        className: e,
        render: t,
        ...a
    }) {
        return (0, n.useRender)({
            defaultTagName: "div",
            props: (0, r.mergeProps)({
                className: (0, s.cn)("flex h-8 shrink-0 items-center rounded-md px-2 text-xs font-medium text-sidebar-foreground/70 ring-sidebar-ring outline-hidden transition-[margin,opacity] duration-200 ease-linear group-data-[collapsible=icon]:-mt-8 group-data-[collapsible=icon]:opacity-0 group-data-[hovered=true]:mt-0! group-data-[hovered=true]:opacity-100! focus-visible:ring-2 [&>svg]:size-4 [&>svg]:shrink-0", e)
            }, a),
            render: t,
            state: {
                slot: "sidebar-group-label",
                sidebar: "group-label"
            }
        })
    }, "SidebarHeader", 0, function({
        className: e,
        ...a
    }) {
        return (0, t.jsx)("div", {
            "data-slot": "sidebar-header",
            "data-sidebar": "header",
            className: (0, s.cn)("flex flex-col gap-2 p-2", e),
            ...a
        })
    }, "SidebarInput", 0, function({
        className: e,
        ...a
    }) {
        return (0, t.jsx)(l.Input, {
            "data-slot": "sidebar-input",
            "data-sidebar": "input",
            className: (0, s.cn)("h-8 w-full bg-background shadow-none", e),
            ...a
        })
    }, "SidebarInset", 0, function({
        className: e,
        ...a
    }) {
        return (0, t.jsx)("main", {
            "data-slot": "sidebar-inset",
            className: (0, s.cn)("relative flex w-full flex-1 flex-col bg-background md:peer-data-[variant=inset]:m-2 md:peer-data-[variant=inset]:ml-0 md:peer-data-[variant=inset]:rounded-xl md:peer-data-[variant=inset]:shadow-sm md:peer-data-[variant=inset]:peer-data-[state=collapsed]:ml-2", e),
            ...a
        })
    }, "SidebarMenu", 0, function({
        className: e,
        ...a
    }) {
        return (0, t.jsx)("ul", {
            "data-slot": "sidebar-menu",
            "data-sidebar": "menu",
            className: (0, s.cn)("flex w-full min-w-0 flex-col gap-1 group-data-[collapsible=icon]:items-center group-data-[hovered=true]:items-stretch!", e),
            ...a
        })
    }, "SidebarMenuAction", 0, function({
        className: e,
        render: t,
        showOnHover: a = !1,
        ...i
    }) {
        return (0, n.useRender)({
            defaultTagName: "button",
            props: (0, r.mergeProps)({
                className: (0, s.cn)("absolute top-1.5 right-1 flex aspect-square w-5 items-center justify-center rounded-md p-0 text-sidebar-foreground ring-sidebar-ring outline-hidden transition-transform group-data-[collapsible=icon]:hidden peer-hover/menu-button:text-sidebar-accent-foreground peer-data-[size=default]/menu-button:top-1.5 peer-data-[size=lg]/menu-button:top-2.5 peer-data-[size=sm]/menu-button:top-1 after:absolute after:-inset-2 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 md:after:hidden [&>svg]:size-4 [&>svg]:shrink-0", a && "group-focus-within/menu-item:opacity-100 group-hover/menu-item:opacity-100 peer-data-active/menu-button:text-sidebar-accent-foreground aria-expanded:opacity-100 md:opacity-0", e)
            }, i),
            render: t,
            state: {
                slot: "sidebar-menu-action",
                sidebar: "menu-action"
            }
        })
    }, "SidebarMenuBadge", 0, function({
        className: e,
        ...a
    }) {
        return (0, t.jsx)("div", {
            "data-slot": "sidebar-menu-badge",
            "data-sidebar": "menu-badge",
            className: (0, s.cn)("pointer-events-none absolute right-1 flex h-5 min-w-5 items-center justify-center rounded-md px-1 text-xs font-medium text-sidebar-foreground tabular-nums select-none group-data-[collapsible=icon]:hidden peer-hover/menu-button:text-sidebar-accent-foreground peer-data-[size=default]/menu-button:top-1.5 peer-data-[size=lg]/menu-button:top-2.5 peer-data-[size=sm]/menu-button:top-1 peer-data-active/menu-button:text-sidebar-accent-foreground", e),
            ...a
        })
    }, "SidebarMenuButton", 0, function({
        render: e,
        isActive: a = !1,
        variant: i = "default",
        size: o = "default",
        tooltip: l,
        className: d,
        ...u
    }) {
        let {
            isMobile: c,
            state: f
        } = m(), g = (0, n.useRender)({
            defaultTagName: "button",
            props: (0, r.mergeProps)({
                className: (0, s.cn)(b({
                    variant: i,
                    size: o
                }), d)
            }, u),
            render: l ? (0, t.jsx)(p.TooltipTrigger, {
                render: e
            }) : e,
            state: {
                slot: "sidebar-menu-button",
                sidebar: "menu-button",
                size: o,
                active: a
            }
        });
        return l ? ("string" == typeof l && (l = {
            children: l
        }), (0, t.jsxs)(p.Tooltip, {
            children: [g, (0, t.jsx)(p.TooltipContent, {
                side: "right",
                align: "center",
                hidden: "collapsed" !== f || c,
                ...l
            })]
        })) : g
    }, "SidebarMenuItem", 0, function({
        className: e,
        ...a
    }) {
        return (0, t.jsx)("li", {
            "data-slot": "sidebar-menu-item",
            "data-sidebar": "menu-item",
            className: (0, s.cn)("group/menu-item relative", e),
            ...a
        })
    }, "SidebarMenuSkeleton", 0, function({
        className: e,
        showIcon: r = !1,
        ...n
    }) {
        let [i] = a.useState(() => `${Math.floor(40*Math.random())+50}%`);
        return (0, t.jsxs)("div", {
            "data-slot": "sidebar-menu-skeleton",
            "data-sidebar": "menu-skeleton",
            className: (0, s.cn)("flex h-8 items-center gap-2 rounded-md px-2", e),
            ...n,
            children: [r && (0, t.jsx)(c.Skeleton, {
                className: "size-4 rounded-md",
                "data-sidebar": "menu-skeleton-icon"
            }), (0, t.jsx)(c.Skeleton, {
                className: "h-4 max-w-(--skeleton-width) flex-1",
                "data-sidebar": "menu-skeleton-text",
                style: {
                    "--skeleton-width": i
                }
            })]
        })
    }, "SidebarMenuSub", 0, function({
        className: e,
        ...a
    }) {
        return (0, t.jsx)("ul", {
            "data-slot": "sidebar-menu-sub",
            "data-sidebar": "menu-sub",
            className: (0, s.cn)("mx-3.5 flex min-w-0 translate-x-px flex-col gap-1 border-l border-sidebar-border px-2.5 py-0.5 group-data-[collapsible=icon]:hidden", e),
            ...a
        })
    }, "SidebarMenuSubButton", 0, function({
        render: e,
        size: t = "md",
        isActive: a = !1,
        className: i,
        ...o
    }) {
        return (0, n.useRender)({
            defaultTagName: "a",
            props: (0, r.mergeProps)({
                className: (0, s.cn)("flex h-7 min-w-0 -translate-x-px items-center gap-2 overflow-hidden rounded-md px-2 text-sidebar-foreground ring-sidebar-ring outline-hidden group-data-[collapsible=icon]:hidden hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 active:bg-sidebar-accent active:text-sidebar-accent-foreground disabled:pointer-events-none disabled:opacity-50 aria-disabled:pointer-events-none aria-disabled:opacity-50 data-[size=md]:text-sm data-[size=sm]:text-xs data-active:bg-sidebar-accent data-active:text-sidebar-accent-foreground [&>span:last-child]:truncate [&>svg]:size-4 [&>svg]:shrink-0 [&>svg]:text-sidebar-accent-foreground", i)
            }, o),
            render: e,
            state: {
                slot: "sidebar-menu-sub-button",
                sidebar: "menu-sub-button",
                size: t,
                active: a
            }
        })
    }, "SidebarMenuSubItem", 0, function({
        className: e,
        ...a
    }) {
        return (0, t.jsx)("li", {
            "data-slot": "sidebar-menu-sub-item",
            "data-sidebar": "menu-sub-item",
            className: (0, s.cn)("group/menu-sub-item relative", e),
            ...a
        })
    }, "SidebarProvider", 0, function({
        defaultOpen: e = !0,
        open: r,
        onOpenChange: n,
        className: i,
        style: o,
        children: l,
        ...d
    }) {
        let u = function() {
                let [e, t] = a.useState(void 0);
                return a.useEffect(() => {
                    let e = window.matchMedia("(max-width: 767px)"),
                        a = () => {
                            t(window.innerWidth < 768)
                        };
                    return e.addEventListener("change", a), t(window.innerWidth < 768), () => e.removeEventListener("change", a)
                }, []), !!e
            }(),
            [c, p] = a.useState(!1),
            [f, m] = a.useState(e),
            b = r ? ? f,
            h = a.useCallback(e => {
                let t = "function" == typeof e ? e(b) : e;
                n ? n(t) : m(t), document.cookie = `sidebar_state=${t}; path=/; max-age=604800`
            }, [n, b]),
            x = a.useCallback(() => u ? p(e => !e) : h(e => !e), [u, h, p]);
        a.useEffect(() => {
            let e = e => {
                "b" === e.key && (e.metaKey || e.ctrlKey) && (e.preventDefault(), x())
            };
            return window.addEventListener("keydown", e), () => window.removeEventListener("keydown", e)
        }, [x]);
        let v = b ? "expanded" : "collapsed",
            S = a.useMemo(() => ({
                state: v,
                open: b,
                setOpen: h,
                isMobile: u,
                openMobile: c,
                setOpenMobile: p,
                toggleSidebar: x
            }), [v, b, h, u, c, p, x]);
        return (0, t.jsx)(g.Provider, {
            value: S,
            children: (0, t.jsx)("div", {
                "data-slot": "sidebar-wrapper",
                style: {
                    "--sidebar-width": "260px",
                    "--sidebar-width-icon": "71px",
                    ...o
                },
                className: (0, s.cn)("group/sidebar-wrapper flex min-h-svh w-full has-data-[variant=inset]:bg-sidebar", i),
                ...d,
                children: l
            })
        })
    }, "SidebarRail", 0, function({
        className: e,
        ...a
    }) {
        let {
            toggleSidebar: r
        } = m();
        return (0, t.jsx)("button", {
            "data-sidebar": "rail",
            "data-slot": "sidebar-rail",
            "aria-label": "Toggle Sidebar",
            tabIndex: -1,
            onClick: r,
            title: "Toggle Sidebar",
            className: (0, s.cn)("absolute inset-y-0 z-20 hidden w-4 transition-all ease-linear group-data-[side=left]:-right-4 group-data-[side=right]:left-0 after:absolute after:inset-y-0 after:start-1/2 after:w-[2px] hover:after:bg-sidebar-border sm:flex ltr:-translate-x-1/2 rtl:-translate-x-1/2", "in-data-[side=left]:cursor-w-resize in-data-[side=right]:cursor-e-resize", "[[data-side=left][data-state=collapsed]_&]:cursor-e-resize [[data-side=right][data-state=collapsed]_&]:cursor-w-resize", "group-data-[collapsible=offcanvas]:translate-x-0 group-data-[collapsible=offcanvas]:after:left-full hover:group-data-[collapsible=offcanvas]:bg-sidebar", "[[data-side=left][data-collapsible=offcanvas]_&]:-right-2", "[[data-side=right][data-collapsible=offcanvas]_&]:-left-2", e),
            ...a
        })
    }, "SidebarSeparator", 0, function({
        className: e,
        ...a
    }) {
        return (0, t.jsx)(d.Separator, {
            "data-slot": "sidebar-separator",
            "data-sidebar": "separator",
            className: (0, s.cn)("mx-2 w-auto bg-sidebar-border", e),
            ...a
        })
    }, "SidebarTrigger", 0, function({
        className: e,
        onClick: a,
        ...r
    }) {
        let {
            toggleSidebar: n
        } = m();
        return (0, t.jsxs)(o.Button, {
            "data-sidebar": "trigger",
            "data-slot": "sidebar-trigger",
            variant: "ghost",
            size: "icon-sm",
            className: (0, s.cn)(e),
            onClick: e => {
                a ? .(e), n()
            },
            ...r,
            children: [(0, t.jsx)(f, {}), (0, t.jsx)("span", {
                className: "sr-only",
                children: "Toggle Sidebar"
            })]
        })
    }, "useSidebar", 0, m], 530909)
}, 880144, e => {
    "use strict";
    var t = e.i(843476),
        a = e.i(657688),
        r = e.i(522016),
        n = e.i(618566),
        i = e.i(856423),
        s = e.i(564346),
        o = e.i(456420);
    let l = (0, o.default)("circle-dot", [
            ["circle", {
                cx: "12",
                cy: "12",
                r: "10",
                key: "1mglay"
            }],
            ["circle", {
                cx: "12",
                cy: "12",
                r: "1",
                key: "41hilf"
            }]
        ]),
        d = (0, o.default)("coins", [
            ["path", {
                d: "M13.744 17.736a6 6 0 1 1-7.48-7.48",
                key: "bq4yh3"
            }],
            ["path", {
                d: "M15 6h1v4",
                key: "11y1tn"
            }],
            ["path", {
                d: "m6.134 14.768.866-.5 2 3.464",
                key: "17snzx"
            }],
            ["circle", {
                cx: "16",
                cy: "8",
                r: "6",
                key: "14bfc9"
            }]
        ]);
    var u = e.i(870387);
    let c = (0, o.default)("external-link", [
            ["path", {
                d: "M15 3h6v6",
                key: "1q9fwt"
            }],
            ["path", {
                d: "M10 14 21 3",
                key: "gplh6r"
            }],
            ["path", {
                d: "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6",
                key: "a6xqqp"
            }]
        ]),
        p = (0, o.default)("gallery-vertical-end", [
            ["path", {
                d: "M7 2h10",
                key: "nczekb"
            }],
            ["path", {
                d: "M5 6h14",
                key: "u2x4p"
            }],
            ["rect", {
                width: "18",
                height: "12",
                x: "3",
                y: "10",
                rx: "2",
                key: "l0tzu3"
            }]
        ]);
    var f = e.i(576248),
        g = e.i(294105),
        m = e.i(27770),
        b = e.i(615331),
        h = e.i(901279),
        x = e.i(438583),
        v = e.i(263676),
        S = e.i(530909),
        y = e.i(604829);
    let w = [{
            label: "Dashboard",
            href: "/dashboard",
            icon: g.LayoutDashboard
        }, {
            label: "Stream",
            href: "/stream",
            icon: b.Radio,
            activePrefix: "/stream"
        }, {
            label: "Media Library",
            href: "/media-library",
            icon: p,
            activePrefix: "/media-library"
        }, {
            label: "Playlist",
            href: "/playlist",
            icon: m.ListVideo
        }, {
            label: "Plans",
            href: "/plans/add-plans",
            icon: d,
            activePrefix: "/plans"
        }],
        j = [{
            label: "Profile",
            href: "/profile",
            icon: h.User,
            activePrefix: "/profile"
        }, {
            label: "Billing",
            href: "/billing",
            icon: u.CreditCard,
            activePrefix: "/billing"
        }],
        R = [{
            label: "Help",
            href: "/contact-us",
            icon: f.HelpCircle,
            external: !0
        }, {
            label: "Video Tutorials",
            href: y.FooterSocialType.YOUTUBE,
            icon: x.Video,
            external: !0
        }, {
            label: "Knowledge Base",
            href: "/articles/",
            icon: i.BookOpen,
            external: !0
        }];

    function C(e, t) {
        return t.activePrefix ? e.startsWith(t.activePrefix) : e === t.href
    }
    e.s(["AppSidebar", 0, function() {
        let e = (0, n.usePathname)(),
            {
                state: i,
                isMobile: o,
                toggleSidebar: d
            } = (0, S.useSidebar)();
        return (0, t.jsxs)(S.Sidebar, {
            collapsible: "icon",
            children: [(0, t.jsxs)(S.SidebarHeader, {
                className: "flex-row items-center justify-between p-[15px] pl-5 group-data-[collapsible=icon]:justify-center group-data-[collapsible=icon]:px-0 group-data-[hovered=true]:justify-between! group-data-[hovered=true]:px-5!",
                children: [(0, t.jsx)(r.default, {
                    href: "/",
                    target: "_blank",
                    className: "group-data-[collapsible=icon]:hidden group-data-[hovered=true]:block!",
                    children: (0, t.jsx)(a.default, {
                        src: "/images/logo/loop-logo.webp",
                        alt: "Loop Stream",
                        width: 140,
                        height: 70,
                        priority: !0,
                        className: "h-12 w-auto"
                    })
                }), (0, t.jsx)(r.default, {
                    href: "/",
                    target: "_blank",
                    className: "hidden group-data-[collapsible=icon]:block group-data-[hovered=true]:hidden!",
                    children: (0, t.jsx)(a.default, {
                        src: "/images/logo/logo.webp",
                        alt: "Loop Stream",
                        width: 32,
                        height: 32,
                        priority: !0,
                        className: "size-12"
                    })
                }), (0, t.jsx)("button", {
                    type: "button",
                    onClick: d,
                    "aria-label": o ? "Close sidebar" : "expanded" === i ? "Collapse sidebar" : "Expand sidebar",
                    className: "text-sidebar-foreground/70 hover:text-sidebar-foreground group-data-[collapsible=icon]:hidden group-data-[hovered=true]:block!",
                    children: o ? (0, t.jsx)(v.X, {
                        className: "size-5"
                    }) : "expanded" === i ? (0, t.jsx)(l, {
                        className: "size-5"
                    }) : (0, t.jsx)(s.Circle, {
                        className: "size-5"
                    })
                })]
            }), (0, t.jsxs)(S.SidebarContent, {
                children: [(0, t.jsx)(S.SidebarGroup, {
                    children: (0, t.jsx)(S.SidebarGroupContent, {
                        children: (0, t.jsx)(S.SidebarMenu, {
                            children: w.map(a => (0, t.jsx)(S.SidebarMenuItem, {
                                children: (0, t.jsxs)(S.SidebarMenuButton, {
                                    render: (0, t.jsx)(r.default, {
                                        href: a.href
                                    }),
                                    isActive: C(e, a),
                                    children: [(0, t.jsx)(a.icon, {}), (0, t.jsx)("span", {
                                        children: a.label
                                    })]
                                })
                            }, a.href))
                        })
                    })
                }), (0, t.jsxs)(S.SidebarGroup, {
                    children: [(0, t.jsx)(S.SidebarGroupLabel, {
                        className: "uppercase tracking-wide",
                        children: "Account Management"
                    }), (0, t.jsx)(S.SidebarGroupContent, {
                        children: (0, t.jsx)(S.SidebarMenu, {
                            children: j.map(a => (0, t.jsx)(S.SidebarMenuItem, {
                                children: (0, t.jsxs)(S.SidebarMenuButton, {
                                    render: (0, t.jsx)(r.default, {
                                        href: a.href
                                    }),
                                    isActive: C(e, a),
                                    children: [(0, t.jsx)(a.icon, {}), (0, t.jsx)("span", {
                                        children: a.label
                                    })]
                                })
                            }, a.href))
                        })
                    })]
                }), (0, t.jsxs)(S.SidebarGroup, {
                    children: [(0, t.jsx)(S.SidebarGroupLabel, {
                        className: "uppercase tracking-wide",
                        children: "Help & Resources"
                    }), (0, t.jsx)(S.SidebarGroupContent, {
                        children: (0, t.jsx)(S.SidebarMenu, {
                            children: R.map(e => (0, t.jsx)(S.SidebarMenuItem, {
                                children: (0, t.jsxs)(S.SidebarMenuButton, {
                                    render: (0, t.jsx)("a", {
                                        href: e.href,
                                        target: "_blank",
                                        rel: "noopener noreferrer"
                                    }),
                                    children: [(0, t.jsx)(e.icon, {}), (0, t.jsx)("span", {
                                        children: e.label
                                    }), (0, t.jsx)(c, {
                                        className: "ml-auto opacity-60 group-data-[collapsible=icon]:hidden group-data-[hovered=true]:inline!"
                                    })]
                                })
                            }, e.href))
                        })
                    })]
                })]
            })]
        })
    }], 880144)
}, 956355, e => {
    "use strict";
    var t = e.i(843476),
        a = e.i(271645),
        r = e.i(522016),
        n = e.i(618566),
        i = e.i(176782),
        s = e.i(911825),
        o = e.i(975157),
        l = e.i(746336);

    function d({
        className: e,
        ...a
    }) {
        return (0, t.jsx)("nav", {
            "aria-label": "breadcrumb",
            "data-slot": "breadcrumb",
            className: (0, o.cn)(e),
            ...a
        })
    }

    function u({
        className: e,
        ...a
    }) {
        return (0, t.jsx)("ol", {
            "data-slot": "breadcrumb-list",
            className: (0, o.cn)("flex flex-wrap items-center gap-1.5 text-sm wrap-break-word text-muted-foreground sm:gap-2.5", e),
            ...a
        })
    }

    function c({
        className: e,
        ...a
    }) {
        return (0, t.jsx)("li", {
            "data-slot": "breadcrumb-item",
            className: (0, o.cn)("inline-flex items-center gap-1.5", e),
            ...a
        })
    }

    function p({
        className: e,
        render: t,
        ...a
    }) {
        return (0, s.useRender)({
            defaultTagName: "a",
            props: (0, i.mergeProps)({
                className: (0, o.cn)("transition-colors hover:text-foreground", e)
            }, a),
            render: t,
            state: {
                slot: "breadcrumb-link"
            }
        })
    }

    function f({
        className: e,
        ...a
    }) {
        return (0, t.jsx)("span", {
            "data-slot": "breadcrumb-page",
            role: "link",
            "aria-disabled": "true",
            "aria-current": "page",
            className: (0, o.cn)("font-normal text-foreground", e),
            ...a
        })
    }

    function g({
        children: e,
        className: a,
        ...r
    }) {
        return (0, t.jsx)("li", {
            "data-slot": "breadcrumb-separator",
            role: "presentation",
            "aria-hidden": "true",
            className: (0, o.cn)("[&>svg]:size-3.5", a),
            ...r,
            children: e ? ? (0, t.jsx)(l.ChevronRightIcon, {})
        })
    }
    e.i(619928);
    let m = [{
        pattern: /^\/stream\/[^/]+$/,
        items: [{
            label: "Streams",
            href: "/stream"
        }, {
            label: "Stream Details"
        }]
    }, {
        pattern: /^\/stream$/,
        items: [{
            label: "Streams"
        }]
    }, {
        pattern: /^\/media-library$/,
        items: [{
            label: "Media Library"
        }]
    }, {
        pattern: /^\/billing\/[^/]+$/,
        items: [{
            label: "Billing",
            href: "/billing"
        }, {
            label: "Order Details"
        }]
    }, {
        pattern: /^\/billing$/,
        items: [{
            label: "Billing"
        }]
    }, {
        pattern: /^\/playlist$/,
        items: [{
            label: "Playlist"
        }]
    }, {
        pattern: /^\/profile$/,
        items: [{
            label: "Profile"
        }]
    }, {
        pattern: /^\/plans\/add-plans$/,
        items: [{
            label: "Plans",
            href: "/plans/overview"
        }, {
            label: "Add Plans"
        }]
    }, {
        pattern: /^\/plans(\/overview)?$/,
        items: [{
            label: "Plans"
        }]
    }];
    e.s(["HeaderBreadcrumb", 0, function() {
        let e = (0, n.usePathname)(),
            i = m.find(t => t.pattern.test(e)) ? .items;
        return i ? (0, t.jsx)(d, {
            className: "min-w-0",
            children: (0, t.jsxs)(u, {
                className: "flex-nowrap overflow-hidden",
                children: [(0, t.jsx)(c, {
                    children: (0, t.jsx)(p, {
                        render: (0, t.jsx)(r.default, {
                            href: "/dashboard"
                        }),
                        children: "Dashboard"
                    })
                }), i.map(e => (0, t.jsxs)(a.Fragment, {
                    children: [(0, t.jsx)(g, {}), (0, t.jsx)(c, {
                        className: "min-w-0",
                        children: e.href ? (0, t.jsx)(p, {
                            render: (0, t.jsx)(r.default, {
                                href: e.href
                            }),
                            children: e.label
                        }) : (0, t.jsx)(f, {
                            className: "truncate",
                            children: e.label
                        })
                    })]
                }, e.label))]
            })
        }) : null
    }], 956355)
}, 515355, e => {
    "use strict";
    var t = e.i(843476),
        a = e.i(271645),
        r = e.i(702598),
        n = e.i(772436),
        i = e.i(350854),
        s = e.i(604829);
    e.s(["StorageWidget", 0, function() {
        let [e, o] = (0, a.useState)({
            usedStorage: 0,
            storage: 0
        }), [l, d] = (0, a.useState)([]);
        (0, a.useEffect)(() => {
            let e = !1;
            return i.default.userService.getUserStorageAndPlaylistAndStreamCount().then(t => {
                e || (o({
                    usedStorage: t.storage ? .usedStorage || 0,
                    storage: t.storage ? .storage || 0
                }), d(t.playlistCount ? .playlistCount || []))
            }).catch(() => {}), () => {
                e = !0
            }
        }, []);
        let u = e.storage > 0 ? Math.round(e.usedStorage / e.storage * 100) : 0;
        return (0, t.jsxs)("div", {
            className: "hidden items-center gap-3 md:flex",
            children: [(0, t.jsxs)("div", {
                className: "flex items-center gap-2",
                children: [(0, t.jsx)(r.CircularProgress, {
                    percentage: u
                }), (0, t.jsxs)("div", {
                    className: "flex flex-col",
                    children: [(0, t.jsx)("span", {
                        className: "text-xs text-muted-foreground",
                        children: "Storage"
                    }), (0, t.jsx)("span", {
                        className: "text-xs text-muted-foreground",
                        children: 0 === e.storage ? "No storage" : (0, t.jsxs)(t.Fragment, {
                            children: [(0, t.jsx)("span", {
                                className: "font-bold text-primary",
                                children: s.default.formatBytes(e.usedStorage)
                            }), ` / ${s.default.formatBytes(e.storage)}`]
                        })
                    })]
                })]
            }), l.length > 0 && (0, t.jsxs)(t.Fragment, {
                children: [(0, t.jsx)(n.Separator, {
                    orientation: "vertical",
                    className: "h-8"
                }), (0, t.jsx)("div", {
                    className: "flex items-center gap-3 overflow-x-auto",
                    children: l.map(e => {
                        let a = e.totalCount > 0 ? Math.round(e.usedCount / e.totalCount * 100) : 0;
                        return (0, t.jsxs)("div", {
                            className: "flex shrink-0 items-center gap-2",
                            children: [(0, t.jsx)(r.CircularProgress, {
                                percentage: a
                            }), (0, t.jsxs)("div", {
                                className: "flex flex-col",
                                children: [(0, t.jsx)("span", {
                                    className: "text-xs text-muted-foreground",
                                    children: s.default.getPlanNameFromStreamType(e.category)
                                }), (0, t.jsxs)("span", {
                                    className: "flex items-baseline gap-1.5 text-xs text-muted-foreground",
                                    children: [(0, t.jsxs)("span", {
                                        children: [(0, t.jsx)("span", {
                                            className: "font-bold text-primary",
                                            children: e.usedCount
                                        }), ` / ${e.totalCount}`]
                                    }), (0, t.jsx)("span", {
                                        className: "text-primary",
                                        children: "Playlist"
                                    })]
                                })]
                            })]
                        }, e.category)
                    })
                })]
            })]
        })
    }])
}, 331278, e => {
    "use strict";
    var t, a, r = e.i(843476),
        n = e.i(271645),
        i = e.i(618566),
        s = e.i(870387),
        o = e.i(576248);
    let l = (0, e.i(456420).default)("log-out", [
        ["path", {
            d: "m16 17 5-5-5-5",
            key: "1bji2h"
        }],
        ["path", {
            d: "M21 12H9",
            key: "dn1m92"
        }],
        ["path", {
            d: "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",
            key: "1uf3rs"
        }]
    ]);
    var d = e.i(901279),
        u = e.i(846696),
        c = e.i(519455);
    e.s([], 261027), e.i(261027), e.i(247167);
    var p = e.i(733332);
    let f = n.createContext(void 0);

    function g(e) {
        let t = n.useContext(f);
        if (void 0 === t && !e) throw Error((0, p.default)(33));
        return t
    }
    let m = n.createContext(void 0);

    function b(e) {
        let t = n.useContext(m);
        if (void 0 === t && !e) throw Error((0, p.default)(36));
        return t
    }
    var h = e.i(552245),
        x = e.i(405005);
    let v = n.forwardRef(function(e, t) {
        let {
            render: a,
            className: r,
            style: n,
            ...i
        } = e, {
            store: s
        } = b(), {
            arrowRef: o,
            side: l,
            align: d,
            arrowUncentered: u,
            arrowStyles: c
        } = g(), p = s.useState("open");
        return (0, h.useRenderElement)("div", e, {
            ref: [o, t],
            stateAttributesMapping: x.popupStateMapping,
            state: {
                open: p,
                side: l,
                align: d,
                uncentered: u
            },
            props: {
                style: c,
                "aria-hidden": !0,
                ...i
            }
        })
    });
    var S = e.i(209407);
    let y = n.createContext(void 0);

    function w(e = !0) {
        let t = n.useContext(y);
        if (void 0 === t && !e) throw Error((0, p.default)(25));
        return t
    }
    var j = e.i(56434);
    let R = { ...x.popupStateMapping,
            ...S.transitionStatusMapping
        },
        C = n.forwardRef(function(e, t) {
            let {
                render: a,
                className: r,
                style: n,
                ...i
            } = e, {
                store: s
            } = b(), o = s.useState("open"), l = s.useState("mounted"), d = s.useState("transitionStatus"), u = s.useState("lastOpenChangeReason"), c = w();
            return (0, h.useRenderElement)("div", e, {
                ref: c ? .backdropRef ? [t, c.backdropRef] : t,
                state: {
                    open: o,
                    transitionStatus: d
                },
                stateAttributesMapping: R,
                props: [{
                    role: "presentation",
                    hidden: !l,
                    style: {
                        pointerEvents: u === j.REASONS.triggerHover ? "none" : void 0,
                        userSelect: "none",
                        WebkitUserSelect: "none"
                    }
                }, i]
            })
        });
    var E = e.i(951437);
    let N = n.createContext(void 0);
    var k = e.i(828918),
        I = e.i(540886),
        P = e.i(176782),
        M = e.i(328744);

    function T(e) {
        let {
            closeOnClick: t,
            highlighted: a,
            id: r,
            nodeId: i,
            store: s,
            typingRef: o,
            itemRef: l,
            itemMetadata: d
        } = e, {
            events: u
        } = s.useState("floatingTreeRoot"), c = s.useState("open"), p = w(!0), f = void 0 !== p;
        return n.useMemo(() => ({
            id: r,
            role: "menuitem",
            tabIndex: c && a ? 0 : -1,
            onKeyDown(e) {
                " " === e.key && o ? .current && e.preventDefault()
            },
            onMouseMove(e) {
                i && u.emit("itemhover", {
                    nodeId: i,
                    target: e.currentTarget
                })
            },
            onClick(e) {
                t && u.emit("close", {
                    domEvent: e,
                    reason: j.REASONS.itemPress
                })
            },
            onMouseUp(e) {
                if (p) {
                    let t = p.initialCursorPointRef.current;
                    if (p.initialCursorPointRef.current = null, f && t && 1 >= Math.abs(e.clientX - t.x) && 1 >= Math.abs(e.clientY - t.y) || f && !M.platform.os.mac && 2 === e.button) return
                }
                l.current && s.context.allowMouseUpTriggerRef.current && (!f || 2 === e.button) && (!d || "regular-item" === d.type) && l.current.click()
            }
        }), [t, a, r, u, i, c, s, o, l, p, f, d])
    }
    let O = {
        type: "regular-item"
    };

    function A(e) {
        let {
            closeOnClick: t,
            disabled: a = !1,
            highlighted: r,
            id: i,
            store: s,
            typingRef: o = s.context.typingRef,
            nativeButton: l,
            itemMetadata: d,
            nodeId: u
        } = e, c = s.useState("disabled"), p = n.useRef(null), {
            getButtonProps: f,
            buttonRef: g
        } = (0, I.useButton)({
            disabled: a || c,
            focusableWhenDisabled: !0,
            native: l,
            composite: !0
        }), m = T({
            closeOnClick: t,
            highlighted: r,
            id: i,
            nodeId: u,
            store: s,
            typingRef: o,
            itemRef: p,
            itemMetadata: d
        }), b = n.useCallback(e => (0, P.mergeProps)(m, {
            onMouseEnter() {
                "submenu-trigger" === d.type && d.setActive()
            }
        }, e, f), [m, f, d]), h = (0, k.useMergedRefs)(p, g);
        return n.useMemo(() => ({
            getItemProps: b,
            itemRef: h
        }), [b, h])
    }
    var D = e.i(673553),
        z = e.i(788015);
    let L = ((t = {}).checked = "data-checked", t.unchecked = "data-unchecked", t.disabled = "data-disabled", t.highlighted = "data-highlighted", t),
        _ = {
            checked: e => e ? {
                [L.checked]: ""
            } : {
                [L.unchecked]: ""
            },
            ...S.transitionStatusMapping
        };
    var F = e.i(675606);
    let B = n.forwardRef(function(e, t) {
        let {
            render: a,
            className: i,
            id: s,
            label: o,
            nativeButton: l = !1,
            disabled: d = !1,
            closeOnClick: u = !1,
            checked: c,
            defaultChecked: p,
            onCheckedChange: f,
            style: m,
            ...x
        } = e, v = (0, D.useCompositeListItem)({
            label: o
        }), S = g(!0), y = (0, z.useBaseUiId)(s), {
            store: w
        } = b(), R = w.useState("isActive", v.index), C = w.useState("itemProps"), [k, I] = (0, E.useControlled)({
            controlled: c,
            default: p ? ? !1,
            name: "MenuCheckboxItem",
            state: "checked"
        }), {
            getItemProps: P,
            itemRef: M
        } = A({
            closeOnClick: u,
            disabled: d,
            highlighted: R,
            id: y,
            store: w,
            nativeButton: l,
            nodeId: S ? .context.nodeId,
            itemMetadata: O
        }), T = n.useMemo(() => ({
            disabled: d,
            highlighted: R,
            checked: k
        }), [d, R, k]), L = (0, h.useRenderElement)("div", e, {
            state: T,
            stateAttributesMapping: _,
            props: [C, {
                role: "menuitemcheckbox",
                "aria-checked": k,
                onClick: function(e) {
                    let t = (0, F.createChangeEventDetails)(j.REASONS.itemPress, e.nativeEvent, void 0, {
                        preventUnmountOnClose() {}
                    });
                    f ? .(!k, t), t.isCanceled || I(e => !e)
                }
            }, x, P],
            ref: [M, t, v.ref]
        });
        return (0, r.jsx)(N.Provider, {
            value: T,
            children: L
        })
    });
    var H = e.i(223910),
        U = e.i(137584);
    let G = n.forwardRef(function(e, t) {
            let {
                render: a,
                className: r,
                style: i,
                keepMounted: s = !1,
                ...o
            } = e, l = function() {
                let e = n.useContext(N);
                if (void 0 === e) throw Error((0, p.default)(30));
                return e
            }(), d = n.useRef(null), {
                transitionStatus: u,
                setMounted: c
            } = (0, H.useTransitionStatus)(l.checked);
            (0, U.useOpenChangeComplete)({
                open: l.checked,
                ref: d,
                onComplete() {
                    l.checked || c(!1)
                }
            });
            let f = {
                checked: l.checked,
                disabled: l.disabled,
                highlighted: l.highlighted,
                transitionStatus: u
            };
            return (0, h.useRenderElement)("span", e, {
                state: f,
                ref: [t, d],
                stateAttributesMapping: _,
                props: {
                    "aria-hidden": !0,
                    ...o
                },
                enabled: s || l.checked
            })
        }),
        V = n.createContext(void 0),
        $ = n.forwardRef(function(e, t) {
            let {
                render: a,
                className: i,
                style: s,
                ...o
            } = e, [l, d] = n.useState(void 0), u = (0, h.useRenderElement)("div", e, {
                ref: t,
                props: {
                    role: "group",
                    "aria-labelledby": l,
                    ...o
                }
            });
            return (0, r.jsx)(V.Provider, {
                value: d,
                children: u
            })
        });
    var K = e.i(146376);
    let Y = n.forwardRef(function(e, t) {
            let {
                render: a,
                className: r,
                style: i,
                id: s,
                ...o
            } = e, l = (0, z.useBaseUiId)(s), d = function() {
                let e = n.useContext(V);
                if (void 0 === e) throw Error((0, p.default)(31));
                return e
            }();
            return (0, K.useIsoLayoutEffect)(() => (d(l), () => {
                d(void 0)
            }), [d, l]), (0, h.useRenderElement)("div", e, {
                ref: t,
                props: {
                    id: l,
                    role: "presentation",
                    ...o
                }
            })
        }),
        q = n.forwardRef(function(e, t) {
            let {
                render: a,
                className: r,
                id: n,
                label: i,
                nativeButton: s = !1,
                disabled: o = !1,
                closeOnClick: l = !0,
                style: d,
                ...u
            } = e, c = (0, D.useCompositeListItem)({
                label: i
            }), p = g(!0), f = (0, z.useBaseUiId)(n), {
                store: m
            } = b(), x = m.useState("isActive", c.index), v = m.useState("itemProps"), {
                getItemProps: S,
                itemRef: y
            } = A({
                closeOnClick: l,
                disabled: o,
                highlighted: x,
                id: f,
                store: m,
                nativeButton: s,
                nodeId: p ? .context.nodeId,
                itemMetadata: O
            });
            return (0, h.useRenderElement)("div", e, {
                state: {
                    disabled: o,
                    highlighted: x
                },
                props: [v, u, S],
                ref: [y, t, c.ref]
            })
        }),
        W = n.forwardRef(function(e, t) {
            let {
                render: a,
                className: r,
                id: i,
                label: s,
                closeOnClick: o = !1,
                style: l,
                ...d
            } = e, u = n.useRef(null), c = (0, D.useCompositeListItem)({
                label: s
            }), p = g(!0), f = p ? .context.nodeId, m = (0, z.useBaseUiId)(i), {
                store: x
            } = b(), v = x.useState("isActive", c.index), S = x.useState("itemProps"), y = x.context.typingRef, {
                getButtonProps: w,
                buttonRef: j
            } = (0, I.useButton)({
                native: !1,
                composite: !0
            }), R = T({
                closeOnClick: o,
                highlighted: v,
                id: m,
                nodeId: f,
                store: x,
                typingRef: y,
                itemRef: u
            });
            return (0, h.useRenderElement)("a", e, {
                state: {
                    highlighted: v
                },
                props: [S, d, function(e) {
                    return (0, P.mergeProps)(R, e, w)
                }],
                ref: [u, j, t, c.ref]
            })
        });
    var J = e.i(61487),
        X = e.i(431157),
        Q = e.i(96533),
        Z = e.i(673327),
        ee = e.i(815982);
    let et = { ...x.popupStateMapping,
            ...S.transitionStatusMapping
        },
        ea = n.forwardRef(function(e, t) {
            let {
                render: a,
                className: i,
                style: s,
                finalFocus: o,
                ...l
            } = e, {
                store: d
            } = b(), {
                side: u,
                align: c
            } = g(), p = null != (0, Q.useToolbarRootContext)(!0), f = d.useState("open"), m = d.useState("transitionStatus"), x = d.useState("popupProps"), v = d.useState("mounted"), S = d.useState("instantType"), y = d.useState("activeTriggerElement"), w = d.useState("parent"), R = d.useState("lastOpenChangeReason"), C = d.useState("rootId"), E = d.useState("floatingRootContext"), N = d.useState("floatingTreeRoot"), k = d.useState("closeDelay"), I = d.useState("activeTriggerElement"), P = d.useState("hoverEnabled"), M = d.useState("disabled"), T = d.useState("openMethod"), O = "context-menu" === w.type;
            (0, U.useOpenChangeComplete)({
                open: f,
                ref: d.context.popupRef,
                onComplete() {
                    f && d.context.onOpenChangeComplete ? .(!0)
                }
            }), n.useEffect(() => {
                function e(e) {
                    d.setOpen(!1, (0, F.createChangeEventDetails)(e.reason, e.domEvent))
                }
                return N.events.on("close", e), () => {
                    N.events.off("close", e)
                }
            }, [N.events, d]), (0, X.useHoverFloatingInteraction)(E, {
                enabled: P && !M && !O && "menubar" !== w.type,
                closeDelay: k
            });
            let A = n.useCallback(e => {
                    d.set("popupElement", e)
                }, [d]),
                D = {
                    transitionStatus: m,
                    side: u,
                    align: c,
                    open: f,
                    nested: "menu" === w.type,
                    instant: S
                },
                z = (0, h.useRenderElement)("div", e, {
                    state: D,
                    ref: [t, d.context.popupRef, A],
                    stateAttributesMapping: et,
                    props: [x, {
                        onKeyDown(e) {
                            p && Z.COMPOSITE_KEYS.has(e.key) && e.stopPropagation()
                        }
                    }, (0, ee.getDisabledMountTransitionStyles)(m), l, {
                        "data-rootownerid": C
                    }]
                }),
                L = void 0 === w.type || O;
            return (y || "menubar" === w.type && R !== j.REASONS.outsidePress) && (L = !0), (0, r.jsx)(J.FloatingFocusManager, {
                context: E,
                openInteractionType: T,
                modal: O,
                disabled: !v,
                returnFocus: void 0 === o ? L : o,
                initialFocus: "menu" !== w.type,
                restoreFocus: !0,
                externalTree: "menubar" !== w.type ? N : void 0,
                previousFocusableElement: I,
                nextFocusableElement: void 0 === w.type ? d.context.triggerFocusTargetRef : void 0,
                beforeContentFocusGuardRef: void 0 === w.type ? d.context.beforeContentFocusGuardRef : void 0,
                children: z
            })
        });
    var er = e.i(726674);
    let en = n.createContext(void 0),
        ei = n.forwardRef(function(e, t) {
            let {
                keepMounted: a = !1,
                ...n
            } = e, {
                store: i
            } = b();
            return i.useState("mounted") || a ? (0, r.jsx)(en.Provider, {
                value: a,
                children: (0, r.jsx)(er.FloatingPortal, {
                    ref: t,
                    ...n
                })
            }) : null
        });
    var es = e.i(144394),
        eo = e.i(439957),
        el = e.i(46420),
        ed = e.i(329365),
        eu = e.i(53687),
        ec = e.i(426),
        ep = e.i(638396),
        ef = e.i(360495),
        eg = e.i(222640),
        em = e.i(789579),
        eb = e.i(33383);
    let eh = n.forwardRef(function(e, t) {
        let {
            anchor: a,
            positionMethod: i = "absolute",
            className: s,
            render: o,
            side: l,
            align: d,
            sideOffset: u = 0,
            alignOffset: c = 0,
            collisionBoundary: g = "clipping-ancestors",
            collisionPadding: m = 5,
            arrowPadding: h = 5,
            sticky: x = !1,
            disableAnchorTracking: v = !1,
            collisionAvoidance: S = ep.DROPDOWN_COLLISION_AVOIDANCE,
            style: y,
            ...R
        } = e, {
            store: C
        } = b(), E = function() {
            let e = n.useContext(en);
            if (void 0 === e) throw Error((0, p.default)(32));
            return e
        }(), N = w(!0), k = C.useState("parent"), I = C.useState("floatingRootContext"), P = C.useState("floatingTreeRoot"), M = C.useState("mounted"), T = C.useState("open"), O = C.useState("modal"), A = C.useState("openMethod"), D = C.useState("activeTriggerElement"), z = C.useState("transitionStatus"), L = C.useState("positionerElement"), _ = C.useState("instantType"), B = C.useState("hasViewport"), H = C.useState("lastOpenChangeReason"), U = C.useState("floatingNodeId"), G = C.useState("floatingParentNodeId"), V = I.useState("domReferenceElement"), $ = n.useRef(null), Y = (0, eg.useAnimationsFinished)(L, !1, !1), q = a, W = u, J = c, X = d, Q = S;
        "context-menu" === k.type && (q = a ? ? k.context ? .anchor, X = X ? ? "start", l || "center" === X || (J = e.alignOffset ? ? 2, W = e.sideOffset ? ? -5));
        let Z = l,
            ee = X;
        "menu" === k.type ? (Z = Z ? ? "inline-end", ee = ee ? ? "start", Q = e.collisionAvoidance ? ? ep.POPUP_COLLISION_AVOIDANCE) : "menubar" === k.type && (Z = Z ? ? ("vertical" === k.context.orientation ? "inline-end" : "bottom"), ee = ee ? ? "start");
        let et = "context-menu" === k.type,
            ea = (0, ed.useAnchorPositioning)({
                anchor: q,
                floatingRootContext: I,
                positionMethod: N ? "fixed" : i,
                mounted: M,
                side: Z,
                sideOffset: W,
                align: ee,
                alignOffset: J,
                arrowPadding: et ? 0 : h,
                collisionBoundary: g,
                collisionPadding: m,
                sticky: x,
                nodeId: U,
                keepMounted: E,
                disableAnchorTracking: v,
                collisionAvoidance: Q,
                shiftCrossAxis: et && !("side" in Q && "flip" === Q.side),
                externalTree: P,
                adaptiveOrigin: B ? ef.adaptiveOrigin : void 0
            });
        n.useEffect(() => {
            function e(e) {
                e.open && (e.parentNodeId === U && C.set("hoverEnabled", !1), e.nodeId !== U && e.parentNodeId === C.select("floatingParentNodeId") && C.setOpen(!1, (0, F.createChangeEventDetails)(j.REASONS.siblingOpen)))
            }
            return P.events.on("menuopenchange", e), () => {
                P.events.off("menuopenchange", e)
            }
        }, [C, P.events, U]), n.useEffect(() => {
            if (null != C.select("floatingParentNodeId")) return P.events.on("menuopenchange", e), () => {
                P.events.off("menuopenchange", e)
            };

            function e(e) {
                if (e.open || e.nodeId !== C.select("floatingParentNodeId")) return;
                let t = e.reason ? ? j.REASONS.siblingOpen;
                C.setOpen(!1, (0, F.createChangeEventDetails)(t))
            }
        }, [P.events, C]);
        let er = (0, eo.useTimeout)();
        n.useEffect(() => {
            T || er.clear()
        }, [T, er]), n.useEffect(() => {
            function e(e) {
                if (T && e.nodeId === C.select("floatingParentNodeId"))
                    if (e.target && D && D !== e.target) {
                        let e = C.select("closeDelay");
                        e > 0 ? er.isStarted() || er.start(e, () => {
                            C.setOpen(!1, (0, F.createChangeEventDetails)(j.REASONS.siblingOpen))
                        }) : C.setOpen(!1, (0, F.createChangeEventDetails)(j.REASONS.siblingOpen))
                    } else er.clear()
            }
            return P.events.on("itemhover", e), () => {
                P.events.off("itemhover", e)
            }
        }, [P.events, T, D, C, er]), n.useEffect(() => {
            let e = {
                open: T,
                nodeId: U,
                parentNodeId: G,
                reason: C.select("lastOpenChangeReason")
            };
            P.events.emit("menuopenchange", e)
        }, [P.events, T, C, U, G]), (0, K.useIsoLayoutEffect)(() => {
            let e = $.current;
            if (V && ($.current = V), e && V && V !== e) {
                C.set("instantType", void 0);
                let e = new AbortController;
                return Y(() => {
                    C.set("instantType", "trigger-change")
                }, e.signal), () => {
                    e.abort()
                }
            }
        }, [V, Y, C]);
        let ei = {
                open: T,
                side: ea.side,
                align: ea.align,
                anchorHidden: ea.anchorHidden,
                nested: "menu" === k.type,
                instant: _
            },
            eh = "menubar" === k.type && k.context.modal,
            ex = O && H !== j.REASONS.triggerHover;
        (0, eb.useAnchoredPopupScrollLock)(T && (eh || ex), "touch" === A, L, D);
        let ev = (0, em.usePositioner)(e, ei, {
                styles: ea.positionerStyles,
                transitionStatus: z,
                props: R,
                refs: [t, C.useStateSetter("positionerElement")],
                hidden: !M,
                inert: !T
            }),
            eS = M && "menu" !== k.type && ("menubar" !== k.type && O && H !== j.REASONS.triggerHover || "menubar" === k.type && k.context.modal),
            ey = null;
        return "menubar" === k.type ? ey = k.context.contentElement : void 0 === k.type && (ey = D), (0, r.jsxs)(f.Provider, {
            value: ea,
            children: [eS && (0, r.jsx)(ec.InternalBackdrop, {
                ref: "context-menu" === k.type || "nested-context-menu" === k.type ? k.context.internalBackdropRef : null,
                inert: (0, es.inertValue)(!T),
                cutout: ey
            }), (0, r.jsx)(el.FloatingNode, {
                id: U,
                children: (0, r.jsx)(eu.CompositeList, {
                    elementsRef: C.context.itemDomElements,
                    labelsRef: C.context.itemLabels,
                    children: ev
                })
            })]
        })
    });
    var ex = e.i(667865);
    let ev = n.createContext(void 0),
        eS = n.memo(n.forwardRef(function(e, t) {
            let {
                render: a,
                className: i,
                value: s,
                defaultValue: o,
                onValueChange: l,
                disabled: d = !1,
                style: u,
                "aria-labelledby": c,
                ...p
            } = e, [f, g] = n.useState(void 0), [m, b] = (0, E.useControlled)({
                controlled: s,
                default: o,
                name: "MenuRadioGroup"
            }), x = (0, ex.useStableCallback)((e, t) => {
                l ? .(e, t), t.isCanceled || b(e)
            }), v = (0, h.useRenderElement)("div", e, {
                state: {
                    disabled: d
                },
                ref: t,
                props: {
                    role: "group",
                    "aria-labelledby": c ? ? f,
                    "aria-disabled": d || void 0,
                    ...p
                }
            }), S = n.useMemo(() => ({
                value: m,
                setValue: x,
                disabled: d
            }), [m, x, d]);
            return (0, r.jsx)(V.Provider, {
                value: g,
                children: (0, r.jsx)(ev.Provider, {
                    value: S,
                    children: v
                })
            })
        })),
        ey = n.createContext(void 0),
        ew = n.forwardRef(function(e, t) {
            let {
                render: a,
                className: i,
                id: s,
                label: o,
                nativeButton: l = !1,
                disabled: d = !1,
                closeOnClick: u = !1,
                value: c,
                style: f,
                ...m
            } = e, x = (0, D.useCompositeListItem)({
                label: o
            }), v = g(!0), S = (0, z.useBaseUiId)(s), {
                store: y
            } = b(), w = y.useState("isActive", x.index), R = y.useState("itemProps"), {
                value: C,
                setValue: E,
                disabled: N
            } = function() {
                let e = n.useContext(ev);
                if (void 0 === e) throw Error((0, p.default)(34));
                return e
            }(), k = N || d, I = C === c, {
                getItemProps: P,
                itemRef: M
            } = A({
                closeOnClick: u,
                disabled: k,
                highlighted: w,
                id: S,
                store: y,
                nativeButton: l,
                nodeId: v ? .context.nodeId,
                itemMetadata: O
            }), T = n.useMemo(() => ({
                disabled: k,
                highlighted: w,
                checked: I
            }), [k, w, I]), L = (0, h.useRenderElement)("div", e, {
                state: T,
                stateAttributesMapping: _,
                props: [R, {
                    role: "menuitemradio",
                    "aria-checked": I,
                    onClick: function(e) {
                        E(c, (0, F.createChangeEventDetails)(j.REASONS.itemPress, e.nativeEvent, void 0, {
                            preventUnmountOnClose() {}
                        }))
                    }
                }, m, P],
                ref: [M, t, x.ref]
            });
            return (0, r.jsx)(ey.Provider, {
                value: T,
                children: L
            })
        }),
        ej = n.forwardRef(function(e, t) {
            let {
                render: a,
                className: r,
                style: i,
                keepMounted: s = !1,
                ...o
            } = e, l = function() {
                let e = n.useContext(ey);
                if (void 0 === e) throw Error((0, p.default)(35));
                return e
            }(), d = n.useRef(null), {
                transitionStatus: u,
                setMounted: c
            } = (0, H.useTransitionStatus)(l.checked);
            (0, U.useOpenChangeComplete)({
                open: l.checked,
                ref: d,
                onComplete() {
                    l.checked || c(!1)
                }
            });
            let f = {
                checked: l.checked,
                disabled: l.disabled,
                highlighted: l.highlighted,
                transitionStatus: u
            };
            return (0, h.useRenderElement)("span", e, {
                state: f,
                stateAttributesMapping: _,
                ref: [t, d],
                props: {
                    "aria-hidden": !0,
                    ...o
                },
                enabled: s || l.checked
            })
        });
    var eR = e.i(883977),
        eC = e.i(956789),
        eE = e.i(896499),
        eN = e.i(17989),
        ek = e.i(260891),
        eI = e.i(736760),
        eP = e.i(350527);
    let eM = n.createContext(null);

    function eT(e) {
        let t = n.useContext(eM);
        if (null === t && !e) throw Error((0, p.default)(5));
        return t
    }
    var eO = e.i(872855),
        eA = e.i(32199),
        eD = e.i(616269),
        ez = e.i(301252),
        eL = e.i(388940),
        e_ = e.i(379248),
        eF = e.i(116786),
        eB = e.i(990627);
    let eH = { ...eF.popupStoreSelectors,
        disabled: (0, eD.createSelector)(e => "menubar" === e.parent.type && e.parent.context.disabled || e.disabled),
        modal: (0, eD.createSelector)(e => (void 0 === e.parent.type || "context-menu" === e.parent.type) && (e.modal ? ? !0)),
        openMethod: (0, eD.createSelector)(e => e.openMethod),
        allowMouseEnter: (0, eD.createSelector)(e => e.allowMouseEnter),
        highlightItemOnHover: (0, eD.createSelector)(e => e.highlightItemOnHover),
        stickIfOpen: (0, eD.createSelector)(e => e.stickIfOpen),
        parent: (0, eD.createSelector)(e => e.parent),
        rootId: (0, eD.createSelector)(e => "menu" === e.parent.type ? e.parent.store.select("rootId") : void 0 !== e.parent.type ? e.parent.context.rootId : e.rootId),
        activeIndex: (0, eD.createSelector)(e => e.activeIndex),
        isActive: (0, eD.createSelector)((e, t) => e.activeIndex === t),
        hoverEnabled: (0, eD.createSelector)(e => e.hoverEnabled),
        instantType: (0, eD.createSelector)(e => e.instantType),
        lastOpenChangeReason: (0, eD.createSelector)(e => e.openChangeReason),
        floatingTreeRoot: (0, eD.createSelector)(e => "menu" === e.parent.type ? e.parent.store.select("floatingTreeRoot") : e.floatingTreeRoot),
        floatingNodeId: (0, eD.createSelector)(e => e.floatingNodeId),
        floatingParentNodeId: (0, eD.createSelector)(e => e.floatingParentNodeId),
        itemProps: (0, eD.createSelector)(e => e.itemProps),
        closeDelay: (0, eD.createSelector)(e => e.closeDelay),
        hasViewport: (0, eD.createSelector)(e => e.hasViewport),
        keyboardEventRelay: (0, eD.createSelector)(e => e.keyboardEventRelay ? e.keyboardEventRelay : "menu" === e.parent.type ? e.parent.store.select("keyboardEventRelay") : void 0)
    };
    class eU extends ez.ReactStore {
        constructor(e) {
            super({ ...{ ...(0, eF.createInitialPopupStoreState)(),
                    disabled: !1,
                    modal: !0,
                    openMethod: null,
                    allowMouseEnter: !1,
                    highlightItemOnHover: !0,
                    stickIfOpen: !0,
                    parent: {
                        type: void 0
                    },
                    rootId: void 0,
                    activeIndex: null,
                    hoverEnabled: !0,
                    instantType: void 0,
                    openChangeReason: null,
                    floatingTreeRoot: new e_.FloatingTreeStore,
                    floatingNodeId: void 0,
                    floatingParentNodeId: null,
                    itemProps: eC.EMPTY_OBJECT,
                    keyboardEventRelay: void 0,
                    closeDelay: 0,
                    hasViewport: !1
                },
                ...e
            }, {
                positionerRef: n.createRef(),
                popupRef: n.createRef(),
                typingRef: {
                    current: !1
                },
                itemDomElements: {
                    current: []
                },
                itemLabels: {
                    current: []
                },
                allowMouseUpTriggerRef: {
                    current: !1
                },
                triggerFocusTargetRef: n.createRef(),
                beforeContentFocusGuardRef: n.createRef(),
                onOpenChangeComplete: void 0,
                triggerElements: new eB.PopupTriggerMap
            }, eH), this.unsubscribeParentListener = this.observe("parent", e => {
                if (this.unsubscribeParentListener ? .(), "menu" === e.type) {
                    let t = e.store.select("rootId"),
                        a = e.store.select("floatingTreeRoot"),
                        r = e.store.select("keyboardEventRelay");
                    this.unsubscribeParentListener = e.store.subscribe(() => {
                        let n = e.store.select("rootId"),
                            i = e.store.select("floatingTreeRoot"),
                            s = e.store.select("keyboardEventRelay");
                        (t !== n || a !== i || r !== s) && (t = n, a = i, r = s, this.notifyAll())
                    }), this.context.allowMouseUpTriggerRef = e.store.context.allowMouseUpTriggerRef;
                    return
                }
                void 0 !== e.type && (this.context.allowMouseUpTriggerRef = e.context.allowMouseUpTriggerRef), this.unsubscribeParentListener = null
            })
        }
        setOpen(e, t) {
            this.state.floatingRootContext.context.events.emit("setOpen", {
                open: e,
                eventDetails: t
            })
        }
        static useStore(e, t) {
            let a = (0, eL.useRefWithInit)(() => new eU(t)).current;
            return e ? ? a
        }
        unsubscribeParentListener = null
    }
    var eG = e.i(264111);
    let eV = n.createContext(void 0);

    function e$() {
        return n.useContext(eV)
    }
    let eK = (0, eE.fastComponent)(function(e) {
        let t, {
                children: a,
                open: i,
                onOpenChange: s,
                onOpenChangeComplete: o,
                defaultOpen: l = !1,
                disabled: d = !1,
                modal: u,
                loopFocus: c = !0,
                orientation: p = "vertical",
                actionsRef: f,
                closeParentOnEsc: g = !1,
                handle: h,
                triggerId: x,
                defaultTriggerId: v = null,
                highlightItemOnHover: S = !0
            } = e,
            y = w(!0),
            R = b(!0),
            C = eT(!0),
            E = e$(),
            N = n.useMemo(() => E && R ? {
                type: "menu",
                store: R.store
            } : C ? {
                type: "menubar",
                context: C
            } : y && !R ? {
                type: "context-menu",
                context: y
            } : {
                type: void 0
            }, [y, R, C, E]),
            k = eU.useStore(h ? .store, {
                open: l,
                openProp: i,
                activeTriggerId: v,
                triggerIdProp: x,
                parent: N
            });
        (0, eG.useInitialOpenSync)(k, i, l, v), k.useControlledProp("openProp", i), k.useControlledProp("triggerIdProp", x), k.useContextCallback("onOpenChangeComplete", o);
        let I = (0, eR.useId)(),
            M = (0, eR.useId)(),
            T = k.useState("floatingTreeRoot"),
            O = (0, el.useFloatingNodeId)(T),
            A = (0, el.useFloatingParentNodeId)(),
            D = k.useState("open"),
            z = k.useState("activeTriggerElement"),
            L = k.useState("positionerElement"),
            _ = k.useState("hoverEnabled"),
            B = k.useState("disabled"),
            H = k.useState("lastOpenChangeReason"),
            U = k.useState("parent"),
            G = k.useState("activeIndex"),
            V = k.useState("payload"),
            $ = k.useState("floatingParentNodeId"),
            Y = n.useRef(null),
            q = n.useRef("context-menu" !== U.type),
            W = (0, eo.useTimeout)(),
            J = n.useRef(!0),
            X = (0, eo.useTimeout)(),
            Q = null != $,
            {
                openMethod: Z,
                triggerProps: ee
            } = (0, eA.useOpenInteractionType)(D);
        k.useSyncedValues({
            disabled: d,
            highlightItemOnHover: S,
            modal: void 0 === U.type ? u : void 0,
            openMethod: Z,
            rootId: I
        }), (0, eG.useImplicitActiveTrigger)(k);
        let {
            forceUnmount: et
        } = (0, eG.useOpenStateTransitions)(D, k, () => {
            k.update({
                allowMouseEnter: !1,
                stickIfOpen: !0
            })
        });
        (0, K.useIsoLayoutEffect)(() => {
            y && !R ? k.update({
                parent: {
                    type: "context-menu",
                    context: y
                },
                floatingNodeId: O,
                floatingParentNodeId: A
            }) : R && k.update({
                floatingNodeId: O,
                floatingParentNodeId: A
            })
        }, [y, R, O, A, k]), n.useEffect(() => {
            if (D || (Y.current = null), "context-menu" === U.type) {
                if (!D) {
                    W.clear(), q.current = !1;
                    return
                }
                W.start(500, () => {
                    q.current = !0
                })
            }
        }, [W, D, U.type]), (0, K.useIsoLayoutEffect)(() => {
            D || _ || k.set("hoverEnabled", !0)
        }, [D, _, k]);
        let ea = (0, ex.useStableCallback)((e, t) => {
                let a = t.reason;
                if (D === e && t.trigger === z && H === a) return;
                let r = (0, eG.attachPreventUnmountOnClose)(t);
                if (e || null != t.trigger || (t.trigger = z ? ? void 0), s ? .(e, t), t.isCanceled) return;
                k.state.floatingRootContext.dispatchOpenChange(e, t);
                let n = t.event;
                if (!1 === e && n ? .type === "click" && "touch" === n.pointerType && !J.current) return;
                e && a === j.REASONS.triggerFocus ? (J.current = !1, X.start(300, () => {
                    J.current = !0
                })) : (J.current = !0, X.clear());
                let i = (a === j.REASONS.triggerPress || a === j.REASONS.itemPress) && 0 === n.detail && n ? .isTrusted,
                    o = !e && (a === j.REASONS.escapeKey || null == a),
                    l = {
                        open: e,
                        openChangeReason: a
                    };
                Y.current = t.event ? ? null, (0, eG.setPopupOpenState)(l, e, t.trigger, r()), k.update(l), "menubar" === U.type && (a === j.REASONS.triggerFocus || a === j.REASONS.focusOut || a === j.REASONS.triggerHover || a === j.REASONS.listNavigation || a === j.REASONS.siblingOpen) ? k.set("instantType", "group") : i || o ? k.set("instantType", i ? "click" : "dismiss") : k.set("instantType", void 0)
            }),
            er = (0, eP.useSyncedFloatingRootContext)({
                popupStore: k,
                floatingId: M,
                nested: null != A,
                onOpenChange: ea
            }),
            en = er.context.events;
        n.useEffect(() => {
            let e = ({
                open: e,
                eventDetails: t
            }) => ea(e, t);
            return en.on("setOpen", e), () => {
                en ? .off("setOpen", e)
            }
        }, [en, ea]);
        let ei = n.useCallback(() => {
            k.setOpen(!1, (0, F.createChangeEventDetails)(j.REASONS.imperativeAction))
        }, [k]);
        n.useImperativeHandle(f, () => ({
            unmount: et,
            close: ei
        }), [et, ei]), "context-menu" === U.type && (t = U.context), n.useImperativeHandle(t ? .positionerRef, () => L, [L]), n.useImperativeHandle(t ? .actionsRef, () => ({
            setOpen: ea
        }), [ea]);
        let es = (0, eN.useDismiss)(er, {
                enabled: !B,
                bubbles: {
                    escapeKey: g && "menu" === U.type
                },
                outsidePress: () => "context-menu" !== U.type || Y.current ? .type === "contextmenu" || q.current,
                externalTree: Q ? T : void 0
            }),
            ed = (0, eO.useDirection)(),
            eu = n.useCallback(e => {
                k.select("activeIndex") !== e && k.set("activeIndex", e)
            }, [k]),
            ec = (0, ek.useListNavigation)(er, {
                enabled: !B,
                listRef: k.context.itemDomElements,
                activeIndex: G,
                nested: void 0 !== U.type,
                loopFocus: c,
                orientation: p,
                parentOrientation: "menubar" === U.type ? U.context.orientation : void 0,
                rtl: "rtl" === ed,
                disabledIndices: eC.EMPTY_ARRAY,
                onNavigate: eu,
                openOnArrowKeyDown: "context-menu" !== U.type,
                externalTree: Q ? T : void 0,
                focusItemOnHover: S
            }),
            ef = n.useCallback(e => {
                k.context.typingRef.current = e
            }, [k]),
            eg = (0, eI.useTypeahead)(er, {
                enabled: !B,
                listRef: k.context.itemLabels,
                elementsRef: k.context.itemDomElements,
                activeIndex: G,
                resetMs: ep.TYPEAHEAD_RESET_MS,
                onMatch: e => {
                    D && e !== G && k.set("activeIndex", e)
                },
                onTyping: ef
            }),
            em = n.useMemo(() => {
                let e = (0, P.mergeProps)(eg.reference, ec.reference, es.reference, {
                    onMouseMove() {
                        k.set("allowMouseEnter", !0)
                    }
                }, ee);
                return e["aria-haspopup"] = "menu", e["aria-expanded"] = D, e
            }, [k, eg.reference, ec.reference, es.reference, ee, D]),
            eb = n.useMemo(() => {
                let e = (0, P.mergeProps)(ec.trigger, es.trigger, ee);
                return e["aria-haspopup"] = "menu", e["aria-expanded"] = !1, e
            }, [ec.trigger, es.trigger, ee]),
            eh = n.useMemo(() => (0, P.mergeProps)(eG.FOCUSABLE_POPUP_PROPS, {
                id: M,
                role: "menu",
                "aria-labelledby": z ? .id,
                onMouseMove() {
                    k.set("allowMouseEnter", !0), "menu" === U.type && k.set("hoverEnabled", !1)
                },
                onClick() {
                    k.select("hoverEnabled") && k.set("hoverEnabled", !1)
                },
                onKeyDown(e) {
                    let t = k.select("keyboardEventRelay");
                    t && !e.isPropagationStopped() && t(e)
                }
            }, eg.floating, ec.floating, es.floating), [z, M, U.type, k, eg.floating, ec.floating, es.floating]),
            ev = ec.item ? ? eC.EMPTY_OBJECT;
        (0, eG.usePopupInteractionProps)(k, {
            floatingRootContext: er,
            activeTriggerProps: em,
            inactiveTriggerProps: eb,
            popupProps: eh,
            itemProps: ev
        });
        let eS = n.useMemo(() => ({
                store: k,
                parent: N
            }), [k, N]),
            ey = (0, r.jsx)(m.Provider, {
                value: eS,
                children: "function" == typeof a ? a({
                    payload: V
                }) : a
            });
        return void 0 === U.type || "context-menu" === U.type ? (0, r.jsx)(el.FloatingTree, {
            externalTree: T,
            children: ey
        }) : ey
    });
    var eY = e.i(108868),
        eq = e.i(650316),
        eW = e.i(385689),
        eJ = e.i(413082),
        eX = e.i(872135),
        eQ = e.i(647554),
        eZ = e.i(264042),
        e0 = e.i(348990),
        e1 = e.i(838452),
        e2 = e.i(229315),
        e5 = e.i(346570),
        e4 = e.i(152535);
    let e6 = (0, eE.fastComponentRef)(function(e, t) {
        let a, i, s, {
                render: o,
                className: l,
                style: d,
                disabled: u = !1,
                nativeButton: c = !0,
                id: f,
                openOnHover: g,
                delay: m = 100,
                closeDelay: v = 0,
                handle: S,
                payload: y,
                ...R
            } = e,
            C = b(!0),
            E = S ? .store ? ? C ? .store;
        if (!E) throw Error((0, p.default)(85));
        let N = (0, z.useBaseUiId)(f),
            k = E.useState("isTriggerActive", N),
            M = E.useState("floatingRootContext"),
            T = E.useState("isOpenedByTrigger", N),
            O = E.useState("triggerPopupId", N),
            A = n.useRef(null),
            D = (a = w(!0), i = b(!0), s = eT(!0), n.useMemo(() => s ? {
                type: "menubar",
                context: s
            } : a && !i ? {
                type: "context-menu",
                context: a
            } : {
                type: void 0
            }, [a, i, s])),
            L = (0, e1.useCompositeRootContext)(!0),
            _ = (0, el.useFloatingTree)(),
            F = n.useMemo(() => _ ? ? new e_.FloatingTreeStore, [_]),
            B = (0, el.useFloatingNodeId)(F),
            H = (0, el.useFloatingParentNodeId)(),
            {
                registerTrigger: U,
                isMountedByThisTrigger: G
            } = (0, eG.useTriggerDataForwarding)(N, A, E, {
                payload: y,
                closeDelay: v,
                parent: D,
                floatingTreeRoot: F,
                floatingNodeId: B,
                floatingParentNodeId: H,
                keyboardEventRelay: L ? .relayKeyboardEvent
            }),
            V = "menubar" === D.type,
            $ = E.useState("disabled"),
            Y = u || $ || V && D.context.disabled,
            {
                getButtonProps: q,
                buttonRef: W
            } = (0, I.useButton)({
                disabled: Y,
                native: c
            });
        n.useEffect(() => {
            T || void 0 !== D.type || (E.context.allowMouseUpTriggerRef.current = !1)
        }, [E, T, D.type]);
        let J = n.useRef(null),
            X = (0, eo.useTimeout)(),
            Q = (0, ex.useStableCallback)(e => {
                if (!J.current) return;
                X.clear(), E.context.allowMouseUpTriggerRef.current = !1;
                let t = e.target;
                if ((0, eQ.contains)(J.current, t) || (0, eQ.contains)(E.select("positionerElement"), t) || t === J.current || null != t && function e(t) {
                        return (0, e2.isHTMLElement)(t) && t.hasAttribute("data-rootownerid") ? t.getAttribute("data-rootownerid") ? ? void 0 : (0, e2.isLastTraversableNode)(t) ? void 0 : e((0, e2.getParentNode)(t))
                    }(t) === E.select("rootId")) return;
                let a = (0, eZ.getPseudoElementBounds)(J.current);
                e.clientX >= a.left - 2 && e.clientX <= a.right + 2 && e.clientY >= a.top - 2 && e.clientY <= a.bottom + 2 || F.events.emit("close", {
                    domEvent: e,
                    reason: j.REASONS.cancelOpen
                })
            });
        n.useEffect(() => {
            T && E.select("lastOpenChangeReason") === j.REASONS.triggerHover && (0, eY.ownerDocument)(J.current).addEventListener("mouseup", Q, {
                once: !0
            })
        }, [T, Q, E]);
        let Z = V && D.context.hasSubmenuOpen,
            ee = g ? ? Z,
            et = (0, eX.useHoverReferenceInteraction)(M, {
                enabled: ee && !Y && "context-menu" !== D.type && (!V || Z && !G),
                handleClose: (0, eq.safePolygon)({
                    blockPointerEvents: !V
                }),
                mouseOnly: !0,
                move: !1,
                restMs: void 0 === D.type ? m : void 0,
                delay: {
                    close: v
                },
                triggerElementRef: A,
                externalTree: F,
                isActiveTrigger: k,
                isClosing: () => "ending" === E.select("transitionStatus")
            }),
            ea = function(e, t) {
                let a = (0, eo.useTimeout)(),
                    [r, i] = n.useState(!1);
                return (0, K.useIsoLayoutEffect)(() => {
                    e && "trigger-hover" === t ? (i(!0), a.start(ep.PATIENT_CLICK_THRESHOLD, () => {
                        i(!1)
                    })) : e || (a.clear(), i(!1))
                }, [e, t, a]), r
            }(T, E.select("lastOpenChangeReason")),
            er = (0, eW.useClick)(M, {
                enabled: !Y && "context-menu" !== D.type,
                event: T && V ? "click" : "mousedown",
                toggle: !0,
                ignoreMouse: !1,
                stickIfOpen: void 0 === D.type && ea
            }),
            en = (0, eJ.useFocus)(M, {
                enabled: !Y && Z
            }),
            ei = function(e) {
                let {
                    enabled: t = !0,
                    mouseDownAction: a,
                    open: r
                } = e, i = n.useRef(!1);
                return n.useMemo(() => t ? {
                    onMouseDown: e => {
                        ("open" === a && !r || "close" === a && r) && (i.current = !0, (0, eY.ownerDocument)(e.currentTarget).addEventListener("click", () => {
                            i.current = !1
                        }, {
                            once: !0
                        }))
                    },
                    onClick: e => {
                        i.current && (i.current = !1, e.preventBaseUIHandler())
                    }
                } : eC.EMPTY_OBJECT, [t, a, r])
            }({
                open: T,
                enabled: V,
                mouseDownAction: "open"
            }),
            es = n.useMemo(() => (0, P.mergeProps)(en.reference, er.reference), [en.reference, er.reference]),
            ed = E.useState("triggerProps", G),
            {
                preFocusGuardRef: eu,
                handlePreFocusGuardFocus: ec,
                handleFocusTargetFocus: ef
            } = (0, e5.useTriggerFocusGuards)(E, A),
            eg = {
                disabled: Y,
                open: T
            },
            em = [J, t, W, U, A],
            eb = [es, et ? ? eC.EMPTY_OBJECT, ed, {
                "aria-haspopup": "menu",
                "aria-controls": O,
                id: N,
                onMouseDown: e => {
                    E.select("open") || (X.start(200, () => {
                        E.context.allowMouseUpTriggerRef.current = !0
                    }), (0, eY.ownerDocument)(e.currentTarget).addEventListener("mouseup", Q, {
                        once: !0
                    }))
                }
            }, V ? {
                role: "menuitem"
            } : {}, ei, R, q],
            eh = (0, h.useRenderElement)("button", e, {
                enabled: !V,
                stateAttributesMapping: x.pressableTriggerOpenStateMapping,
                state: eg,
                ref: em,
                props: eb
            });
        return V ? (0, r.jsx)(e0.CompositeItem, {
            tag: "button",
            render: o,
            className: l,
            style: d,
            state: eg,
            refs: em,
            props: eb,
            stateAttributesMapping: x.pressableTriggerOpenStateMapping
        }) : T ? (0, r.jsxs)(n.Fragment, {
            children: [(0, r.jsx)(e4.FocusGuard, {
                ref: eu,
                onFocus: ec
            }, `${N}-pre-focus-guard`), (0, r.jsx)(n.Fragment, {
                children: eh
            }, N), (0, r.jsx)(e4.FocusGuard, {
                ref: E.context.triggerFocusTargetRef,
                onFocus: ef
            }, `${N}-post-focus-guard`)]
        }) : (0, r.jsx)(n.Fragment, {
            children: eh
        }, N)
    });
    var e3 = e.i(818390);
    let e7 = ((a = {}).popupWidth = "--popup-width", a.popupHeight = "--popup-height", a),
        e8 = {
            activationDirection: e => e ? {
                "data-activation-direction": e
            } : null
        },
        e9 = n.forwardRef(function(e, t) {
            let {
                render: a,
                className: r,
                style: n,
                children: i,
                ...s
            } = e, {
                store: o
            } = b(), {
                side: l
            } = g(), d = o.useState("instantType"), {
                children: u,
                state: c
            } = (0, e3.usePopupViewport)({
                store: o,
                side: l,
                cssVars: e7,
                children: i
            }), p = {
                activationDirection: c.activationDirection,
                transitioning: c.transitioning,
                instant: d
            };
            return (0, h.useRenderElement)("div", e, {
                state: p,
                ref: t,
                props: [s, {
                    children: u
                }],
                stateAttributesMapping: e8
            })
        });
    var te = e.i(652225);
    let tt = n.forwardRef(function(e, t) {
        let {
            render: a,
            className: r,
            style: i,
            label: s,
            id: o,
            nativeButton: l = !1,
            openOnHover: d = !0,
            delay: u = 100,
            closeDelay: c = 0,
            disabled: f = !1,
            ...m
        } = e, v = (0, D.useCompositeListItem)({
            label: s
        }), S = g(), {
            store: y
        } = b(), w = (0, z.useBaseUiId)(o), j = y.useState("open"), R = y.useState("floatingRootContext"), C = y.useState("floatingTreeRoot"), E = y.useState("triggerPopupId", w), N = (0, eG.useTriggerRegistration)(w, y), k = n.useCallback(e => {
            let t = N(e);
            return null !== e && y.select("open") && null == y.select("activeTriggerId") && y.update({
                activeTriggerId: w,
                activeTriggerElement: e,
                closeDelay: c
            }), t
        }, [N, c, y, w]), I = n.useRef(null), P = n.useCallback(e => {
            I.current = e, y.set("activeTriggerElement", e)
        }, [y]), M = e$();
        if (!M ? .parentMenu) throw Error((0, p.default)(37));
        y.useSyncedValue("closeDelay", c);
        let T = M.parentMenu,
            O = y.useState("disabled"),
            L = T.useState("disabled"),
            _ = f || O || L,
            F = T.useState("itemProps"),
            B = T.useState("isActive", v.index),
            H = n.useMemo(() => ({
                type: "submenu-trigger",
                setActive() {
                    T.select("highlightItemOnHover") && T.set("activeIndex", v.index)
                }
            }), [T, v.index]),
            {
                getItemProps: U,
                itemRef: G
            } = A({
                closeOnClick: !1,
                disabled: _,
                highlighted: B,
                id: w,
                store: y,
                typingRef: T.context.typingRef,
                nativeButton: l,
                itemMetadata: H,
                nodeId: S ? .context.nodeId
            }),
            V = y.useState("hoverEnabled"),
            $ = (0, eX.useHoverReferenceInteraction)(R, {
                enabled: V && d && !_,
                handleClose: (0, eq.safePolygon)({
                    blockPointerEvents: !0
                }),
                mouseOnly: !0,
                move: !0,
                restMs: u,
                delay: {
                    open: u,
                    close: c
                },
                shouldOpen: u > 0 ? () => T.select("allowMouseEnter") : void 0,
                triggerElementRef: I,
                externalTree: C,
                isClosing: () => "ending" === y.select("transitionStatus")
            }),
            K = (0, eW.useClick)(R, {
                enabled: !_,
                event: "mousedown",
                toggle: !d,
                ignoreMouse: d,
                stickIfOpen: !1
            }).reference ? ? eC.EMPTY_OBJECT,
            Y = y.useState("triggerProps", !0);
        return delete Y.id, (0, h.useRenderElement)("div", e, {
            state: {
                disabled: _,
                highlighted: B,
                open: j
            },
            stateAttributesMapping: x.triggerOpenStateMapping,
            props: [K, $, Y, F, {
                "aria-controls": E,
                tabIndex: j || B ? 0 : -1,
                onBlur() {
                    B && T.set("activeIndex", null)
                }
            }, m, U],
            ref: [t, v.ref, G, k, P]
        })
    });
    class ta {
        constructor() {
            this.store = new eU
        }
        open(e) {
            let t = e ? this.store.context.triggerElements.getById(e) : void 0;
            if (e && !t) throw Error((0, p.default)(83, e));
            this.store.setOpen(!0, (0, F.createChangeEventDetails)("imperative-action", void 0, t))
        }
        close() {
            this.store.setOpen(!1, (0, F.createChangeEventDetails)("imperative-action", void 0, void 0))
        }
        get isOpen() {
            return this.store.select("open")
        }
    }
    e.s(["Arrow", 0, v, "Backdrop", 0, C, "CheckboxItem", 0, B, "CheckboxItemIndicator", 0, G, "Group", 0, $, "GroupLabel", 0, Y, "Handle", 0, ta, "Item", 0, q, "LinkItem", 0, W, "Popup", 0, ea, "Portal", 0, ei, "Positioner", 0, eh, "RadioGroup", 0, eS, "RadioItem", 0, ew, "RadioItemIndicator", 0, ej, "Root", 0, eK, "Separator", () => te.Separator, "SubmenuRoot", 0, function(e) {
        let t = b().store,
            a = n.useMemo(() => ({
                parentMenu: t
            }), [t]);
        return (0, r.jsx)(eV.Provider, {
            value: a,
            children: (0, r.jsx)(eK, { ...e
            })
        })
    }, "SubmenuTrigger", 0, tt, "Trigger", 0, e6, "Viewport", 0, e9, "createHandle", 0, function() {
        return new ta
    }], 160948);
    var tr = e.i(160948),
        tr = tr,
        tn = e.i(975157);

    function ti({ ...e
    }) {
        return (0, r.jsx)(tr.Root, {
            "data-slot": "dropdown-menu",
            ...e
        })
    }

    function ts({ ...e
    }) {
        return (0, r.jsx)(tr.Trigger, {
            "data-slot": "dropdown-menu-trigger",
            ...e
        })
    }

    function to({
        align: e = "start",
        alignOffset: t = 0,
        side: a = "bottom",
        sideOffset: n = 4,
        className: i,
        ...s
    }) {
        return (0, r.jsx)(tr.Portal, {
            children: (0, r.jsx)(tr.Positioner, {
                className: "isolate z-50 outline-none",
                align: e,
                alignOffset: t,
                side: a,
                sideOffset: n,
                children: (0, r.jsx)(tr.Popup, {
                    "data-slot": "dropdown-menu-content",
                    className: (0, tn.cn)("z-50 max-h-(--available-height) w-(--anchor-width) min-w-32 origin-(--transform-origin) overflow-x-hidden overflow-y-auto rounded-md bg-popover p-1 text-popover-foreground shadow-md ring-1 ring-foreground/10 duration-100 outline-none data-[side=bottom]:slide-in-from-top-2 data-[side=inline-end]:slide-in-from-left-2 data-[side=inline-start]:slide-in-from-right-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-closed:animate-out data-closed:overflow-hidden data-closed:fade-out-0 data-closed:zoom-out-95", i),
                    ...s
                })
            })
        })
    }

    function tl({ ...e
    }) {
        return (0, r.jsx)(tr.Group, {
            "data-slot": "dropdown-menu-group",
            ...e
        })
    }

    function td({
        className: e,
        inset: t,
        ...a
    }) {
        return (0, r.jsx)(tr.GroupLabel, {
            "data-slot": "dropdown-menu-label",
            "data-inset": t,
            className: (0, tn.cn)("px-2 py-1.5 text-xs font-medium text-muted-foreground data-inset:pl-8", e),
            ...a
        })
    }

    function tu({
        className: e,
        inset: t,
        variant: a = "default",
        ...n
    }) {
        return (0, r.jsx)(tr.Item, {
            "data-slot": "dropdown-menu-item",
            "data-inset": t,
            "data-variant": a,
            className: (0, tn.cn)("group/dropdown-menu-item relative flex cursor-default items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-hidden select-none focus:bg-accent focus:text-accent-foreground not-data-[variant=destructive]:focus:**:text-accent-foreground data-inset:pl-8 data-[variant=destructive]:text-destructive data-[variant=destructive]:focus:bg-destructive/10 data-[variant=destructive]:focus:text-destructive dark:data-[variant=destructive]:focus:bg-destructive/20 data-disabled:pointer-events-none data-disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4 data-[variant=destructive]:*:[svg]:text-destructive", e),
            ...n
        })
    }

    function tc({
        className: e,
        ...t
    }) {
        return (0, r.jsx)(tr.Separator, {
            "data-slot": "dropdown-menu-separator",
            className: (0, tn.cn)("-mx-1 my-1 h-px bg-border", e),
            ...t
        })
    }
    e.i(746336), e.i(593698);
    var tp = e.i(177490),
        tf = e.i(350854);
    e.s(["UserDropdown", 0, function() {
        let e = (0, i.useRouter)(),
            [t, a] = (0, n.useState)(null);
        async function p() {
            try {
                await tf.default.authService.logout(), e.push("/login"), e.refresh()
            } catch (e) {
                u.toast.error(e.message)
            }
        }
        return (0, n.useEffect)(() => {
            let e = !1;
            return tf.default.userService.getUserProfile().then(t => {
                e || a(t)
            }).catch(() => {
                u.toast.error("Error fetching user data")
            }), () => {
                e = !0
            }
        }, []), (0, r.jsxs)(ti, {
            children: [(0, r.jsx)(ts, {
                className: "relative cursor-pointer rounded-full",
                "aria-label": "Account menu",
                children: t && (0, r.jsxs)(r.Fragment, {
                    children: [(0, r.jsx)(tp.AvatarComponent, {
                        data: t,
                        size: 40
                    }), (0, r.jsx)("span", {
                        className: "absolute right-0 bottom-0 size-2.5 rounded-full bg-emerald-500 ring-2 ring-background"
                    })]
                })
            }), (0, r.jsxs)(to, {
                align: "end",
                className: "min-w-60",
                children: [(0, r.jsx)(tl, {
                    children: (0, r.jsxs)(td, {
                        className: "flex items-center gap-2 py-2 font-normal",
                        children: [t && (0, r.jsx)(tp.AvatarComponent, {
                            data: t,
                            size: 40
                        }), (0, r.jsxs)("div", {
                            className: "flex flex-col gap-0.5",
                            children: [(0, r.jsx)("span", {
                                className: "font-medium text-foreground",
                                children: t ? .username
                            }), (0, r.jsx)("span", {
                                className: "text-xs text-muted-foreground",
                                children: t ? .email
                            })]
                        })]
                    })
                }), (0, r.jsx)(tc, {}), (0, r.jsxs)(tu, {
                    render: (0, r.jsx)("a", {
                        href: "/profile"
                    }),
                    children: [(0, r.jsx)(d.User, {}), "My Profile"]
                }), (0, r.jsxs)(tu, {
                    render: (0, r.jsx)("a", {
                        href: "/plans/add-plans"
                    }),
                    children: [(0, r.jsx)(s.CreditCard, {}), "Pricing"]
                }), (0, r.jsxs)(tu, {
                    render: (0, r.jsx)("a", {
                        href: "/#faq",
                        target: "_blank",
                        rel: "noopener noreferrer"
                    }),
                    children: [(0, r.jsx)(o.HelpCircle, {}), "FAQ"]
                }), (0, r.jsx)("div", {
                    className: "p-1 pt-2",
                    children: (0, r.jsxs)(c.Button, {
                        className: "w-full justify-center bg-destructive text-white hover:bg-destructive/90",
                        onClick: p,
                        children: ["Logout", (0, r.jsx)(l, {})]
                    })
                })]
            })]
        })
    }], 331278)
}, 932007, e => {
    "use strict";
    var t = e.i(843476),
        a = e.i(271645),
        r = e.i(422768),
        n = e.i(285595);
    let i = (0, e.i(456420).default)("cloud-upload", [
        ["path", {
            d: "M12 13v8",
            key: "1l5pq0"
        }],
        ["path", {
            d: "M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242",
            key: "1pljnt"
        }],
        ["path", {
            d: "m8 17 4-4 4 4",
            key: "1quai1"
        }]
    ]);
    var s = e.i(632781),
        o = e.i(168148),
        l = e.i(975157),
        d = e.i(93498);
    e.s(["GlobalUploadProgress", 0, function() {
        let [e, u] = (0, a.useState)([]);
        (0, a.useEffect)(() => {
            let e = d.uploadQueue.subscribe(e => u(e));
            return () => e.unsubscribe()
        }, []), (0, a.useEffect)(() => {
            if (!e.some(e => "uploading" === e.status)) return;
            let t = e => {
                if (d.uploadQueue.value.some(e => "uploading" === e.status)) return e.preventDefault(), e.returnValue = "Upload in progress. Are you sure you want to leave? Your upload will be lost.", e.returnValue
            };
            return window.addEventListener("beforeunload", t), () => window.removeEventListener("beforeunload", t)
        }, [e]);
        let c = (0, a.useMemo)(() => e.filter(e => "completed" === e.status).length, [e]),
            p = e.some(e => "uploading" === e.status);
        return e.length ? (0, t.jsxs)("div", {
            className: (0, l.cn)("fixed bottom-3 left-3 z-50 flex max-h-[65vh] w-auto max-w-[calc(100vw-1.5rem)] flex-col overflow-hidden rounded-2xl border", "bg-popover/95 shadow-[0_0_10px_2px_rgba(150,150,150,0.15)] backdrop-blur-md", "sm:bottom-6 sm:left-auto sm:right-6 sm:max-h-[70vh] sm:w-90 sm:max-w-none"),
            children: [(0, t.jsxs)("div", {
                className: "flex shrink-0 items-start gap-1.5 border-b p-2.5 sm:items-center sm:gap-2 sm:p-4",
                children: [(0, t.jsx)(i, {
                    className: "size-5 shrink-0 text-primary sm:size-6"
                }), (0, t.jsxs)("div", {
                    className: "min-w-0 flex-1",
                    children: [(0, t.jsxs)("p", {
                        className: "text-xs font-semibold sm:text-[0.9375rem]",
                        children: ["Uploading ", e.length, " ", 1 === e.length ? "file" : "files"]
                    }), (0, t.jsxs)("p", {
                        className: "text-[11px] text-muted-foreground sm:text-xs",
                        children: [c, " of ", e.length, " completed"]
                    })]
                })]
            }), (0, t.jsx)("div", {
                className: "flex-1 overflow-auto",
                children: e.map(e => (0, t.jsxs)("div", {
                    className: "border-b p-2.5 last:border-b-0 sm:p-4",
                    children: [(0, t.jsxs)("div", {
                        className: "mb-1 flex items-center gap-1.5 sm:gap-2",
                        children: ["uploading" === e.status && (0, t.jsx)(s.Loader2, {
                            className: "size-3.5 shrink-0 animate-spin text-primary sm:size-4"
                        }), "completed" === e.status && (0, t.jsx)(n.CircleCheck, {
                            className: "size-4 shrink-0 text-green-600 sm:size-5"
                        }), "error" === e.status && (0, t.jsx)(r.CircleAlert, {
                            className: "size-4 shrink-0 text-destructive sm:size-5"
                        }), (0, t.jsx)("p", {
                            className: "min-w-0 flex-1 truncate text-xs font-medium sm:text-sm",
                            children: e.fileName
                        }), (0, t.jsxs)("span", {
                            className: (0, l.cn)("shrink-0 text-[11px] font-semibold sm:text-xs", "completed" === e.status ? "text-green-600" : "error" === e.status ? "text-destructive" : "text-muted-foreground"),
                            children: [e.progress, "%"]
                        })]
                    }), "uploading" === e.status && (0, t.jsx)(o.Progress, {
                        value: e.progress,
                        className: "[&_[data-slot=progress-track]]:h-1"
                    }), "completed" === e.status && (0, t.jsx)(o.Progress, {
                        value: 100,
                        className: "[&_[data-slot=progress-indicator]]:bg-green-600 [&_[data-slot=progress-track]]:h-1"
                    }), "error" === e.status && (0, t.jsx)("p", {
                        className: "mt-0.5 text-[11px] text-destructive sm:text-xs",
                        children: e.error || "Upload failed"
                    })]
                }, e.id))
            }), p && (0, t.jsxs)("div", {
                className: "flex shrink-0 items-center gap-1.5 border-t bg-amber-500/10 p-2.5 sm:p-4",
                children: [(0, t.jsx)(r.CircleAlert, {
                    className: "size-3 shrink-0 text-amber-500 sm:size-3.5"
                }), (0, t.jsx)("p", {
                    className: "text-[11px] text-muted-foreground sm:text-xs",
                    children: "Do not close or refresh the page"
                })]
            })]
        }) : null
    }], 932007)
}]);