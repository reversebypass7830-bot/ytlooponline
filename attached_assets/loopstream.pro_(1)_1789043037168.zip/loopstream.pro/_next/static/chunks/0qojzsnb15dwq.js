(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 602927, e => {
    "use strict";
    var t, r, l, a, n, o = e.i(843476),
        s = e.i(271645),
        i = e.i(657688),
        c = e.i(522016),
        d = e.i(867927),
        u = e.i(515288),
        f = e.i(604829);
    let h = [{
        title: "What Is Loop Stream? Go Live on YouTube Without Going Live Yourself",
        url: "https://loopstream.pro/articles/what-is-loop-stream-go-live-youtube-without-being-live",
        thumbnail: "https://loopstream.pro/wp-content/uploads/2026/04/A1_Thumbnail.webp"
    }, {
        title: "Loop Stream vs Traditional Live Streaming (2026 Guide)",
        url: "https://loopstream.pro/articles/loop-stream-vs-traditional-live-streaming-guide",
        thumbnail: "https://loopstream.pro/wp-content/uploads/2026/04/Featured-Image.webp"
    }, {
        title: "Who Is Loop Stream For? 11 Types of YouTube Channels That Grow With 24/7 Live Streaming",
        url: "https://loopstream.pro/articles/who-is-loop-stream-for-11-types-of-youtube-channels-that-grow-with-24-7-live-streaming",
        thumbnail: "https://loopstream.pro/wp-content/uploads/2026/04/Who-is-Loop-Stream-For-Feature-Image.webp"
    }, {
        title: "Is Pre-Recorded Live Streaming Safe for Your Channel? Honest Pros, Cons and Best Practices",
        url: "https://loopstream.pro/articles/is-pre-recorded-live-streaming-safe-for-your-channel",
        thumbnail: "https://loopstream.pro/wp-content/uploads/2026/05/Feature-Image.webp"
    }];

    function m() {
        return (0, o.jsxs)(u.Card, {
            className: "gap-3 rounded-3xl border-none bg-card p-4 shadow-none",
            children: [(0, o.jsx)("h2", {
                className: "text-lg font-bold",
                children: "Articles to Help You Grow"
            }), (0, o.jsx)("div", {
                className: "flex flex-col gap-3",
                children: h.map(e => (0, o.jsxs)(c.default, {
                    href: e.url,
                    target: "_blank",
                    rel: "noopener noreferrer",
                    className: "flex min-h-16 items-center gap-3 rounded-2xl bg-muted px-3 py-2",
                    children: [(0, o.jsx)(i.default, {
                        src: e.thumbnail,
                        alt: "",
                        width: 96,
                        height: 54,
                        className: "h-[54px] w-24 shrink-0 rounded-lg object-cover",
                        unoptimized: !0
                    }), (0, o.jsx)("p", {
                        className: "flex-1 text-sm font-medium",
                        children: f.default.string.truncate(e.title, 60)
                    }), (0, o.jsx)(d.ChevronRight, {
                        className: "size-4 shrink-0 text-muted-foreground"
                    })]
                }, e.url))
            })]
        })
    }
    var x = e.i(615331),
        p = e.i(487486),
        v = e.i(519455),
        g = e.i(302747);

    function b({
        streams: e,
        loading: t
    }) {
        return (0, o.jsxs)(u.Card, {
            className: "gap-3 rounded-3xl border-none bg-card p-4 shadow-none",
            children: [(0, o.jsxs)("div", {
                className: "flex items-center justify-between",
                children: [(0, o.jsx)("h2", {
                    className: "text-lg font-bold",
                    children: "Recent Streams"
                }), (0, o.jsxs)(v.Button, {
                    size: "sm",
                    className: "font-bold",
                    nativeButton: !1,
                    render: (0, o.jsx)(c.default, {
                        href: "/stream"
                    }),
                    children: ["See All", (0, o.jsx)(d.ChevronRight, {
                        className: "size-4"
                    })]
                })]
            }), t ? (0, o.jsx)(g.Skeleton, {
                className: "h-16 w-full rounded-2xl"
            }) : e && 0 !== e.length ? (0, o.jsx)("div", {
                className: "flex flex-col gap-3",
                children: e.map((e, t) => (0, o.jsxs)("div", {
                    className: "flex min-h-16 items-center gap-3 rounded-2xl bg-muted px-3 py-2",
                    children: [(0, o.jsx)("div", {
                        className: "relative h-[54px] w-24 shrink-0 overflow-hidden rounded-lg bg-accent",
                        children: e.thumbnailKey && (0, o.jsx)(i.default, {
                            src: f.default.getCdnImageUrlFromKey(e.thumbnailKey),
                            alt: "",
                            fill: !0,
                            className: "object-cover",
                            unoptimized: !0
                        })
                    }), (0, o.jsx)("p", {
                        className: "flex-1 text-sm font-medium",
                        children: f.default.string.truncate(e.title, 15)
                    }), (0, o.jsx)(p.Badge, {
                        domain: "stream-status",
                        value: e.status,
                        className: "shrink-0",
                        iconOnly: !0
                    })]
                }, e.id || t))
            }) : (0, o.jsxs)("div", {
                className: "flex items-center justify-center gap-2 py-16 text-muted-foreground",
                children: [(0, o.jsx)(x.Radio, {
                    className: "size-6"
                }), (0, o.jsx)("span", {
                    children: "No stream"
                })]
            })]
        })
    }
    var w = e.i(725981),
        y = e.i(438583);

    function j({
        videos: e,
        loading: t
    }) {
        return (0, o.jsxs)(u.Card, {
            className: "gap-3 rounded-3xl border-none bg-card p-4 shadow-none",
            children: [(0, o.jsxs)("div", {
                className: "flex items-center justify-between",
                children: [(0, o.jsx)("h2", {
                    className: "text-lg font-bold",
                    children: "Recent Videos"
                }), (0, o.jsxs)(v.Button, {
                    size: "sm",
                    className: "font-bold",
                    nativeButton: !1,
                    render: (0, o.jsx)(c.default, {
                        href: "/media-library"
                    }),
                    children: ["See All", (0, o.jsx)(d.ChevronRight, {
                        className: "size-4"
                    })]
                })]
            }), t ? (0, o.jsx)(g.Skeleton, {
                className: "h-16 w-full rounded-2xl"
            }) : e && 0 !== e.length ? (0, o.jsx)("div", {
                className: "flex flex-col gap-3",
                children: e.map((e, t) => (0, o.jsxs)("div", {
                    className: "flex min-h-16 items-center gap-3 rounded-2xl bg-muted px-3 py-2",
                    children: [(0, o.jsx)("div", {
                        className: "relative flex h-[54px] w-24 shrink-0 items-center justify-center overflow-hidden rounded-lg bg-accent",
                        children: e.metadata ? .thumbnail ? (0, o.jsx)(i.default, {
                            src: f.default.getCdnImageUrlFromKey(e.metadata.thumbnail),
                            alt: "",
                            fill: !0,
                            className: "object-cover",
                            unoptimized: !0
                        }) : (0, o.jsx)(y.Video, {
                            className: "size-6 text-muted-foreground"
                        })
                    }), (0, o.jsx)("p", {
                        className: "flex-1 text-sm font-medium",
                        children: f.default.string.truncate(e.fileName || "", 8)
                    }), (0, o.jsx)(p.Badge, {
                        domain: "media-status",
                        value: e.metadata ? .status,
                        className: "shrink-0",
                        iconOnly: !0
                    })]
                }, e.id || t))
            }) : (0, o.jsxs)("div", {
                className: "flex flex-col items-center justify-center gap-3 rounded-2xl border border-dashed py-9",
                children: [(0, o.jsx)("p", {
                    className: "text-sm text-muted-foreground",
                    children: "No recent videos found."
                }), (0, o.jsxs)(v.Button, {
                    variant: "outline",
                    nativeButton: !1,
                    render: (0, o.jsx)(c.default, {
                        href: "/media-library"
                    }),
                    children: [(0, o.jsx)(w.Upload, {
                        className: "size-4"
                    }), "Upload"]
                })]
            })]
        })
    }
    var S = e.i(77071);

    function N({
        streams: e,
        loading: t
    }) {
        return (0, o.jsxs)(u.Card, {
            className: "gap-3 rounded-3xl border-none bg-card p-4 shadow-none",
            children: [(0, o.jsx)("h2", {
                className: "text-lg font-bold",
                children: "Upcoming Streams"
            }), t ? (0, o.jsx)(g.Skeleton, {
                className: "h-16 w-full rounded-2xl"
            }) : 0 === e.length ? (0, o.jsxs)("div", {
                className: "flex flex-col items-center justify-center gap-3 py-6",
                children: [(0, o.jsx)("p", {
                    className: "text-sm text-muted-foreground",
                    children: "No upcoming streams scheduled"
                }), (0, o.jsxs)(v.Button, {
                    className: "border-primary bg-background text-primary hover:bg-primary/10 hover:text-primary",
                    nativeButton: !1,
                    render: (0, o.jsx)(c.default, {
                        href: "/stream"
                    }),
                    children: [(0, o.jsx)(S.Plus, {
                        className: "size-4"
                    }), "Schedule a Stream"]
                })]
            }) : (0, o.jsx)("div", {
                className: "flex flex-col gap-3",
                children: e.map(e => ({
                    date: new Date(e.createdAt),
                    quality: e.category || "-",
                    title: e.title || "Untitled"
                })).map((e, t) => (0, o.jsxs)("div", {
                    className: "flex min-h-16 items-center gap-3 rounded-2xl bg-muted px-3 py-3",
                    children: [(0, o.jsxs)("div", {
                        className: "flex size-12 shrink-0 flex-col items-center justify-center rounded-lg bg-primary text-primary-foreground",
                        children: [(0, o.jsx)("span", {
                            className: "text-base font-bold leading-none",
                            children: e.date.getDate()
                        }), (0, o.jsx)("span", {
                            className: "text-xs leading-none",
                            children: e.date.toLocaleString("en-US", {
                                month: "short"
                            })
                        })]
                    }), (0, o.jsxs)("div", {
                        className: "flex flex-1 flex-col items-center",
                        children: [(0, o.jsx)("span", {
                            className: "text-sm",
                            children: e.date.toLocaleTimeString([], {
                                hour: "2-digit",
                                minute: "2-digit",
                                hour12: !1
                            })
                        }), (0, o.jsx)("span", {
                            className: "rounded border border-primary px-1.5 py-0.5 text-xs font-bold",
                            children: e.quality.split("-")[0]
                        })]
                    }), (0, o.jsx)("p", {
                        className: "text-sm font-medium",
                        children: f.default.string.truncate(e.title, 25)
                    })]
                }, t))
            })]
        })
    }
    e.s([], 673176), e.i(673176), e.i(247167);
    var E = e.i(667865),
        C = e.i(439957),
        R = e.i(733332);
    let T = s.createContext(void 0);

    function A() {
        let e = s.useContext(T);
        if (void 0 === e) throw Error((0, R.default)(53));
        return e
    }
    var P = e.i(552245);
    let O = ((t = {}).scrollAreaCornerHeight = "--scroll-area-corner-height", t.scrollAreaCornerWidth = "--scroll-area-corner-width", t);

    function z(e, t, r) {
        if (!e) return 0;
        let l = getComputedStyle(e),
            a = "x" === r ? "Inline" : "Block";
        return "x" === r && "margin" === t ? 2 * parseFloat(l[`${t}InlineStart`]) : parseFloat(l[`${t}${a}Start`]) + parseFloat(l[`${t}${a}End`])
    }
    let Y = ((r = {}).orientation = "data-orientation", r.hovering = "data-hovering", r.scrolling = "data-scrolling", r.hasOverflowX = "data-has-overflow-x", r.hasOverflowY = "data-has-overflow-y", r.overflowXStart = "data-overflow-x-start", r.overflowXEnd = "data-overflow-x-end", r.overflowYStart = "data-overflow-y-start", r.overflowYEnd = "data-overflow-y-end", r);
    var L = e.i(60837),
        W = e.i(788015);
    let I = ((l = {}).scrolling = "data-scrolling", l.hasOverflowX = "data-has-overflow-x", l.hasOverflowY = "data-has-overflow-y", l.overflowXStart = "data-overflow-x-start", l.overflowXEnd = "data-overflow-x-end", l.overflowYStart = "data-overflow-y-start", l.overflowYEnd = "data-overflow-y-end", l),
        F = {
            hasOverflowX: e => e ? {
                [I.hasOverflowX]: ""
            } : null,
            hasOverflowY: e => e ? {
                [I.hasOverflowY]: ""
            } : null,
            overflowXStart: e => e ? {
                [I.overflowXStart]: ""
            } : null,
            overflowXEnd: e => e ? {
                [I.overflowXEnd]: ""
            } : null,
            overflowYStart: e => e ? {
                [I.overflowYStart]: ""
            } : null,
            overflowYEnd: e => e ? {
                [I.overflowYEnd]: ""
            } : null,
            cornerHidden: () => null
        };
    var H = e.i(647554),
        X = e.i(172410);
    let M = {
            x: 0,
            y: 0
        },
        k = {
            width: 0,
            height: 0
        },
        B = {
            xStart: !1,
            xEnd: !1,
            yStart: !1,
            yEnd: !1
        },
        U = {
            x: !0,
            y: !0,
            corner: !0
        },
        D = s.forwardRef(function(e, t) {
            let {
                render: r,
                className: l,
                overflowEdgeThreshold: a,
                style: n,
                ...i
            } = e, {
                xStart: c,
                xEnd: d,
                yStart: u,
                yEnd: f
            } = function(e) {
                if ("number" == typeof e) {
                    let t = Math.max(0, e);
                    return {
                        xStart: t,
                        xEnd: t,
                        yStart: t,
                        yEnd: t
                    }
                }
                return {
                    xStart: Math.max(0, e ? .xStart || 0),
                    xEnd: Math.max(0, e ? .xEnd || 0),
                    yStart: Math.max(0, e ? .yStart || 0),
                    yEnd: Math.max(0, e ? .yEnd || 0)
                }
            }(a), h = (0, W.useBaseUiId)(), m = (0, C.useTimeout)(), x = (0, C.useTimeout)(), {
                nonce: p,
                disableStyleElements: v
            } = (0, X.useCSPContext)(), [g, b] = s.useState(!1), [w, y] = s.useState(!1), [j, S] = s.useState(!1), [N, R] = s.useState(!1), [A, I] = s.useState(!1), [D, $] = s.useState(k), [G, V] = s.useState(k), [_, K] = s.useState(B), [q, J] = s.useState(U), Q = s.useRef(null), Z = s.useRef(null), ee = s.useRef(null), et = s.useRef(null), er = s.useRef(null), el = s.useRef(null), ea = s.useRef(null), en = s.useRef(!1), eo = s.useRef(0), es = s.useRef(0), ei = s.useRef(0), ec = s.useRef(0), ed = s.useRef("vertical"), eu = s.useRef(M), ef = (0, E.useStableCallback)(e => {
                let t = e.x - eu.current.x,
                    r = e.y - eu.current.y;
                eu.current = e, 0 !== r && (S(!0), m.start(500, () => {
                    S(!1)
                })), 0 !== t && (y(!0), x.start(500, () => {
                    y(!1)
                }))
            }), eh = (0, E.useStableCallback)(e => {
                0 === e.button && (en.current = !0, eo.current = e.clientY, es.current = e.clientX, ed.current = e.currentTarget.getAttribute(Y.orientation), Z.current && (ei.current = Z.current.scrollTop, ec.current = Z.current.scrollLeft), er.current && "vertical" === ed.current && er.current.setPointerCapture(e.pointerId), el.current && "horizontal" === ed.current && el.current.setPointerCapture(e.pointerId))
            }), em = (0, E.useStableCallback)(e => {
                if (!en.current) return;
                let t = e.clientY - eo.current,
                    r = e.clientX - es.current;
                if (Z.current) {
                    let l = Z.current.scrollHeight,
                        a = Z.current.clientHeight,
                        n = Z.current.scrollWidth,
                        o = Z.current.clientWidth;
                    if (er.current && ee.current && "vertical" === ed.current) {
                        let r = z(ee.current, "padding", "y"),
                            n = z(er.current, "margin", "y"),
                            o = er.current.offsetHeight,
                            s = ee.current.offsetHeight - o - r - n;
                        Z.current.scrollTop = ei.current + t / s * (l - a), e.preventDefault(), S(!0), m.start(500, () => {
                            S(!1)
                        })
                    }
                    if (el.current && et.current && "horizontal" === ed.current) {
                        let t = z(et.current, "padding", "x"),
                            l = z(el.current, "margin", "x"),
                            a = el.current.offsetWidth,
                            s = et.current.offsetWidth - a - t - l;
                        Z.current.scrollLeft = ec.current + r / s * (n - o), e.preventDefault(), y(!0), x.start(500, () => {
                            y(!1)
                        })
                    }
                }
            }), ex = (0, E.useStableCallback)(e => {
                en.current = !1, er.current && "vertical" === ed.current && er.current.hasPointerCapture(e.pointerId) && er.current.releasePointerCapture(e.pointerId), el.current && "horizontal" === ed.current && el.current.hasPointerCapture(e.pointerId) && el.current.releasePointerCapture(e.pointerId)
            });

            function ep(e) {
                R("touch" === e.pointerType)
            }

            function ev(e) {
                ep(e), "touch" !== e.pointerType && b((0, H.contains)(Q.current, e.target))
            }
            let eg = s.useMemo(() => ({
                    scrolling: w || j,
                    hasOverflowX: !q.x,
                    hasOverflowY: !q.y,
                    overflowXStart: _.xStart,
                    overflowXEnd: _.xEnd,
                    overflowYStart: _.yStart,
                    overflowYEnd: _.yEnd,
                    cornerHidden: q.corner
                }), [w, j, q.x, q.y, q.corner, _]),
                eb = {
                    role: "presentation",
                    onPointerEnter: ev,
                    onPointerMove: ev,
                    onPointerDown: ep,
                    onPointerLeave() {
                        b(!1)
                    },
                    style: {
                        position: "relative",
                        [O.scrollAreaCornerHeight]: `${D.height}px`,
                        [O.scrollAreaCornerWidth]: `${D.width}px`
                    }
                },
                ew = (0, P.useRenderElement)("div", e, {
                    state: eg,
                    ref: [t, Q],
                    props: [eb, i],
                    stateAttributesMapping: F
                }),
                ey = s.useMemo(() => ({
                    handlePointerDown: eh,
                    handlePointerMove: em,
                    handlePointerUp: ex,
                    handleScroll: ef,
                    cornerSize: D,
                    setCornerSize: $,
                    thumbSize: G,
                    setThumbSize: V,
                    hasMeasuredScrollbar: A,
                    setHasMeasuredScrollbar: I,
                    touchModality: N,
                    cornerRef: ea,
                    scrollingX: w,
                    setScrollingX: y,
                    scrollingY: j,
                    setScrollingY: S,
                    hovering: g,
                    setHovering: b,
                    viewportRef: Z,
                    rootRef: Q,
                    scrollbarYRef: ee,
                    scrollbarXRef: et,
                    thumbYRef: er,
                    thumbXRef: el,
                    rootId: h,
                    hiddenState: q,
                    setHiddenState: J,
                    overflowEdges: _,
                    setOverflowEdges: K,
                    viewportState: eg,
                    overflowEdgeThreshold: {
                        xStart: c,
                        xEnd: d,
                        yStart: u,
                        yEnd: f
                    }
                }), [eh, em, ex, ef, D, G, A, N, w, y, j, S, g, b, h, q, _, eg, c, d, u, f]);
            return (0, o.jsxs)(T.Provider, {
                value: ey,
                children: [!v && L.styleDisableScrollbar.getElement(p), ew]
            })
        });
    var $ = e.i(146376),
        G = e.i(328744);
    let V = s.createContext(void 0);
    var _ = e.i(872855),
        K = e.i(201675);
    let q = ((a = {}).scrollAreaOverflowXStart = "--scroll-area-overflow-x-start", a.scrollAreaOverflowXEnd = "--scroll-area-overflow-x-end", a.scrollAreaOverflowYStart = "--scroll-area-overflow-y-start", a.scrollAreaOverflowYEnd = "--scroll-area-overflow-y-end", a);
    var J = e.i(550896);
    let Q = !1,
        Z = s.forwardRef(function(e, t) {
            let {
                render: r,
                className: l,
                style: a,
                ...n
            } = e, {
                viewportRef: i,
                scrollbarYRef: c,
                scrollbarXRef: d,
                thumbYRef: u,
                thumbXRef: f,
                cornerRef: h,
                cornerSize: m,
                setCornerSize: x,
                setThumbSize: p,
                rootId: v,
                setHiddenState: g,
                hiddenState: b,
                setHasMeasuredScrollbar: w,
                handleScroll: y,
                setHovering: j,
                setOverflowEdges: S,
                overflowEdges: N,
                overflowEdgeThreshold: R,
                scrollingX: T,
                scrollingY: O
            } = A(), Y = (0, _.useDirection)(), W = s.useRef(!0), I = s.useRef([NaN, NaN, NaN, NaN]), H = (0, C.useTimeout)(), X = (0, C.useTimeout)(), M = (0, E.useStableCallback)(() => {
                var e;
                let t, r, l = i.current,
                    a = c.current,
                    n = d.current,
                    o = u.current,
                    s = f.current,
                    v = h.current;
                if (!l) return;
                let b = l.scrollHeight,
                    y = l.scrollWidth,
                    j = l.clientHeight,
                    N = l.clientWidth,
                    E = l.scrollTop,
                    C = l.scrollLeft,
                    T = I.current,
                    A = Number.isNaN(T[0]);
                if (T[0] = j, T[1] = b, T[2] = N, T[3] = y, A && w(!0), 0 === b || 0 === y) return;
                let P = (t = (e = l).clientHeight >= e.scrollHeight, {
                        y: t,
                        x: r = e.clientWidth >= e.scrollWidth,
                        corner: t || r
                    }),
                    O = P.y,
                    L = P.x,
                    W = N / y,
                    F = j / b,
                    H = Math.max(0, y - N),
                    X = Math.max(0, b - j),
                    M = 0,
                    k = 0;
                if (!L) {
                    let e = 0;
                    e = "rtl" === Y ? (0, K.clamp)(-C, 0, H) : (0, K.clamp)(C, 0, H), M = (0, J.normalizeScrollOffset)(e, H), k = H - M
                }
                let B = O ? 0 : (0, K.clamp)(E, 0, X),
                    U = O ? 0 : (0, J.normalizeScrollOffset)(B, X),
                    D = O ? 0 : X - U,
                    $ = L ? 0 : N,
                    G = O ? 0 : j,
                    V = 0,
                    _ = 0;
                L || O || (V = a ? .offsetWidth || 0, _ = n ? .offsetHeight || 0);
                let Q = 0 === m.width && 0 === m.height,
                    Z = Q ? V : 0,
                    ee = Q ? _ : 0,
                    et = z(n, "padding", "x"),
                    er = z(a, "padding", "y"),
                    el = z(s, "margin", "x"),
                    ea = z(o, "margin", "y"),
                    en = $ - et - el,
                    eo = G - er - ea,
                    es = n ? Math.min(n.offsetWidth - Z, en) : en,
                    ei = a ? Math.min(a.offsetHeight - ee, eo) : eo,
                    ec = Math.max(16, es * W),
                    ed = Math.max(16, ei * F);
                if (p(e => e.height === ed && e.width === ec ? e : {
                        width: ec,
                        height: ed
                    }), a && o) {
                    let e = a.offsetHeight - ed - er - ea,
                        t = b - j,
                        r = Math.min(e, Math.max(0, (0 === t ? 0 : E / t) * e));
                    o.style.transform = `translate3d(0,${r}px,0)`
                }
                if (n && s) {
                    let e = n.offsetWidth - ec - et - el,
                        t = y - N,
                        r = 0 === t ? 0 : C / t,
                        l = "rtl" === Y ? (0, K.clamp)(r * e, -e, 0) : (0, K.clamp)(r * e, 0, e);
                    s.style.transform = `translate3d(${l}px,0,0)`
                }
                for (let [e, t] of [
                        [q.scrollAreaOverflowXStart, M],
                        [q.scrollAreaOverflowXEnd, k],
                        [q.scrollAreaOverflowYStart, U],
                        [q.scrollAreaOverflowYEnd, D]
                    ]) l.style.setProperty(e, `${t}px`);
                v && (L || O ? x({
                    width: 0,
                    height: 0
                }) : L || O || x({
                    width: V,
                    height: _
                })), g(e => {
                    var t, r;
                    return t = e, r = P, t.y === r.y && t.x === r.x && t.corner === r.corner ? t : r
                });
                let eu = {
                    xStart: !L && M > R.xStart,
                    xEnd: !L && k > R.xEnd,
                    yStart: !O && U > R.yStart,
                    yEnd: !O && D > R.yEnd
                };
                S(e => e.xStart === eu.xStart && e.xEnd === eu.xEnd && e.yStart === eu.yStart && e.yEnd === eu.yEnd ? e : eu)
            });

            function k() {
                W.current = !1
            }(0, $.useIsoLayoutEffect)(() => {
                i.current && (Q || G.platform.engine.webkit || ("u" > typeof CSS && "registerProperty" in CSS && [q.scrollAreaOverflowXStart, q.scrollAreaOverflowXEnd, q.scrollAreaOverflowYStart, q.scrollAreaOverflowYEnd].forEach(e => {
                    try {
                        CSS.registerProperty({
                            name: e,
                            syntax: "<length>",
                            inherits: !1,
                            initialValue: "0px"
                        })
                    } catch {}
                }), Q = !0))
            }, [i]), (0, $.useIsoLayoutEffect)(() => {
                queueMicrotask(M)
            }, [M, b, Y, R.xStart, R.xEnd, R.yStart, R.yEnd]), (0, $.useIsoLayoutEffect)(() => {
                i.current ? .matches(":hover") && j(!0)
            }, [i, j]), (0, $.useIsoLayoutEffect)(() => {
                let e = i.current;
                if ("u" < typeof ResizeObserver || !e) return;
                let t = !1,
                    r = new ResizeObserver(() => {
                        if (!t) {
                            t = !0;
                            let r = I.current;
                            if (r[0] === e.clientHeight && r[1] === e.scrollHeight && r[2] === e.clientWidth && r[3] === e.scrollWidth) return
                        }
                        M()
                    });
                return r.observe(e), X.start(0, () => {
                    let t = e.getAnimations({
                        subtree: !0
                    });
                    0 !== t.length && Promise.allSettled(t.map(e => e.finished)).then(M).catch(() => {})
                }), () => {
                    r.disconnect(), X.clear()
                }
            }, [M, i, X]);
            let B = {
                    role: "presentation",
                    ...v && {
                        "data-id": `${v}-viewport`
                    },
                    tabIndex: b.x && b.y ? -1 : 0,
                    className: L.styleDisableScrollbar.className,
                    style: {
                        overflow: "scroll"
                    },
                    onScroll() {
                        i.current && (M(), W.current || y({
                            x: i.current.scrollLeft,
                            y: i.current.scrollTop
                        }), H.start(100, () => {
                            W.current = !0
                        }))
                    },
                    onWheel: k,
                    onTouchMove: k,
                    onPointerMove: k,
                    onPointerEnter: k,
                    onKeyDown: k
                },
                U = s.useMemo(() => ({
                    scrolling: T || O,
                    hasOverflowX: !b.x,
                    hasOverflowY: !b.y,
                    overflowXStart: N.xStart,
                    overflowXEnd: N.xEnd,
                    overflowYStart: N.yStart,
                    overflowYEnd: N.yEnd,
                    cornerHidden: b.corner
                }), [T, O, b.x, b.y, b.corner, N]),
                D = (0, P.useRenderElement)("div", e, {
                    ref: [t, i],
                    state: U,
                    props: [B, n],
                    stateAttributesMapping: F
                }),
                Z = s.useMemo(() => ({
                    computeThumbPosition: M
                }), [M]);
            return (0, o.jsx)(V.Provider, {
                value: Z,
                children: D
            })
        });
    var ee = e.i(574735);
    let et = s.createContext(void 0),
        er = ((n = {}).scrollAreaThumbHeight = "--scroll-area-thumb-height", n.scrollAreaThumbWidth = "--scroll-area-thumb-width", n),
        el = s.forwardRef(function(e, t) {
            let {
                render: r,
                className: l,
                orientation: a = "vertical",
                keepMounted: n = !1,
                style: i,
                ...c
            } = e, {
                hovering: d,
                scrollingX: u,
                scrollingY: f,
                hiddenState: h,
                overflowEdges: m,
                scrollbarYRef: x,
                scrollbarXRef: p,
                viewportRef: v,
                thumbYRef: g,
                thumbXRef: b,
                handlePointerDown: w,
                handlePointerUp: y,
                handleScroll: j,
                rootId: S,
                thumbSize: N,
                hasMeasuredScrollbar: E
            } = A(), C = {
                hovering: d,
                scrolling: {
                    horizontal: u,
                    vertical: f
                }[a],
                orientation: a,
                hasOverflowX: !h.x,
                hasOverflowY: !h.y,
                overflowXStart: m.xStart,
                overflowXEnd: m.xEnd,
                overflowYStart: m.yStart,
                overflowYEnd: m.yEnd,
                cornerHidden: h.corner
            }, R = (0, _.useDirection)(), T = !E && !n, Y = "vertical" === a ? h.y : h.x, L = n || !Y;
            s.useEffect(() => {
                if (!L) return;
                let e = v.current,
                    t = "vertical" === a ? x.current : p.current;
                if (t) return (0, ee.addEventListener)(t, "wheel", function(r) {
                    if (!e || !t || r.ctrlKey) return;
                    let l = "horizontal" === a,
                        n = l ? "scrollLeft" : "scrollTop",
                        o = l ? r.deltaX : r.deltaY;
                    if (0 === o) return;
                    let s = l ? e.scrollWidth - e.clientWidth : e.scrollHeight - e.clientHeight,
                        i = l && "rtl" === R ? -s : 0,
                        c = l && "rtl" === R ? 0 : s,
                        d = e[n];
                    d <= i && o < 0 || d >= c && o > 0 || (r.preventDefault(), e[n] = Math.min(c, Math.max(i, d + o)), j({
                        x: e.scrollLeft,
                        y: e.scrollTop
                    }))
                }, {
                    passive: !1
                })
            }, [R, j, a, p, x, L, v]);
            let W = { ...S && {
                        "data-id": `${S}-scrollbar`
                    },
                    onPointerDown(e) {
                        if (0 !== e.button) return;
                        let t = (0, H.getTarget)(e.nativeEvent),
                            r = "vertical" === a ? g.current : b.current;
                        if (!(r && (0, H.contains)(r, t)) && v.current) {
                            if (g.current && x.current && "vertical" === a) {
                                let t = z(g.current, "margin", "y"),
                                    r = z(x.current, "padding", "y"),
                                    l = g.current.offsetHeight,
                                    a = x.current.getBoundingClientRect(),
                                    n = e.clientY - a.top - l / 2 - r + t / 2,
                                    o = v.current.scrollHeight,
                                    s = v.current.clientHeight,
                                    i = x.current.offsetHeight - l - r - t;
                                v.current.scrollTop = n / i * (o - s)
                            }
                            if (b.current && p.current && "horizontal" === a) {
                                let t, r = z(b.current, "margin", "x"),
                                    l = z(p.current, "padding", "x"),
                                    a = b.current.offsetWidth,
                                    n = p.current.getBoundingClientRect(),
                                    o = e.clientX - n.left - a / 2 - l + r / 2,
                                    s = v.current.scrollWidth,
                                    i = v.current.clientWidth,
                                    c = o / (p.current.offsetWidth - a - l - r);
                                "rtl" === R ? (t = (1 - c) * (s - i), v.current.scrollLeft <= 0 && (t = -t)) : t = c * (s - i), v.current.scrollLeft = t
                            }
                            j({
                                x: v.current.scrollLeft,
                                y: v.current.scrollTop
                            }), w(e)
                        }
                    },
                    onPointerUp: y,
                    onPointerCancel: y,
                    style: {
                        position: "absolute",
                        touchAction: "none",
                        WebkitUserSelect: "none",
                        userSelect: "none",
                        visibility: T ? "hidden" : void 0,
                        ..."vertical" === a && {
                            top: 0,
                            bottom: `var(${O.scrollAreaCornerHeight})`,
                            insetInlineEnd: 0,
                            [er.scrollAreaThumbHeight]: `${N.height}px`
                        },
                        ..."horizontal" === a && {
                            insetInlineStart: 0,
                            insetInlineEnd: `var(${O.scrollAreaCornerWidth})`,
                            bottom: 0,
                            [er.scrollAreaThumbWidth]: `${N.width}px`
                        }
                    }
                },
                I = (0, P.useRenderElement)("div", e, {
                    ref: [t, "vertical" === a ? x : p],
                    state: C,
                    props: [W, c],
                    stateAttributesMapping: F
                }),
                X = s.useMemo(() => ({
                    orientation: a
                }), [a]);
            return L ? (0, o.jsx)(et.Provider, {
                value: X,
                children: I
            }) : null
        }),
        ea = s.forwardRef(function(e, t) {
            let {
                render: r,
                className: l,
                style: a,
                ...n
            } = e, {
                computeThumbPosition: o
            } = function() {
                let e = s.useContext(V);
                if (void 0 === e) throw Error((0, R.default)(55));
                return e
            }(), {
                hasMeasuredScrollbar: i,
                viewportState: c
            } = A(), d = s.useRef(null), u = s.useRef(i);
            return (0, $.useIsoLayoutEffect)(() => {
                if ("u" < typeof ResizeObserver) return;
                let e = !1,
                    t = new ResizeObserver(() => {
                        (e || (e = !0, u.current)) && o()
                    });
                return d.current && t.observe(d.current), () => {
                    t.disconnect()
                }
            }, [o]), (0, P.useRenderElement)("div", e, {
                ref: [t, d],
                state: c,
                stateAttributesMapping: F,
                props: [{
                    role: "presentation",
                    style: {
                        minWidth: "fit-content"
                    }
                }, n]
            })
        }),
        en = s.forwardRef(function(e, t) {
            let {
                render: r,
                className: l,
                style: a,
                ...n
            } = e, {
                thumbYRef: o,
                thumbXRef: i,
                handlePointerDown: c,
                handlePointerMove: d,
                handlePointerUp: u,
                setScrollingX: f,
                setScrollingY: h,
                scrollingX: m,
                scrollingY: x,
                hasMeasuredScrollbar: p
            } = A(), {
                orientation: v
            } = function() {
                let e = s.useContext(et);
                if (void 0 === e) throw Error((0, R.default)(54));
                return e
            }();

            function g(e) {
                "vertical" === v && h(!1), "horizontal" === v && f(!1), u(e)
            }
            return (0, P.useRenderElement)("div", e, {
                ref: [t, "vertical" === v ? o : i],
                state: {
                    scrolling: "horizontal" === v ? m : x,
                    orientation: v
                },
                props: [{
                    onPointerDown: c,
                    onPointerMove: d,
                    onPointerUp: g,
                    onPointerCancel: g,
                    style: {
                        visibility: p ? void 0 : "hidden",
                        ..."vertical" === v && {
                            height: `var(${er.scrollAreaThumbHeight})`
                        },
                        ..."horizontal" === v && {
                            width: `var(${er.scrollAreaThumbWidth})`
                        }
                    }
                }, n]
            })
        }),
        eo = s.forwardRef(function(e, t) {
            let {
                render: r,
                className: l,
                style: a,
                ...n
            } = e, {
                cornerRef: o,
                cornerSize: s,
                hiddenState: i
            } = A(), c = (0, P.useRenderElement)("div", e, {
                ref: [t, o],
                props: [{
                    style: {
                        position: "absolute",
                        bottom: 0,
                        insetInlineEnd: 0,
                        width: s.width,
                        height: s.height
                    }
                }, n]
            });
            return i.corner ? null : c
        });
    e.s(["Content", 0, ea, "Corner", 0, eo, "Root", 0, D, "Scrollbar", 0, el, "Thumb", 0, en, "Viewport", 0, Z], 236093);
    var es = e.i(236093),
        es = es,
        ei = e.i(975157);

    function ec({
        className: e,
        children: t,
        ...r
    }) {
        return (0, o.jsxs)(es.Root, {
            "data-slot": "scroll-area",
            className: (0, ei.cn)("relative", e),
            ...r,
            children: [(0, o.jsx)(es.Viewport, {
                "data-slot": "scroll-area-viewport",
                className: "size-full rounded-[inherit] transition-[color,box-shadow] outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50 focus-visible:outline-1",
                children: t
            }), (0, o.jsx)(ed, {}), (0, o.jsx)(es.Corner, {})]
        })
    }

    function ed({
        className: e,
        orientation: t = "vertical",
        ...r
    }) {
        return (0, o.jsx)(es.Scrollbar, {
            "data-slot": "scroll-area-scrollbar",
            "data-orientation": t,
            orientation: t,
            className: (0, ei.cn)("flex touch-none p-px transition-colors select-none data-horizontal:h-2.5 data-horizontal:flex-col data-horizontal:border-t data-horizontal:border-t-transparent data-vertical:h-full data-vertical:w-2.5 data-vertical:border-l data-vertical:border-l-transparent", e),
            ...r,
            children: (0, o.jsx)(es.Thumb, {
                "data-slot": "scroll-area-thumb",
                className: "relative flex-1 rounded-full bg-border"
            })
        })
    }
    let eu = {
            Featured: "🔥",
            New: void 0
        },
        ef = [{
            title: "Upload Videos & Build Your First Playlist in Loop Stream | Stream Pre-recorded Video Live 24x7",
            videoUrl: "https://www.youtube.com/watch?v=F4EuD_GoBe8",
            label: "New"
        }, {
            title: "Stream Pre-Recorded Videos as LIVE on YouTube (Without Being On Camera)",
            videoUrl: "https://www.youtube.com/watch?v=dbLnpxOyFvE",
            label: "Featured"
        }, {
            title: "How to Set Up Loop Stream – Account, Email Verification & Dashboard Guide",
            videoUrl: "https://www.youtube.com/watch?v=t2PVpIX5rFo",
            label: "New"
        }];

    function eh() {
        return (0, o.jsxs)("div", {
            className: "flex flex-col gap-3",
            children: [(0, o.jsx)("h2", {
                className: "text-lg font-bold",
                children: "Recommended by Loop Stream"
            }), (0, o.jsx)("div", {
                className: "grid grid-cols-1 gap-6 sm:grid-cols-2",
                children: ef.map(e => (0, o.jsx)(c.default, {
                    href: e.videoUrl,
                    target: "_blank",
                    rel: "noopener noreferrer",
                    children: (0, o.jsxs)(u.Card, {
                        className: "gap-0 overflow-hidden rounded-2xl border-none bg-muted p-0 shadow-none",
                        children: [e.label && (0, o.jsxs)("div", {
                            className: "flex items-center justify-end ",
                            children: [eu[e.label] && (0, o.jsx)("span", {
                                className: "px-2",
                                children: eu[e.label]
                            }), (0, o.jsx)(p.Badge, {
                                className: "h-auto min-w-[100px] justify-center rounded-none rounded-bl-full bg-primary px-3 py-0.5 font-bold text-primary-foreground",
                                children: e.label
                            })]
                        }), (0, o.jsxs)("div", {
                            className: "flex items-center gap-3 p-3 pt-1",
                            children: [(0, o.jsx)("img", {
                                src: function(e, t = "maxresdefault") {
                                    for (let r of [/(?:youtube\.com\/watch\?v=)([^&\n?#]+)/, /(?:youtu\.be\/)([^&\n?#]+)/, /(?:youtube\.com\/embed\/)([^&\n?#]+)/, /(?:youtube\.com\/v\/)([^&\n?#]+)/, /(?:youtube\.com\/shorts\/)([^&\n?#]+)/]) {
                                        let l = e.match(r);
                                        if (l && l[1]) return `https://img.youtube.com/vi/${l[1]}/${t}.jpg`
                                    }
                                    return null
                                }(e.videoUrl) ? ? "/images/placeholder/Working_on_tutorials.webp",
                                alt: "",
                                className: "h-[90px] w-40 shrink-0 rounded-lg object-cover"
                            }), (0, o.jsx)("p", {
                                className: "flex-1 text-sm font-medium",
                                children: e.title
                            })]
                        })]
                    })
                }, e.videoUrl))
            })]
        })
    }

    function em() {
        return (0, o.jsx)(u.Card, {
            className: "gap-3 rounded-3xl border-none bg-card p-4 shadow-none",
            children: (0, o.jsxs)(ec, {
                className: "max-h-[820px]",
                children: [(0, o.jsx)("h2", {
                    className: "p-2 text-lg font-bold",
                    children: "Video Tutorials"
                }), (0, o.jsx)("div", {
                    className: "relative w-full overflow-hidden rounded-2xl pt-[56.25%]",
                    children: (0, o.jsx)("iframe", {
                        className: "absolute inset-0 size-full border-0",
                        src: "https://www.youtube.com/embed/dbLnpxOyFvE",
                        title: "LoopStream Tutorial",
                        referrerPolicy: "strict-origin-when-cross-origin",
                        allowFullScreen: !0
                    })
                }), (0, o.jsx)("div", {
                    className: "mt-4",
                    children: (0, o.jsx)(eh, {})
                })]
            })
        })
    }
    var ex = e.i(552838),
        ep = e.i(618566),
        ev = e.i(846696),
        eg = e.i(350854);
    let eb = {
        [ex.GlobalConstants.FreeTrialStatus.PENDING]: "Your free trial request is being reviewed. We'll notify you as soon as it's ready - usually within 24 hours.",
        [ex.GlobalConstants.FreeTrialStatus.REJECTED]: "Your free trial request wasn't approved this time. See the common reasons below to understand what happened.",
        [ex.GlobalConstants.FreeTrialStatus.APPROVED]: "Your free trial is ready. Claim it now to unlock 24 hours of full Premium features."
    };

    function ew({
        trial: e
    }) {
        let t = (0, ep.useRouter)(),
            [r, l] = (0, s.useState)(!1),
            a = eb[e.status];
        if (!a) return null;
        let n = e.status === ex.GlobalConstants.FreeTrialStatus.APPROVED,
            i = e.status === ex.GlobalConstants.FreeTrialStatus.REJECTED;
        async function d() {
            if (!e.couponCode) return void ev.toast.error("Something went wrong — please contact support");
            l(!0);
            try {
                let r = (await eg.default.productService.getProducts()).items.find(e => e.category ? .[0] === ex.GlobalConstants.ProductTimeCategory.t_day && e.category ? .[1] === ex.GlobalConstants.ProductStreamCategory.s_1080p);
                if (!r) return void ev.toast.error("Something went wrong — please contact support");
                let l = {
                    coupons: [e.couponCode],
                    lineItems: [{
                        productId: r.id,
                        quantity: 1,
                        timeQty: 1,
                        streamId: null
                    }],
                    note: "Free trial claim"
                };
                localStorage.setItem("orderData", f.default.encodeToBase64(l)), t.push("/checkout")
            } catch {
                ev.toast.error("Something went wrong — please contact support")
            } finally {
                l(!1)
            }
        }
        let h = new Date(e.createdAt).toLocaleDateString(void 0, {
            year: "numeric",
            month: "short",
            day: "numeric"
        });
        return (0, o.jsxs)(u.Card, {
            className: "h-full gap-3 rounded-3xl border-none bg-card p-4 shadow-none sm:p-6",
            children: [(0, o.jsxs)("div", {
                className: "flex items-center justify-between gap-3",
                children: [(0, o.jsx)("p", {
                    className: "text-sm font-bold sm:text-base",
                    children: "Free Trial"
                }), (0, o.jsx)(p.Badge, {
                    domain: "free-trial-status",
                    value: e.status,
                    className: "text-white"
                })]
            }), (0, o.jsx)("p", {
                className: "text-[13.5px] leading-relaxed text-muted-foreground",
                children: a
            }), (0, o.jsxs)("div", {
                className: "mt-auto flex items-center justify-between gap-3 pt-2",
                children: [n ? (0, o.jsx)(v.Button, {
                    size: "sm",
                    disabled: r,
                    onClick: d,
                    children: r ? "Claiming..." : "Claim Free Trial"
                }) : i ? (0, o.jsx)(v.Button, {
                    size: "sm",
                    nativeButton: !1,
                    render: (0, o.jsx)(c.default, {
                        href: f.FREE_TRIAL_REJECTED_REASON_ARTICLE_URL,
                        target: "_blank",
                        rel: "noopener noreferrer"
                    }),
                    children: "Why Wasn't I Approved?"
                }) : (0, o.jsx)("div", {}), (0, o.jsxs)("span", {
                    className: "text-xs text-muted-foreground",
                    children: ["Applied on ", h]
                })]
            })]
        })
    }
    var ey = e.i(702598);

    function ej({
        active: e,
        running: t
    }) {
        let [r, l] = (0, s.useState)({
            usedStorage: 0,
            storage: 0
        });
        (0, s.useEffect)(() => {
            let e = !1;
            return eg.default.userService.getUserStorageAndPlaylistAndStreamCount().then(t => {
                e || l({
                    usedStorage: t.storage ? .usedStorage || 0,
                    storage: t.storage ? .storage || 0
                })
            }).catch(() => {}), () => {
                e = !0
            }
        }, []);
        let a = r.storage > 0 ? Math.round(r.usedStorage / r.storage * 100) : 0;
        return (0, o.jsxs)(u.Card, {
            className: "h-full flex-row items-center gap-4 rounded-3xl border-none bg-card p-4 shadow-none sm:p-6",
            children: [(0, o.jsxs)("div", {
                className: "flex-1 text-center sm:text-left",
                children: [(0, o.jsxs)("p", {
                    className: "text-sm font-bold sm:text-base",
                    children: ["Active Stream: ", e]
                }), (0, o.jsxs)("p", {
                    className: "text-sm font-bold sm:text-base",
                    children: ["Running Stream: ", t]
                }), (0, o.jsxs)("p", {
                    className: "text-sm font-bold sm:text-base",
                    children: ["Storage Used: ", a, "%"]
                })]
            }), (0, o.jsxs)("div", {
                className: "flex flex-col items-center gap-2",
                children: [(0, o.jsx)(ey.CircularProgress, {
                    percentage: a,
                    size: 70,
                    strokeWidth: 6
                }), (0, o.jsx)("p", {
                    className: "text-center text-xs text-muted-foreground",
                    children: 0 === r.storage ? "No active stream" : (0, o.jsxs)(o.Fragment, {
                        children: [(0, o.jsx)("span", {
                            className: "font-bold text-primary",
                            children: f.default.formatBytes(r.usedStorage)
                        }), ` / ${f.default.formatBytes(r.storage)}`]
                    })
                })]
            })]
        })
    }

    function eS({
        active: e,
        running: t
    }) {
        let [r, l] = (0, s.useState)(""), [a, n] = (0, s.useState)(null);
        (0, s.useEffect)(() => {
            eg.default.userService.getUserProfile().then(e => l(`${e.firstName.charAt(0).toUpperCase()}${e.firstName.slice(1)} ${e.lastName.charAt(0).toUpperCase()}${e.lastName.slice(1)}` || "User")).catch(() => l("User"))
        }, []), (0, s.useEffect)(() => {
            let e = !1;
            return eg.default.orderService.getFreeTrialStatus().then(t => {
                e || n(t)
            }).catch(() => {}), () => {
                e = !0
            }
        }, []);
        let i = !!a && a.status !== ex.GlobalConstants.FreeTrialStatus.CLAIMED;
        return (0, o.jsxs)("div", {
            className: "mb-8 w-full",
            children: [(0, o.jsxs)("div", {
                className: "grid grid-cols-1 items-stretch gap-4 md:grid-cols-12",
                children: [(0, o.jsxs)("div", {
                    className: `flex flex-col justify-center px-4 sm:px-3 md:px-7 ${i?"md:col-span-6":"md:col-span-9"} col-span-12`,
                    children: [(0, o.jsxs)("h1", {
                        className: "text-xl font-medium sm:text-2xl",
                        children: ["Welcome back, ", (0, o.jsx)("span", {
                            className: "text-2xl font-bold sm:text-3xl",
                            children: r
                        }), " ", (0, o.jsx)("span", {
                            role: "img",
                            "aria-label": "wave",
                            children: "👋"
                        })]
                    }), (0, o.jsxs)("p", {
                        className: "mt-1 text-foreground",
                        children: ["Ready to go live again or start something fresh?", (0, o.jsx)(v.Button, {
                            size: "sm",
                            nativeButton: !1,
                            render: (0, o.jsx)(c.default, {
                                href: "/stream"
                            }),
                            className: "ml-2 font-extrabold",
                            children: "Start Now"
                        })]
                    })]
                }), i && a && (0, o.jsx)("div", {
                    className: "col-span-12 md:col-span-3",
                    children: (0, o.jsx)(ew, {
                        trial: a
                    })
                }), (0, o.jsx)("div", {
                    className: "col-span-12 md:col-span-3",
                    children: (0, o.jsx)(ej, {
                        active: e,
                        running: t
                    })
                })]
            }), (0, o.jsx)("div", {
                className: "mt-4 w-full md:hidden",
                children: (0, o.jsx)(em, {})
            })]
        })
    }
    e.s(["default", 0, function() {
        let [e, t] = (0, s.useState)(), [r, l] = (0, s.useState)(!0);
        return (0, s.useEffect)(() => {
            let e = !1;
            return eg.default.userService.getDashboard().then(r => {
                e || t(r)
            }).finally(() => {
                e || l(!1)
            }), () => {
                e = !0
            }
        }, []), (0, o.jsxs)("div", {
            className: "min-h-screen p-3",
            children: [(0, o.jsx)(eS, {
                active: e ? .activeStreamsCount || 0,
                running: e ? .runningStreamsCount || 0
            }), (0, o.jsxs)("div", {
                className: "grid grid-cols-1 gap-4 md:grid-cols-12",
                children: [(0, o.jsxs)("div", {
                    className: "col-span-12 flex flex-col gap-4 md:col-span-3",
                    children: [(0, o.jsx)(N, {
                        streams: e ? .zeroToFourStreamsUpcoming || [],
                        loading: r
                    }), (0, o.jsx)(m, {})]
                }), (0, o.jsx)("div", {
                    className: "col-span-12 hidden flex-col gap-4 md:col-span-6 md:flex",
                    children: (0, o.jsx)(em, {})
                }), (0, o.jsxs)("div", {
                    className: "col-span-12 flex flex-col gap-4 md:col-span-3",
                    children: [(0, o.jsx)(b, {
                        streams: e ? .zeroToFourRecentStreams || [],
                        loading: r
                    }), (0, o.jsx)(j, {
                        videos: e ? .videos.media || [],
                        loading: r
                    })]
                })]
            })]
        })
    }], 602927)
}]);