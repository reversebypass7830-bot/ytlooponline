(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 96315, e => {
    "use strict";
    let a = (0, e.i(456420).default)("mail", [
        ["path", {
            d: "m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7",
            key: "132q7q"
        }],
        ["rect", {
            x: "2",
            y: "4",
            width: "20",
            height: "16",
            rx: "2",
            key: "izxlao"
        }]
    ]);
    e.s(["Mail", 0, a], 96315)
}, 847211, e => {
    "use strict";
    let a = (0, e.i(456420).default)("ban", [
        ["circle", {
            cx: "12",
            cy: "12",
            r: "10",
            key: "1mglay"
        }],
        ["path", {
            d: "M4.929 4.929 19.07 19.071",
            key: "196cmz"
        }]
    ]);
    e.s(["Ban", 0, a], 847211)
}, 855958, e => {
    "use strict";
    let a = (0, e.i(456420).default)("circle-pause", [
        ["circle", {
            cx: "12",
            cy: "12",
            r: "10",
            key: "1mglay"
        }],
        ["line", {
            x1: "10",
            x2: "10",
            y1: "15",
            y2: "9",
            key: "c1nkhi"
        }],
        ["line", {
            x1: "14",
            x2: "14",
            y1: "15",
            y2: "9",
            key: "h65svq"
        }]
    ]);
    e.s(["PauseCircle", 0, a], 855958)
}, 573474, e => {
    "use strict";
    let a = (0, e.i(456420).default)("trash-2", [
        ["path", {
            d: "M10 11v6",
            key: "nco0om"
        }],
        ["path", {
            d: "M14 11v6",
            key: "outv1u"
        }],
        ["path", {
            d: "M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6",
            key: "miytrc"
        }],
        ["path", {
            d: "M3 6h18",
            key: "d0wm0j"
        }],
        ["path", {
            d: "M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2",
            key: "e791ji"
        }]
    ]);
    e.s(["Trash2", 0, a], 573474)
}, 793021, e => {
    "use strict";
    var a = e.i(271645),
        t = e.i(846696),
        l = e.i(365114);
    let i = new class {
            async getMetadata() {
                return (await l.default.get("/v1/metadata")).data
            }
        },
        s = null;
    e.s(["useMetadata", 0, function(e = !0) {
        let [l, r] = (0, a.useState)(), [n, d] = (0, a.useState)(e);
        return (0, a.useEffect)(() => {
            if (!e) return;
            let a = !1;
            return d(!0), s || (s = i.getMetadata()), s.then(e => {
                a || r(e)
            }).catch(() => {
                s = null, a || t.toast.error("Error fetching metadata")
            }).finally(() => {
                a || d(!1)
            }), () => {
                a = !0
            }
        }, [e]), {
            metadata: l,
            loading: n
        }
    }], 793021)
}, 632781, e => {
    "use strict";
    var a = e.i(758379);
    e.s(["Loader2", () => a.default])
}, 615331, e => {
    "use strict";
    let a = (0, e.i(456420).default)("radio", [
        ["path", {
            d: "M16.247 7.761a6 6 0 0 1 0 8.478",
            key: "1fwjs5"
        }],
        ["path", {
            d: "M19.075 4.933a10 10 0 0 1 0 14.134",
            key: "ehdyv1"
        }],
        ["path", {
            d: "M4.925 19.067a10 10 0 0 1 0-14.134",
            key: "1q22gi"
        }],
        ["path", {
            d: "M7.753 16.239a6 6 0 0 1 0-8.478",
            key: "r2q7qm"
        }],
        ["circle", {
            cx: "12",
            cy: "12",
            r: "2",
            key: "1c9p78"
        }]
    ]);
    e.s(["Radio", 0, a], 615331)
}, 551757, 519647, 413281, 474544, 766764, 62822, 282625, 512796, 944808, 441206, 457665, 395925, e => {
    "use strict";
    var a = e.i(616933);
    e.s(["CheckCircle2", () => a.default], 551757);
    var t = e.i(456420);
    let l = (0, t.default)("circle-minus", [
        ["circle", {
            cx: "12",
            cy: "12",
            r: "10",
            key: "1mglay"
        }],
        ["path", {
            d: "M8 12h8",
            key: "1wcyev"
        }]
    ]);
    e.s(["CircleMinus", 0, l], 519647);
    let i = (0, t.default)("clock", [
        ["circle", {
            cx: "12",
            cy: "12",
            r: "10",
            key: "1mglay"
        }],
        ["path", {
            d: "M12 6v6l4 2",
            key: "mmk7yg"
        }]
    ]);
    e.s(["default", 0, i], 413281), e.s(["Clock", 0, i], 474544);
    let s = (0, t.default)("file-pen", [
        ["path", {
            d: "M12.659 22H18a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v9.34",
            key: "o6klzx"
        }],
        ["path", {
            d: "M14 2v5a1 1 0 0 0 1 1h5",
            key: "wfsgrz"
        }],
        ["path", {
            d: "M10.378 12.622a1 1 0 0 1 3 3.003L8.36 20.637a2 2 0 0 1-.854.506l-2.867.837a.5.5 0 0 1-.62-.62l.836-2.869a2 2 0 0 1 .506-.853z",
            key: "zhnas1"
        }]
    ]);
    e.s(["FileEdit", 0, s], 766764);
    let r = (0, t.default)("file-plus", [
        ["path", {
            d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
            key: "1oefj6"
        }],
        ["path", {
            d: "M14 2v5a1 1 0 0 0 1 1h5",
            key: "wfsgrz"
        }],
        ["path", {
            d: "M9 15h6",
            key: "cctwl0"
        }],
        ["path", {
            d: "M12 18v-6",
            key: "17g6i2"
        }]
    ]);
    e.s(["FilePlus", 0, r], 62822);
    let n = (0, t.default)("gift", [
        ["path", {
            d: "M12 7v14",
            key: "1akyts"
        }],
        ["path", {
            d: "M20 11v8a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-8",
            key: "1sqzm4"
        }],
        ["path", {
            d: "M7.5 7a1 1 0 0 1 0-5A4.8 8 0 0 1 12 7a4.8 8 0 0 1 4.5-5 1 1 0 0 1 0 5",
            key: "kc0143"
        }],
        ["rect", {
            x: "3",
            y: "7",
            width: "18",
            height: "4",
            rx: "1",
            key: "1hberx"
        }]
    ]);
    e.s(["Gift", 0, n], 282625);
    let d = (0, t.default)("loader", [
        ["path", {
            d: "M12 2v4",
            key: "3427ic"
        }],
        ["path", {
            d: "m16.2 7.8 2.9-2.9",
            key: "r700ao"
        }],
        ["path", {
            d: "M18 12h4",
            key: "wj9ykh"
        }],
        ["path", {
            d: "m16.2 16.2 2.9 2.9",
            key: "1bxg5t"
        }],
        ["path", {
            d: "M12 18v4",
            key: "jadmvz"
        }],
        ["path", {
            d: "m4.9 19.1 2.9-2.9",
            key: "bwix9q"
        }],
        ["path", {
            d: "M2 12h4",
            key: "j09sii"
        }],
        ["path", {
            d: "m4.9 4.9 2.9 2.9",
            key: "giyufr"
        }]
    ]);
    e.s(["Loader", 0, d], 512796);
    let c = (0, t.default)("mail-open", [
        ["path", {
            d: "M21.2 8.4c.5.38.8.97.8 1.6v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V10a2 2 0 0 1 .8-1.6l8-6a2 2 0 0 1 2.4 0l8 6Z",
            key: "1jhwl8"
        }],
        ["path", {
            d: "m22 10-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 10",
            key: "1qfld7"
        }]
    ]);
    e.s(["MailOpen", 0, c], 944808);
    let o = (0, t.default)("mail-warning", [
        ["path", {
            d: "M22 10.5V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v12c0 1.1.9 2 2 2h12.5",
            key: "e61zoh"
        }],
        ["path", {
            d: "m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7",
            key: "1ocrg3"
        }],
        ["path", {
            d: "M20 14v4",
            key: "1hm744"
        }],
        ["path", {
            d: "M20 22v.01",
            key: "12bgn6"
        }]
    ]);
    e.s(["MailWarning", 0, o], 441206);
    let m = (0, t.default)("power", [
        ["path", {
            d: "M12 2v10",
            key: "mnfbl"
        }],
        ["path", {
            d: "M18.4 6.6a9 9 0 1 1-12.77.04",
            key: "obofu9"
        }]
    ]);
    e.s(["Power", 0, m], 457665);
    let b = (0, t.default)("rotate-ccw", [
        ["path", {
            d: "M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",
            key: "1357e3"
        }],
        ["path", {
            d: "M3 3v5h5",
            key: "1xhq8a"
        }]
    ]);
    e.s(["RotateCcw", 0, b], 395925)
}, 725981, e => {
    "use strict";
    let a = (0, e.i(456420).default)("upload", [
        ["path", {
            d: "M12 3v12",
            key: "1x0j5s"
        }],
        ["path", {
            d: "m17 8-5-5-5 5",
            key: "7q97r8"
        }],
        ["path", {
            d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",
            key: "ih7n3h"
        }]
    ]);
    e.s(["Upload", 0, a], 725981)
}, 487486, 583967, e => {
    "use strict";
    var a = e.i(843476),
        t = e.i(225913),
        l = e.i(975157),
        i = e.i(847211),
        s = e.i(551757),
        r = e.i(519647),
        n = e.i(474544),
        d = e.i(766764),
        c = e.i(62822),
        o = e.i(282625),
        m = e.i(512796),
        b = e.i(632781),
        g = e.i(96315),
        u = e.i(944808),
        p = e.i(441206),
        y = e.i(855958),
        h = e.i(457665),
        x = e.i(615331),
        k = e.i(395925),
        f = e.i(573474),
        v = e.i(725981);
    let N = (0, e.i(456420).default)("circle-x", [
        ["circle", {
            cx: "12",
            cy: "12",
            r: "10",
            key: "1mglay"
        }],
        ["path", {
            d: "m15 9-6 6",
            key: "1uzhvr"
        }],
        ["path", {
            d: "m9 9 6 6",
            key: "z0biqf"
        }]
    ]);
    e.s(["XCircle", 0, N], 583967);
    let M = {
        boolean: {},
        "media-status": {
            ready: {
                label: "Ready",
                className: "bg-green-500 text-green-50",
                icon: s.CheckCircle2,
                iconOnlyClassName: "bg-green-400/15 text-green-500"
            },
            processing: {
                label: "Processing",
                className: "bg-amber-500 text-amber-50",
                icon: m.Loader,
                spin: !0,
                iconOnlyClassName: "bg-amber-400/15 text-amber-500"
            },
            uploading: {
                label: "Uploading",
                className: "bg-orange-500 text-orange-50",
                icon: v.Upload,
                iconOnlyClassName: "bg-orange-400/15 text-orange-500"
            }
        },
        "playlist-status": {
            ready: {
                label: "Ready",
                className: "bg-green-500 text-green-50",
                icon: s.CheckCircle2,
                iconOnlyClassName: "bg-green-400/15 text-green-500"
            },
            created: {
                label: "Created",
                className: "bg-blue-500 text-blue-50",
                icon: c.FilePlus,
                iconOnlyClassName: "bg-blue-400/15 text-blue-500"
            },
            processing: {
                label: "Processing",
                className: "bg-amber-500 text-amber-50",
                icon: m.Loader,
                spin: !0,
                iconOnlyClassName: "bg-amber-400/15 text-amber-500"
            },
            uploading: {
                label: "Uploading",
                className: "bg-orange-500 text-orange-50",
                icon: v.Upload,
                iconOnlyClassName: "bg-orange-400/15 text-orange-500"
            }
        },
        "stream-status": {
            off: {
                label: "Off",
                className: "bg-red-400/15 text-red-500",
                icon: h.Power
            },
            on: {
                label: "On",
                className: "bg-green-400/15 text-green-500",
                icon: x.Radio
            },
            starting: {
                label: "Starting",
                className: "bg-yellow-400/15 text-yellow-500",
                icon: b.Loader2,
                spin: !0
            },
            stopping: {
                label: "Stopping",
                className: "bg-yellow-400/15 text-yellow-500",
                icon: y.PauseCircle
            },
            scheduled: {
                label: "Scheduled",
                className: "bg-blue-400/15 text-blue-500",
                icon: n.Clock
            }
        },
        "stream-category": {
            "1080p-standard": {
                label: "1080p Standard*",
                className: "bg-indigo-400/15 text-indigo-400"
            },
            "1080p-premium": {
                label: "1080p Premium*",
                className: "bg-fuchsia-400/15 text-fuchsia-400"
            },
            "4k": {
                label: "4K*",
                className: "bg-indigo-500/15 text-indigo-200"
            }
        },
        "media-category": {
            "1080p-standard": {
                label: "1080p Standard*",
                className: "bg-indigo-400/15 text-indigo-400"
            },
            "1080p-premium": {
                label: "1080p Premium*",
                className: "bg-fuchsia-400/15 text-fuchsia-400"
            },
            "4k": {
                label: "4K*",
                className: "bg-indigo-500/15 text-indigo-200"
            }
        },
        "playlist-category": {
            "1080p-standard": {
                label: "1080p Standard*",
                className: "bg-indigo-400/15 text-indigo-400"
            },
            "1080p-premium": {
                label: "1080p Premium*",
                className: "bg-fuchsia-400/15 text-fuchsia-400"
            },
            "4k": {
                label: "4K*",
                className: "bg-indigo-500/15 text-indigo-200"
            }
        },
        "plan-name": {
            "1080p-standard": {
                label: "1080p Standard*",
                className: "bg-amber-600/50 text-amber-200"
            },
            "1080p-premium": {
                label: "1080p Premium*",
                className: "bg-purple-600/50 text-purple-200"
            },
            "4k": {
                label: "4K*",
                className: "bg-indigo-500/15 text-indigo-200"
            }
        },
        "user-status": {
            active: {
                label: "Active",
                className: "bg-emerald-500/15 text-emerald-200",
                icon: s.CheckCircle2
            },
            inactive: {
                label: "Inactive",
                className: "bg-muted text-muted-foreground",
                icon: r.CircleMinus
            },
            deleted: {
                label: "Deleted",
                className: "bg-rose-500/15 text-rose-200",
                icon: f.Trash2
            },
            email_not_verified: {
                label: "Email Not Verified",
                className: "bg-amber-500/15 text-amber-200",
                icon: p.MailWarning
            },
            disabled: {
                label: "Disabled",
                className: "bg-muted text-muted-foreground",
                icon: i.Ban
            }
        },
        "user-role": {
            admin: {
                label: "Admin",
                className: "bg-indigo-500/15 text-indigo-200"
            },
            user: {
                label: "User",
                className: "bg-muted text-muted-foreground"
            }
        },
        "order-status": {
            pending: {
                label: "Pending",
                className: "bg-amber-500/50 text-amber-200",
                icon: n.Clock
            },
            completed: {
                label: "Completed",
                className: "bg-green-500/50 text-green-200",
                icon: s.CheckCircle2
            },
            failed: {
                label: "Failed",
                className: "bg-red-500/50 text-red-200",
                icon: N
            },
            refunded: {
                label: "Refunded",
                className: "bg-purple-500/50 text-purple-200",
                icon: k.RotateCcw
            },
            created: {
                label: "Created",
                className: "bg-blue-500/50 text-blue-200",
                icon: c.FilePlus
            }
        },
        "free-trial-status": {
            pending: {
                label: "Pending",
                className: "bg-amber-500 text-amber-200",
                icon: n.Clock
            },
            approved: {
                label: "Approved",
                className: "bg-green-500 text-green-200",
                icon: s.CheckCircle2
            },
            rejected: {
                label: "Rejected",
                className: "bg-rose-500 text-rose-200",
                icon: N
            },
            claimed: {
                label: "Claimed",
                className: "bg-sky-500 text-sky-200",
                icon: o.Gift
            }
        },
        "notification-read": {
            read: {
                label: "Read",
                className: "bg-emerald-500/15 text-emerald-200",
                icon: u.MailOpen
            },
            unread: {
                label: "Unread",
                className: "bg-amber-500/15 text-amber-200",
                icon: g.Mail
            }
        },
        "coupon-apply-mode": {
            auto: {
                label: "Auto",
                className: "bg-emerald-500/15 text-emerald-200"
            },
            manual: {
                label: "Manual",
                className: "bg-muted text-muted-foreground"
            }
        },
        "waitlist-approval": {
            approved: {
                label: "Approved",
                className: "bg-emerald-500/15 text-emerald-200",
                icon: s.CheckCircle2
            },
            pending: {
                label: "Pending",
                className: "bg-amber-500/15 text-amber-200",
                icon: n.Clock
            }
        },
        "product-status": {
            active: {
                label: "Active",
                className: "bg-emerald-500/15 text-emerald-200",
                icon: s.CheckCircle2
            },
            inactive: {
                label: "Inactive",
                className: "bg-muted text-muted-foreground",
                icon: r.CircleMinus
            },
            draft: {
                label: "Draft",
                className: "bg-amber-500/15 text-amber-200",
                icon: d.FileEdit
            }
        }
    };
    var C = e.i(793021);
    let w = {
            "stream-status": "streamStatus",
            "stream-category": "streamResolutions",
            "media-category": "mediaResolutions",
            "playlist-category": "playlistCategory",
            "plan-name": "streamResolutions"
        },
        P = "inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium w-fit whitespace-nowrap",
        j = (0, t.cva)(P, {
            variants: {
                variant: {
                    default: "bg-primary/15 text-primary",
                    success: "bg-emerald-500/15 text-emerald-200",
                    warning: "bg-amber-500/15 text-amber-200",
                    danger: "bg-rose-500/15 text-rose-200",
                    info: "bg-sky-500/15 text-sky-200",
                    special: "bg-indigo-500/15 text-indigo-200",
                    neutral: "bg-muted text-muted-foreground",
                    outline: "border border-border bg-transparent text-foreground",
                    secondary: "bg-secondary text-secondary-foreground"
                }
            },
            defaultVariants: {
                variant: "neutral"
            }
        });

    function z(e) {
        return e.replace(/[_-]+/g, " ").trim().split(" ").map(e => e ? e[0].toUpperCase() + e.slice(1) : e).join(" ")
    }
    e.s(["Badge", 0, function({
        className: e,
        variant: t,
        domain: i,
        value: s,
        trueLabel: r,
        falseLabel: n,
        trueVariant: d,
        falseVariant: c,
        iconOnly: o,
        children: m,
        ...b
    }) {
        let g, u, p = m,
            y = t ? ? void 0,
            h = !1,
            x = i ? w[i] : void 0,
            {
                metadata: k
            } = (0, C.useMetadata)(!!x),
            f = x && null != s ? k ? .[x].find(e => e.value === String(s).toLowerCase().trim()) ? .label : void 0;
        if (i) {
            let e = function(e, a, t = "Yes", l = "No", i = "success", s = "neutral", r = !1, n) {
                if ("boolean" === e) {
                    let e = !!a;
                    return {
                        label: e ? t : l,
                        kind: "variant",
                        variant: e ? i : s
                    }
                }
                let d = null == a ? "" : String(a),
                    c = d.toLowerCase().trim(),
                    o = M[e] ? .[c];
                if (o) {
                    let e = r && o.iconOnlyClassName || o.className;
                    return {
                        label: n ? ? o.label,
                        kind: "class",
                        className: e,
                        icon: o.icon,
                        spin: o.spin
                    }
                }
                return d ? {
                    label: n ? ? z(d),
                    kind: "variant",
                    variant: "neutral"
                } : {
                    label: "—",
                    kind: "variant",
                    variant: "neutral"
                }
            }(i, s, r, n, d, c, o, f);
            p = e.label, t || ("class" === e.kind ? (g = e.className, u = e.icon, h = !!e.spin) : y = e.variant)
        }
        return g ? (0, a.jsxs)("span", {
            "data-slot": "badge",
            className: (0, l.cn)(P, "gap-1 font-bold", g, e),
            ...b,
            children: [u && (0, a.jsx)(u, {
                className: (0, l.cn)("size-3 shrink-0", h && "animate-spin")
            }), !o && p]
        }) : (0, a.jsx)("span", {
            "data-slot": "badge",
            "data-variant": y,
            className: (0, l.cn)(j({
                variant: y,
                className: e
            })),
            ...b,
            children: p
        })
    }, "badgeVariants", 0, j, "getBadgeLabel", 0, function(e, a) {
        let t = a.toLowerCase().trim();
        return M[e] ? .[t] ? .label ? ? z(a)
    }], 487486)
}]);