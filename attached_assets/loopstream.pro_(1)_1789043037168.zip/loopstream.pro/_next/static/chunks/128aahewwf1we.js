(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 132061, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        BailoutToCSRError: function() {
            return o
        },
        isBailoutToCSRError: function() {
            return s
        }
    };
    for (var a in n) Object.defineProperty(r, a, {
        enumerable: !0,
        get: n[a]
    });
    let i = "BAILOUT_TO_CLIENT_SIDE_RENDERING";
    class o extends Error {
        constructor(e) {
            super(`Bail out to client-side rendering: ${e}`), this.reason = e, this.digest = i
        }
    }

    function s(e) {
        return "object" == typeof e && null !== e && "digest" in e && e.digest === i
    }
}, 754394, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        HTTPAccessErrorStatus: function() {
            return i
        },
        HTTP_ERROR_FALLBACK_ERROR_CODE: function() {
            return s
        },
        getAccessFallbackErrorTypeByStatus: function() {
            return l
        },
        getAccessFallbackHTTPStatus: function() {
            return c
        },
        isHTTPAccessFallbackError: function() {
            return u
        }
    };
    for (var a in n) Object.defineProperty(r, a, {
        enumerable: !0,
        get: n[a]
    });
    let i = {
            NOT_FOUND: 404,
            FORBIDDEN: 403,
            UNAUTHORIZED: 401
        },
        o = new Set(Object.values(i)),
        s = "NEXT_HTTP_ERROR_FALLBACK";

    function u(e) {
        if ("object" != typeof e || null === e || !("digest" in e) || "string" != typeof e.digest) return !1;
        let [t, r] = e.digest.split(";");
        return t === s && o.has(Number(r))
    }

    function c(e) {
        return Number(e.digest.split(";")[1])
    }

    function l(e) {
        switch (e) {
            case 401:
                return "unauthorized";
            case 403:
                return "forbidden";
            case 404:
                return "not-found";
            default:
                return
        }
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 265713, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "isNextRouterError", {
        enumerable: !0,
        get: function() {
            return i
        }
    });
    let n = e.r(754394),
        a = e.r(968391);

    function i(e) {
        return (0, a.isRedirectError)(e) || (0, n.isHTTPAccessFallbackError)(e)
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 903680, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "ReadonlyURLSearchParams", {
        enumerable: !0,
        get: function() {
            return a
        }
    });
    class n extends Error {
        constructor() {
            super("Method unavailable on `ReadonlyURLSearchParams`. Read more: https://nextjs.org/docs/app/api-reference/functions/use-search-params#updating-searchparams")
        }
    }
    class a extends URLSearchParams {
        append() {
            throw new n
        }
        delete() {
            throw new n
        }
        set() {
            throw new n
        }
        sort() {
            throw new n
        }
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 261994, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        NavigationPromisesContext: function() {
            return l
        },
        PathParamsContext: function() {
            return c
        },
        PathnameContext: function() {
            return u
        },
        ReadonlyURLSearchParams: function() {
            return o.ReadonlyURLSearchParams
        },
        SearchParamsContext: function() {
            return s
        },
        createDevToolsInstrumentedPromise: function() {
            return d
        }
    };
    for (var a in n) Object.defineProperty(r, a, {
        enumerable: !0,
        get: n[a]
    });
    let i = e.r(271645),
        o = e.r(903680),
        s = (0, i.createContext)(null),
        u = (0, i.createContext)(null),
        c = (0, i.createContext)(null),
        l = (0, i.createContext)(null);

    function d(e, t) {
        let r = Promise.resolve(t);
        return r.status = "fulfilled", r.value = t, r.displayName = `${e} (SSR)`, r
    }
}, 245955, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "workUnitAsyncStorageInstance", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = (0, e.r(90317).createAsyncLocalStorage)()
}, 142852, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n, a = {
        RenderStage: function() {
            return u
        },
        StagedRenderingController: function() {
            return c
        }
    };
    for (var i in a) Object.defineProperty(r, i, {
        enumerable: !0,
        get: a[i]
    });
    let o = e.r(312718),
        s = e.r(839470);
    var u = ((n = {})[n.Before = 1] = "Before", n[n.EarlyStatic = 2] = "EarlyStatic", n[n.Static = 3] = "Static", n[n.EarlyRuntime = 4] = "EarlyRuntime", n[n.Runtime = 5] = "Runtime", n[n.Dynamic = 6] = "Dynamic", n[n.Abandoned = 7] = "Abandoned", n);
    class c {
        constructor(e, t, r) {
            this.abortSignal = e, this.abandonController = t, this.shouldTrackSyncIO = r, this.currentStage = 1, this.syncInterruptReason = null, this.staticStageEndTime = 1 / 0, this.runtimeStageEndTime = 1 / 0, this.staticStageListeners = [], this.earlyRuntimeStageListeners = [], this.runtimeStageListeners = [], this.dynamicStageListeners = [], this.staticStagePromise = (0, s.createPromiseWithResolvers)(), this.earlyRuntimeStagePromise = (0, s.createPromiseWithResolvers)(), this.runtimeStagePromise = (0, s.createPromiseWithResolvers)(), this.dynamicStagePromise = (0, s.createPromiseWithResolvers)(), e && e.addEventListener("abort", () => {
                let {
                    reason: t
                } = e;
                this.staticStagePromise.promise.catch(l), this.staticStagePromise.reject(t), this.earlyRuntimeStagePromise.promise.catch(l), this.earlyRuntimeStagePromise.reject(t), this.runtimeStagePromise.promise.catch(l), this.runtimeStagePromise.reject(t), this.dynamicStagePromise.promise.catch(l), this.dynamicStagePromise.reject(t)
            }, {
                once: !0
            }), t && t.signal.addEventListener("abort", () => {
                this.abandonRender()
            }, {
                once: !0
            })
        }
        onStage(e, t) {
            if (this.currentStage >= e) t();
            else if (3 === e) this.staticStageListeners.push(t);
            else if (4 === e) this.earlyRuntimeStageListeners.push(t);
            else if (5 === e) this.runtimeStageListeners.push(t);
            else if (6 === e) this.dynamicStageListeners.push(t);
            else throw Object.defineProperty(new o.InvariantError(`Invalid render stage: ${e}`), "__NEXT_ERROR_CODE", {
                value: "E881",
                enumerable: !1,
                configurable: !0
            })
        }
        shouldTrackSyncInterrupt() {
            if (!this.shouldTrackSyncIO) return !1;
            switch (this.currentStage) {
                case 1:
                case 5:
                case 6:
                case 7:
                default:
                    return !1;
                case 2:
                case 3:
                case 4:
                    return !0
            }
        }
        syncInterruptCurrentStageWithReason(e) {
            if (1 !== this.currentStage && 7 !== this.currentStage) {
                if (this.abandonController) return void this.abandonController.abort();
                if (this.abortSignal) {
                    this.syncInterruptReason = e, this.currentStage = 7;
                    return
                }
                switch (this.currentStage) {
                    case 2:
                    case 3:
                    case 4:
                        this.syncInterruptReason = e, this.advanceStage(6);
                        return;
                    case 5:
                        return
                }
            }
        }
        getSyncInterruptReason() {
            return this.syncInterruptReason
        }
        getStaticStageEndTime() {
            return this.staticStageEndTime
        }
        getRuntimeStageEndTime() {
            return this.runtimeStageEndTime
        }
        abandonRender() {
            let {
                currentStage: e
            } = this;
            switch (e) {
                case 2:
                    this.resolveStaticStage();
                case 3:
                    this.resolveEarlyRuntimeStage();
                case 4:
                    this.resolveRuntimeStage();
                case 5:
                    this.currentStage = 7;
                    return
            }
        }
        advanceStage(e) {
            if (e <= this.currentStage) return;
            let t = this.currentStage;
            if (this.currentStage = e, t < 3 && e >= 3 && this.resolveStaticStage(), t < 4 && e >= 4 && this.resolveEarlyRuntimeStage(), t < 5 && e >= 5 && (this.staticStageEndTime = performance.now() + performance.timeOrigin, this.resolveRuntimeStage()), t < 6 && e >= 6) {
                this.runtimeStageEndTime = performance.now() + performance.timeOrigin, this.resolveDynamicStage();
                return
            }
        }
        resolveStaticStage() {
            let e = this.staticStageListeners;
            for (let t = 0; t < e.length; t++) e[t]();
            e.length = 0, this.staticStagePromise.resolve()
        }
        resolveEarlyRuntimeStage() {
            let e = this.earlyRuntimeStageListeners;
            for (let t = 0; t < e.length; t++) e[t]();
            e.length = 0, this.earlyRuntimeStagePromise.resolve()
        }
        resolveRuntimeStage() {
            let e = this.runtimeStageListeners;
            for (let t = 0; t < e.length; t++) e[t]();
            e.length = 0, this.runtimeStagePromise.resolve()
        }
        resolveDynamicStage() {
            let e = this.dynamicStageListeners;
            for (let t = 0; t < e.length; t++) e[t]();
            e.length = 0, this.dynamicStagePromise.resolve()
        }
        getStagePromise(e) {
            switch (e) {
                case 3:
                    return this.staticStagePromise.promise;
                case 4:
                    return this.earlyRuntimeStagePromise.promise;
                case 5:
                    return this.runtimeStagePromise.promise;
                case 6:
                    return this.dynamicStagePromise.promise;
                default:
                    throw Object.defineProperty(new o.InvariantError(`Invalid render stage: ${e}`), "__NEXT_ERROR_CODE", {
                        value: "E881",
                        enumerable: !1,
                        configurable: !0
                    })
            }
        }
        waitForStage(e) {
            return this.getStagePromise(e)
        }
        delayUntilStage(e, t, r) {
            var n, a, i;
            let o, s = (n = this.getStagePromise(e), a = t, i = r, o = new Promise((e, t) => {
                n.then(e.bind(null, i), t)
            }), void 0 !== a && (o.displayName = a), o);
            return this.abortSignal && s.catch(l), s
        }
    }

    function l() {}
}, 662141, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        getCacheSignal: function() {
            return b
        },
        getDraftModeProviderForCacheScope: function() {
            return g
        },
        getHmrRefreshHash: function() {
            return m
        },
        getPrerenderResumeDataCache: function() {
            return d
        },
        getRenderResumeDataCache: function() {
            return f
        },
        getServerComponentsHmrCache: function() {
            return p
        },
        getStagedRenderingController: function() {
            return y
        },
        isHmrRefresh: function() {
            return h
        },
        isInEarlyRenderStage: function() {
            return u
        },
        throwForMissingRequestStore: function() {
            return c
        },
        throwInvariantForMissingStore: function() {
            return l
        },
        workUnitAsyncStorage: function() {
            return i.workUnitAsyncStorageInstance
        }
    };
    for (var a in n) Object.defineProperty(r, a, {
        enumerable: !0,
        get: n[a]
    });
    let i = e.r(245955);
    e.r(621768);
    let o = e.r(312718),
        s = e.r(142852);

    function u(e) {
        let t = e.stagedRendering;
        return !!t && (t.currentStage === s.RenderStage.EarlyStatic || t.currentStage === s.RenderStage.EarlyRuntime)
    }

    function c(e) {
        throw Object.defineProperty(Error(`\`${e}\` was called outside a request scope. Read more: https://nextjs.org/docs/messages/next-dynamic-api-wrong-context`), "__NEXT_ERROR_CODE", {
            value: "E251",
            enumerable: !1,
            configurable: !0
        })
    }

    function l() {
        throw Object.defineProperty(new o.InvariantError("Expected workUnitAsyncStorage to have a store."), "__NEXT_ERROR_CODE", {
            value: "E696",
            enumerable: !1,
            configurable: !0
        })
    }

    function d(e) {
        switch (e.type) {
            case "prerender":
            case "prerender-runtime":
            case "prerender-ppr":
            case "prerender-client":
            case "validation-client":
                return e.prerenderResumeDataCache;
            case "request":
                if (e.prerenderResumeDataCache) return e.prerenderResumeDataCache;
            case "prerender-legacy":
            case "cache":
            case "private-cache":
            case "unstable-cache":
            case "generate-static-params":
                return null;
            default:
                return e
        }
    }

    function f(e) {
        switch (e.type) {
            case "request":
            case "prerender":
            case "prerender-runtime":
            case "prerender-client":
            case "validation-client":
                if (e.renderResumeDataCache) return e.renderResumeDataCache;
            case "prerender-ppr":
                return e.prerenderResumeDataCache ? ? null;
            case "cache":
            case "private-cache":
            case "unstable-cache":
            case "prerender-legacy":
            case "generate-static-params":
                return null;
            default:
                return e
        }
    }

    function m(e) {}

    function h(e) {
        return !1
    }

    function p(e) {}

    function g(e, t) {
        if (e.isDraftMode) switch (t.type) {
            case "cache":
            case "private-cache":
            case "unstable-cache":
            case "prerender-runtime":
            case "request":
                return t.draftMode
        }
    }

    function y(e) {
        switch (e.type) {
            case "request":
            case "prerender-runtime":
                return e.stagedRendering ? ? null;
            case "prerender":
            case "prerender-client":
            case "validation-client":
            case "prerender-ppr":
            case "prerender-legacy":
            case "cache":
            case "private-cache":
            case "unstable-cache":
            case "generate-static-params":
                return null;
            default:
                return e
        }
    }

    function b(e) {
        switch (e.type) {
            case "prerender":
            case "prerender-client":
            case "validation-client":
            case "prerender-runtime":
                return e.cacheSignal;
            case "request":
                if (e.cacheSignal) return e.cacheSignal;
            case "prerender-ppr":
            case "prerender-legacy":
            case "cache":
            case "private-cache":
            case "unstable-cache":
            case "generate-static-params":
                return null;
            default:
                return e
        }
    }
}, 13957, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        ServerInsertedHTMLContext: function() {
            return o
        },
        useServerInsertedHTML: function() {
            return s
        }
    };
    for (var a in n) Object.defineProperty(r, a, {
        enumerable: !0,
        get: n[a]
    });
    let i = e.r(190809)._(e.r(271645)),
        o = i.default.createContext(null);

    function s(e) {
        let t = (0, i.useContext)(o);
        t && t(e)
    }
}, 222783, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "notFound", {
        enumerable: !0,
        get: function() {
            return i
        }
    });
    let n = e.r(754394),
        a = `${n.HTTP_ERROR_FALLBACK_ERROR_CODE};404`;

    function i() {
        let e = Object.defineProperty(Error(a), "__NEXT_ERROR_CODE", {
            value: "E1041",
            enumerable: !1,
            configurable: !0
        });
        throw e.digest = a, e
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 879854, (e, t, r) => {
    "use strict";

    function n() {
        throw Object.defineProperty(Error("`forbidden()` is experimental and only allowed to be enabled when `experimental.authInterrupts` is enabled."), "__NEXT_ERROR_CODE", {
            value: "E488",
            enumerable: !1,
            configurable: !0
        })
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "forbidden", {
        enumerable: !0,
        get: function() {
            return n
        }
    }), e.r(754394).HTTP_ERROR_FALLBACK_ERROR_CODE, ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 122683, (e, t, r) => {
    "use strict";

    function n() {
        throw Object.defineProperty(Error("`unauthorized()` is experimental and only allowed to be used when `experimental.authInterrupts` is enabled."), "__NEXT_ERROR_CODE", {
            value: "E411",
            enumerable: !1,
            configurable: !0
        })
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "unauthorized", {
        enumerable: !0,
        get: function() {
            return n
        }
    }), e.r(754394).HTTP_ERROR_FALLBACK_ERROR_CODE, ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 115507, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "unstable_rethrow", {
        enumerable: !0,
        get: function() {
            return function e(t) {
                if ((0, a.isNextRouterError)(t) || (0, n.isBailoutToCSRError)(t)) throw t;
                t instanceof Error && "cause" in t && e(t.cause)
            }
        }
    });
    let n = e.r(132061),
        a = e.r(265713);
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 963138, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        delayUntilRuntimeStage: function() {
            return h
        },
        getRuntimeStage: function() {
            return m
        },
        isHangingPromiseRejectionError: function() {
            return o
        },
        makeDevtoolsIOAwarePromise: function() {
            return f
        },
        makeHangingPromise: function() {
            return l
        }
    };
    for (var a in n) Object.defineProperty(r, a, {
        enumerable: !0,
        get: n[a]
    });
    let i = e.r(142852);

    function o(e) {
        return "object" == typeof e && null !== e && "digest" in e && e.digest === s
    }
    let s = "HANGING_PROMISE_REJECTION";
    class u extends Error {
        constructor(e, t) {
            super(`During prerendering, ${t} rejects when the prerender is complete. Typically these errors are handled by React but if you move ${t} to a different context by using \`setTimeout\`, \`after\`, or similar functions you may observe this error and you should handle it in that context. This occurred at route "${e}".`), this.route = e, this.expression = t, this.digest = s
        }
    }
    let c = new WeakMap;

    function l(e, t, r) {
        if (e.aborted) return Promise.reject(new u(t, r)); {
            let n = new Promise((n, a) => {
                let i = a.bind(null, new u(t, r)),
                    o = c.get(e);
                if (o) o.push(i);
                else {
                    let t = [i];
                    c.set(e, t), e.addEventListener("abort", () => {
                        for (let e = 0; e < t.length; e++) t[e]()
                    }, {
                        once: !0
                    })
                }
            });
            return n.catch(d), n
        }
    }

    function d() {}

    function f(e, t, r) {
        return t.stagedRendering ? t.stagedRendering.delayUntilStage(r, void 0, e) : new Promise(t => {
            setTimeout(() => {
                t(e)
            }, 0)
        })
    }

    function m(e) {
        return e.currentStage === i.RenderStage.EarlyStatic || e.currentStage === i.RenderStage.EarlyRuntime ? i.RenderStage.EarlyRuntime : i.RenderStage.Runtime
    }

    function h(e, t) {
        let {
            stagedRendering: r
        } = e;
        return r ? r.waitForStage(m(r)).then(() => t) : t
    }
}, 367287, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "isPostpone", {
        enumerable: !0,
        get: function() {
            return a
        }
    });
    let n = Symbol.for("react.postpone");

    function a(e) {
        return "object" == typeof e && null !== e && e.$$typeof === n
    }
}, 476353, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        DynamicServerError: function() {
            return o
        },
        isDynamicServerError: function() {
            return s
        }
    };
    for (var a in n) Object.defineProperty(r, a, {
        enumerable: !0,
        get: n[a]
    });
    let i = "DYNAMIC_SERVER_USAGE";
    class o extends Error {
        constructor(e) {
            super(`Dynamic server usage: ${e}`), this.description = e, this.digest = i
        }
    }

    function s(e) {
        return "object" == typeof e && null !== e && "digest" in e && "string" == typeof e.digest && e.digest === i
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 643248, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        StaticGenBailoutError: function() {
            return o
        },
        isStaticGenBailoutError: function() {
            return s
        }
    };
    for (var a in n) Object.defineProperty(r, a, {
        enumerable: !0,
        get: n[a]
    });
    let i = "NEXT_STATIC_GEN_BAILOUT";
    class o extends Error {
        constructor(...e) {
            super(...e), this.code = i
        }
    }

    function s(e) {
        return "object" == typeof e && null !== e && "code" in e && e.code === i
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 954839, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        METADATA_BOUNDARY_NAME: function() {
            return i
        },
        OUTLET_BOUNDARY_NAME: function() {
            return s
        },
        ROOT_LAYOUT_BOUNDARY_NAME: function() {
            return u
        },
        VIEWPORT_BOUNDARY_NAME: function() {
            return o
        }
    };
    for (var a in n) Object.defineProperty(r, a, {
        enumerable: !0,
        get: n[a]
    });
    let i = "__next_metadata_boundary__",
        o = "__next_viewport_boundary__",
        s = "__next_outlet_boundary__",
        u = "__next_root_layout_boundary__"
}, 729419, (e, t, r) => {
    "use strict";
    var n = e.i(247167);
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var a = {
        atLeastOneTask: function() {
            return u
        },
        scheduleImmediate: function() {
            return s
        },
        scheduleOnNextTick: function() {
            return o
        },
        waitAtLeastOneReactRenderTask: function() {
            return c
        }
    };
    for (var i in a) Object.defineProperty(r, i, {
        enumerable: !0,
        get: a[i]
    });
    let o = e => {
            Promise.resolve().then(() => {
                n.default.nextTick(e)
            })
        },
        s = e => {
            setImmediate(e)
        };

    function u() {
        return new Promise(e => s(e))
    }

    function c() {
        return new Promise(e => setImmediate(e))
    }
}, 102897, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "INSTANT_VALIDATION_BOUNDARY_NAME", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = "__next_instant_validation_boundary__"
}, 67673, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n, a, i, o = {
        DynamicHoleKind: function() {
            return Z
        },
        Postpone: function() {
            return T
        },
        PreludeState: function() {
            return ei
        },
        abortAndThrowOnSynchronousRequestDataAccess: function() {
            return D
        },
        abortOnSynchronousPlatformIOAccess: function() {
            return j
        },
        accessedDynamicData: function() {
            return L
        },
        annotateDynamicAccess: function() {
            return H
        },
        consumeDynamicAccess: function() {
            return $
        },
        createDynamicTrackingState: function() {
            return E
        },
        createDynamicValidationState: function() {
            return R
        },
        createHangingInputAbortSignal: function() {
            return X
        },
        createInstantValidationState: function() {
            return Q
        },
        createRenderInBrowserAbortSignal: function() {
            return B
        },
        formatDynamicAPIAccesses: function() {
            return U
        },
        getFirstDynamicReason: function() {
            return v
        },
        getNavigationDisallowedDynamicReasons: function() {
            return ec
        },
        getStaticShellDisallowedDynamicReasons: function() {
            return eu
        },
        isDynamicPostpone: function() {
            return C
        },
        isPrerenderInterruptedError: function() {
            return I
        },
        logDisallowedDynamicError: function() {
            return eo
        },
        markCurrentScopeAsDynamic: function() {
            return S
        },
        postponeWithTracking: function() {
            return x
        },
        throwIfDisallowedDynamic: function() {
            return es
        },
        throwToInterruptStaticGeneration: function() {
            return O
        },
        trackAllowedDynamicAccess: function() {
            return J
        },
        trackDynamicDataInDynamicRender: function() {
            return w
        },
        trackDynamicHoleInNavigation: function() {
            return ee
        },
        trackDynamicHoleInRuntimeShell: function() {
            return er
        },
        trackDynamicHoleInStaticShell: function() {
            return en
        },
        trackThrownErrorInNavigation: function() {
            return et
        },
        useDynamicRouteParams: function() {
            return F
        },
        useDynamicSearchParams: function() {
            return W
        }
    };
    for (var s in o) Object.defineProperty(r, s, {
        enumerable: !0,
        get: o[s]
    });
    let u = (n = e.r(271645)) && n.__esModule ? n : {
            default: n
        },
        c = e.r(476353),
        l = e.r(643248),
        d = e.r(662141),
        f = e.r(563599),
        m = e.r(963138),
        h = e.r(954839),
        p = e.r(729419),
        g = e.r(132061),
        y = e.r(312718),
        b = e.r(102897),
        _ = "function" == typeof u.default.unstable_postpone;

    function E(e) {
        return {
            isDebugDynamicAccesses: e,
            dynamicAccesses: [],
            syncDynamicErrorWithStack: null
        }
    }

    function R() {
        return {
            hasSuspenseAboveBody: !1,
            hasDynamicMetadata: !1,
            dynamicMetadata: null,
            hasDynamicViewport: !1,
            hasAllowedDynamic: !1,
            dynamicErrors: []
        }
    }

    function v(e) {
        var t;
        return null == (t = e.dynamicAccesses[0]) ? void 0 : t.expression
    }

    function S(e, t, r) {
        if (t) switch (t.type) {
            case "cache":
            case "unstable-cache":
            case "private-cache":
                return
        }
        if (!e.forceDynamic && !e.forceStatic) {
            if (e.dynamicShouldError) throw Object.defineProperty(new l.StaticGenBailoutError(`Route ${e.route} with \`dynamic = "error"\` couldn't be rendered statically because it used \`${r}\`. See more info here: https://nextjs.org/docs/app/building-your-application/rendering/static-and-dynamic#dynamic-rendering`), "__NEXT_ERROR_CODE", {
                value: "E553",
                enumerable: !1,
                configurable: !0
            });
            if (t) switch (t.type) {
                case "prerender-ppr":
                    return x(e.route, r, t.dynamicTracking);
                case "prerender-legacy":
                    t.revalidate = 0;
                    let n = Object.defineProperty(new c.DynamicServerError(`Route ${e.route} couldn't be rendered statically because it used ${r}. See more info here: https://nextjs.org/docs/messages/dynamic-server-error`), "__NEXT_ERROR_CODE", {
                        value: "E550",
                        enumerable: !1,
                        configurable: !0
                    });
                    throw e.dynamicUsageDescription = r, e.dynamicUsageStack = n.stack, n
            }
        }
    }

    function O(e, t, r) {
        let n = Object.defineProperty(new c.DynamicServerError(`Route ${t.route} couldn't be rendered statically because it used \`${e}\`. See more info here: https://nextjs.org/docs/messages/dynamic-server-error`), "__NEXT_ERROR_CODE", {
            value: "E558",
            enumerable: !1,
            configurable: !0
        });
        throw r.revalidate = 0, t.dynamicUsageDescription = e, t.dynamicUsageStack = n.stack, n
    }

    function w(e) {
        switch (e.type) {
            case "cache":
            case "unstable-cache":
            case "private-cache":
                return
        }
    }

    function P(e, t, r) {
        let n = M(`Route ${e} needs to bail out of prerendering at this point because it used ${t}.`);
        r.controller.abort(n);
        let a = r.dynamicTracking;
        a && a.dynamicAccesses.push({
            stack: a.isDebugDynamicAccesses ? Error().stack : void 0,
            expression: t
        })
    }

    function j(e, t, r, n) {
        let a = n.dynamicTracking;
        P(e, t, n), a && null === a.syncDynamicErrorWithStack && (a.syncDynamicErrorWithStack = r)
    }

    function D(e, t, r, n) {
        if (!1 === n.controller.signal.aborted) {
            P(e, t, n);
            let a = n.dynamicTracking;
            a && null === a.syncDynamicErrorWithStack && (a.syncDynamicErrorWithStack = r)
        }
        throw M(`Route ${e} needs to bail out of prerendering at this point because it used ${t}.`)
    }

    function T({
        reason: e,
        route: t
    }) {
        let r = d.workUnitAsyncStorage.getStore();
        x(t, e, r && "prerender-ppr" === r.type ? r.dynamicTracking : null)
    }

    function x(e, t, r) {
        (function() {
            if (!_) throw Object.defineProperty(Error("Invariant: React.unstable_postpone is not defined. This suggests the wrong version of React was loaded. This is a bug in Next.js"), "__NEXT_ERROR_CODE", {
                value: "E224",
                enumerable: !1,
                configurable: !0
            })
        })(), r && r.dynamicAccesses.push({
            stack: r.isDebugDynamicAccesses ? Error().stack : void 0,
            expression: t
        }), u.default.unstable_postpone(A(e, t))
    }

    function A(e, t) {
        return `Route ${e} needs to bail out of prerendering at this point because it used ${t}. React throws this special object to indicate where. It should not be caught by your own try/catch. Learn more: https://nextjs.org/docs/messages/ppr-caught-error`
    }

    function C(e) {
        return "object" == typeof e && null !== e && "string" == typeof e.message && N(e.message)
    }

    function N(e) {
        return e.includes("needs to bail out of prerendering at this point because it used") && e.includes("Learn more: https://nextjs.org/docs/messages/ppr-caught-error")
    }
    if (!1 === N(A("%%%", "^^^"))) throw Object.defineProperty(Error("Invariant: isDynamicPostpone misidentified a postpone reason. This is a bug in Next.js"), "__NEXT_ERROR_CODE", {
        value: "E296",
        enumerable: !1,
        configurable: !0
    });
    let k = "NEXT_PRERENDER_INTERRUPTED";

    function M(e) {
        let t = Object.defineProperty(Error(e), "__NEXT_ERROR_CODE", {
            value: "E394",
            enumerable: !1,
            configurable: !0
        });
        return t.digest = k, t
    }

    function I(e) {
        return "object" == typeof e && null !== e && e.digest === k && "name" in e && "message" in e && e instanceof Error
    }

    function L(e) {
        return e.length > 0
    }

    function $(e, t) {
        return e.dynamicAccesses.push(...t.dynamicAccesses), e.dynamicAccesses
    }

    function U(e) {
        return e.filter(e => "string" == typeof e.stack && e.stack.length > 0).map(({
            expression: e,
            stack: t
        }) => (t = t.split("\n").slice(4).filter(e => !(e.includes("node_modules/next/") || e.includes(" (<anonymous>)") || e.includes(" (node:"))).join("\n"), `Dynamic API Usage Debug - ${e}:
${t}`))
    }

    function B() {
        let e = new AbortController;
        return e.abort(Object.defineProperty(new g.BailoutToCSRError("Render in Browser"), "__NEXT_ERROR_CODE", {
            value: "E721",
            enumerable: !1,
            configurable: !0
        })), e.signal
    }

    function X(e) {
        switch (e.type) {
            case "prerender":
            case "prerender-runtime":
                let t = new AbortController;
                if (e.cacheSignal) e.cacheSignal.inputReady().then(() => {
                    t.abort()
                });
                else if ("prerender-runtime" === e.type && e.stagedRendering) {
                    let {
                        stagedRendering: r
                    } = e;
                    r.waitForStage((0, m.getRuntimeStage)(r)).then(() => (0, p.scheduleOnNextTick)(() => t.abort()))
                } else(0, p.scheduleOnNextTick)(() => t.abort());
                return t.signal;
            case "prerender-client":
            case "validation-client":
            case "prerender-ppr":
            case "prerender-legacy":
            case "request":
            case "cache":
            case "private-cache":
            case "unstable-cache":
            case "generate-static-params":
                return
        }
    }

    function H(e, t) {
        let r = t.dynamicTracking;
        r && r.dynamicAccesses.push({
            stack: r.isDebugDynamicAccesses ? Error().stack : void 0,
            expression: e
        })
    }

    function F(e) {
        let t = f.workAsyncStorage.getStore(),
            r = d.workUnitAsyncStorage.getStore();
        if (t && r) switch (r.type) {
            case "prerender-client":
            case "prerender":
                {
                    let n = r.fallbackRouteParams;n && n.size > 0 && u.default.use((0, m.makeHangingPromise)(r.renderSignal, t.route, e));
                    break
                }
            case "prerender-ppr":
                {
                    let n = r.fallbackRouteParams;
                    if (n && n.size > 0) return x(t.route, e, r.dynamicTracking);
                    break
                }
            case "validation-client":
            case "prerender-legacy":
            case "request":
            case "unstable-cache":
                break;
            case "prerender-runtime":
                throw Object.defineProperty(new y.InvariantError(`\`${e}\` was called during a runtime prerender. Next.js should be preventing ${e} from being included in server components statically, but did not in this case.`), "__NEXT_ERROR_CODE", {
                    value: "E771",
                    enumerable: !1,
                    configurable: !0
                });
            case "cache":
            case "private-cache":
                throw Object.defineProperty(new y.InvariantError(`\`${e}\` was called inside a cache scope. Next.js should be preventing ${e} from being included in server components statically, but did not in this case.`), "__NEXT_ERROR_CODE", {
                    value: "E745",
                    enumerable: !1,
                    configurable: !0
                });
            case "generate-static-params":
                throw Object.defineProperty(new y.InvariantError(`\`${e}\` was called in \`generateStaticParams\`. Next.js should be preventing ${e} from being included in server component files statically, but did not in this case.`), "__NEXT_ERROR_CODE", {
                    value: "E1130",
                    enumerable: !1,
                    configurable: !0
                })
        }
    }

    function W(e) {
        let t = f.workAsyncStorage.getStore(),
            r = d.workUnitAsyncStorage.getStore();
        if (t) switch (!r && (0, d.throwForMissingRequestStore)(e), r.type) {
            case "validation-client":
            case "request":
                return;
            case "prerender-client":
                u.default.use((0, m.makeHangingPromise)(r.renderSignal, t.route, e));
                break;
            case "prerender-legacy":
            case "prerender-ppr":
                if (t.forceStatic) return;
                throw Object.defineProperty(new g.BailoutToCSRError(e), "__NEXT_ERROR_CODE", {
                    value: "E394",
                    enumerable: !1,
                    configurable: !0
                });
            case "prerender":
            case "prerender-runtime":
                throw Object.defineProperty(new y.InvariantError(`\`${e}\` was called from a Server Component. Next.js should be preventing ${e} from being included in server components statically, but did not in this case.`), "__NEXT_ERROR_CODE", {
                    value: "E795",
                    enumerable: !1,
                    configurable: !0
                });
            case "cache":
            case "unstable-cache":
            case "private-cache":
                throw Object.defineProperty(new y.InvariantError(`\`${e}\` was called inside a cache scope. Next.js should be preventing ${e} from being included in server components statically, but did not in this case.`), "__NEXT_ERROR_CODE", {
                    value: "E745",
                    enumerable: !1,
                    configurable: !0
                });
            case "generate-static-params":
                throw Object.defineProperty(new y.InvariantError(`\`${e}\` was called in \`generateStaticParams\`. Next.js should be preventing ${e} from being included in server component files statically, but did not in this case.`), "__NEXT_ERROR_CODE", {
                    value: "E1130",
                    enumerable: !1,
                    configurable: !0
                })
        }
    }
    let z = /\n\s+at Suspense \(<anonymous>\)/,
        V = RegExp(`\\n\\s+at Suspense \\(<anonymous>\\)(?:(?!\\n\\s+at (?:body|div|main|section|article|aside|header|footer|nav|form|p|span|h1|h2|h3|h4|h5|h6) \\(<anonymous>\\))[\\s\\S])*?\\n\\s+at ${h.ROOT_LAYOUT_BOUNDARY_NAME} \\([^\\n]*\\)`),
        q = RegExp(`\\n\\s+at ${h.METADATA_BOUNDARY_NAME}[\\n\\s]`),
        G = RegExp(`\\n\\s+at ${h.VIEWPORT_BOUNDARY_NAME}[\\n\\s]`),
        Y = RegExp(`\\n\\s+at ${h.OUTLET_BOUNDARY_NAME}[\\n\\s]`),
        K = RegExp(`\\n\\s+at ${b.INSTANT_VALIDATION_BOUNDARY_NAME}[\\n\\s]`);

    function J(e, t, r, n) {
        if (!Y.test(t)) {
            if (q.test(t)) {
                r.hasDynamicMetadata = !0;
                return
            }
            if (G.test(t)) {
                r.hasDynamicViewport = !0;
                return
            }
            if (V.test(t)) {
                r.hasAllowedDynamic = !0, r.hasSuspenseAboveBody = !0;
                return
            } else if (z.test(t)) {
                r.hasAllowedDynamic = !0;
                return
            } else {
                if (n.syncDynamicErrorWithStack) return void r.dynamicErrors.push(n.syncDynamicErrorWithStack);
                let a = ea(Object.defineProperty(Error(`Route "${e.route}": Uncached data was accessed outside of <Suspense>. This delays the entire page from rendering, resulting in a slow user experience. Learn more: https://nextjs.org/docs/messages/blocking-route`), "__NEXT_ERROR_CODE", {
                    value: "E1079",
                    enumerable: !1,
                    configurable: !0
                }), t, null);
                return void r.dynamicErrors.push(a)
            }
        }
    }
    var Z = ((a = {})[a.Runtime = 1] = "Runtime", a[a.Dynamic = 2] = "Dynamic", a);

    function Q(e) {
        return {
            hasDynamicMetadata: !1,
            hasAllowedClientDynamicAboveBoundary: !1,
            dynamicMetadata: null,
            hasDynamicViewport: !1,
            hasAllowedDynamic: !1,
            dynamicErrors: [],
            validationPreventingErrors: [],
            thrownErrorsOutsideBoundary: [],
            createInstantStack: e
        }
    }

    function ee(e, t, r, n, a, i) {
        if (Y.test(t)) return;
        if (q.test(t)) {
            let n = ea(Object.defineProperty(Error(`Route "${e.route}": ${1===a?"Runtime data such as `cookies()`, `headers()`, `params`, or `searchParams` was accessed inside `generateMetadata` or you have file-based metadata such as icons that depend on dynamic params segments.":"Uncached data or `connection()` was accessed inside `generateMetadata`."} Except for this instance, the page would have been entirely prerenderable which may have been the intended behavior. See more info here: https://nextjs.org/docs/messages/next-prerender-dynamic-metadata`), "__NEXT_ERROR_CODE", {
                value: "E1076",
                enumerable: !1,
                configurable: !0
            }), t, r.createInstantStack);
            r.dynamicMetadata = n;
            return
        }
        if (G.test(t)) {
            let n = ea(Object.defineProperty(Error(`Route "${e.route}": ${1===a?"Runtime data such as `cookies()`, `headers()`, `params`, or `searchParams` was accessed inside `generateViewport`.":"Uncached data or `connection()` was accessed inside `generateViewport`."} This delays the entire page from rendering, resulting in a slow user experience. Learn more: https://nextjs.org/docs/messages/next-prerender-dynamic-viewport`), "__NEXT_ERROR_CODE", {
                value: "E1086",
                enumerable: !1,
                configurable: !0
            }), t, r.createInstantStack);
            r.dynamicErrors.push(n);
            return
        }
        let o = K.exec(t);
        if (o) {
            let e = z.exec(t);
            if (e && e.index < o.index) {
                r.hasAllowedDynamic = !0;
                return
            }
        } else if (i.expectedIds.size === i.renderedIds.size) {
            r.hasAllowedClientDynamicAboveBoundary = !0, r.hasAllowedDynamic = !0;
            return
        } else {
            let n = ea(Object.defineProperty(Error(`Route "${e.route}": Could not validate \`unstable_instant\` because a Client Component in a parent segment prevented the page from rendering.`), "__NEXT_ERROR_CODE", {
                value: "E1082",
                enumerable: !1,
                configurable: !0
            }), t, r.createInstantStack);
            r.validationPreventingErrors.push(n);
            return
        }
        if (n.syncDynamicErrorWithStack) {
            let e = n.syncDynamicErrorWithStack;
            null !== r.createInstantStack && void 0 === e.cause && (e.cause = r.createInstantStack()), r.dynamicErrors.push(e);
            return
        }
        let s = ea(Object.defineProperty(Error(`Route "${e.route}": ${1===a?"Runtime data such as `cookies()`, `headers()`, `params`, or `searchParams` was accessed outside of `<Suspense>`.":"Uncached data or `connection()` was accessed outside of `<Suspense>`."} This delays the entire page from rendering, resulting in a slow user experience. Learn more: https://nextjs.org/docs/messages/blocking-route`), "__NEXT_ERROR_CODE", {
            value: "E1078",
            enumerable: !1,
            configurable: !0
        }), t, r.createInstantStack);
        r.dynamicErrors.push(s)
    }

    function et(e, t, r, n) {
        let a = K.exec(n);
        if (a) {
            let i = z.exec(n);
            if (i && i.index < a.index) return;
            let o = ea(Object.defineProperty(Error(`Route "${e.route}": Could not validate \`unstable_instant\` because an error prevented the target segment from rendering.`, {
                cause: r
            }), "__NEXT_ERROR_CODE", {
                value: "E1112",
                enumerable: !1,
                configurable: !0
            }), n, null);
            t.validationPreventingErrors.push(o)
        } else {
            let e = ea(Object.defineProperty(Error("An error occurred while attempting to validate instant UI. This error may be preventing the validation from completing.", {
                cause: r
            }), "__NEXT_ERROR_CODE", {
                value: "E1118",
                enumerable: !1,
                configurable: !0
            }), n, null);
            t.thrownErrorsOutsideBoundary.push(e)
        }
    }

    function er(e, t, r, n) {
        if (Y.test(t)) return;
        if (q.test(t)) {
            r.dynamicMetadata = ea(Object.defineProperty(Error(`Route "${e.route}": Uncached data or \`connection()\` was accessed inside \`generateMetadata\`. Except for this instance, the page would have been entirely prerenderable which may have been the intended behavior. See more info here: https://nextjs.org/docs/messages/next-prerender-dynamic-metadata`), "__NEXT_ERROR_CODE", {
                value: "E1080",
                enumerable: !1,
                configurable: !0
            }), t, null);
            return
        }
        if (G.test(t)) {
            let n = ea(Object.defineProperty(Error(`Route "${e.route}": Uncached data or \`connection()\` was accessed inside \`generateViewport\`. This delays the entire page from rendering, resulting in a slow user experience. Learn more: https://nextjs.org/docs/messages/next-prerender-dynamic-viewport`), "__NEXT_ERROR_CODE", {
                value: "E1077",
                enumerable: !1,
                configurable: !0
            }), t, null);
            r.dynamicErrors.push(n);
            return
        }
        if (V.test(t)) {
            r.hasAllowedDynamic = !0, r.hasSuspenseAboveBody = !0;
            return
        }
        if (z.test(t)) {
            r.hasAllowedDynamic = !0;
            return
        } else if (n.syncDynamicErrorWithStack) return void r.dynamicErrors.push(n.syncDynamicErrorWithStack);
        let a = ea(Object.defineProperty(Error(`Route "${e.route}": Uncached data or \`connection()\` was accessed outside of \`<Suspense>\`. This delays the entire page from rendering, resulting in a slow user experience. Learn more: https://nextjs.org/docs/messages/blocking-route`), "__NEXT_ERROR_CODE", {
            value: "E1084",
            enumerable: !1,
            configurable: !0
        }), t, null);
        r.dynamicErrors.push(a)
    }

    function en(e, t, r, n) {
        if (!Y.test(t)) {
            if (q.test(t)) {
                r.dynamicMetadata = ea(Object.defineProperty(Error(`Route "${e.route}": Runtime data such as \`cookies()\`, \`headers()\`, \`params\`, or \`searchParams\` was accessed inside \`generateMetadata\` or you have file-based metadata such as icons that depend on dynamic params segments. Except for this instance, the page would have been entirely prerenderable which may have been the intended behavior. See more info here: https://nextjs.org/docs/messages/next-prerender-dynamic-metadata`), "__NEXT_ERROR_CODE", {
                    value: "E1085",
                    enumerable: !1,
                    configurable: !0
                }), t, null);
                return
            }
            if (G.test(t)) {
                let n = ea(Object.defineProperty(Error(`Route "${e.route}": Runtime data such as \`cookies()\`, \`headers()\`, \`params\`, or \`searchParams\` was accessed inside \`generateViewport\`. This delays the entire page from rendering, resulting in a slow user experience. Learn more: https://nextjs.org/docs/messages/next-prerender-dynamic-viewport`), "__NEXT_ERROR_CODE", {
                    value: "E1081",
                    enumerable: !1,
                    configurable: !0
                }), t, null);
                r.dynamicErrors.push(n);
                return
            }
            if (V.test(t)) {
                r.hasAllowedDynamic = !0, r.hasSuspenseAboveBody = !0;
                return
            } else if (z.test(t)) {
                r.hasAllowedDynamic = !0;
                return
            } else {
                if (n.syncDynamicErrorWithStack) return void r.dynamicErrors.push(n.syncDynamicErrorWithStack);
                let a = ea(Object.defineProperty(Error(`Route "${e.route}": Runtime data such as \`cookies()\`, \`headers()\`, \`params\`, or \`searchParams\` was accessed outside of \`<Suspense>\`. This delays the entire page from rendering, resulting in a slow user experience. Learn more: https://nextjs.org/docs/messages/blocking-route`), "__NEXT_ERROR_CODE", {
                    value: "E1083",
                    enumerable: !1,
                    configurable: !0
                }), t, null);
                return void r.dynamicErrors.push(a)
            }
        }
    }

    function ea(e, t, r) {
        return null !== r && (e.cause = r()), e.stack = e.name + ": " + e.message + t, e
    }
    var ei = ((i = {})[i.Full = 0] = "Full", i[i.Empty = 1] = "Empty", i[i.Errored = 2] = "Errored", i);

    function eo(e, t) {
        console.error(t), console.error(`To get a more detailed stack trace and pinpoint the issue, try one of the following:
  - Start the app in development mode by running \`next dev\`, then open "${e.route}" in your browser to investigate the error.
  - Rerun the production build with \`next build --debug-prerender\` to generate better stack traces.`)
    }

    function es(e, t, r, n) {
        if (n.syncDynamicErrorWithStack) throw eo(e, n.syncDynamicErrorWithStack), new l.StaticGenBailoutError;
        if (0 !== t) {
            if (r.hasSuspenseAboveBody) return;
            let n = r.dynamicErrors;
            if (n.length > 0) {
                for (let t = 0; t < n.length; t++) eo(e, n[t]);
                throw new l.StaticGenBailoutError
            }
            if (r.hasDynamicViewport) throw console.error(`Route "${e.route}" has a \`generateViewport\` that depends on Request data (\`cookies()\`, etc...) or uncached external data (\`fetch(...)\`, etc...) without explicitly allowing fully dynamic rendering. See more info here: https://nextjs.org/docs/messages/next-prerender-dynamic-viewport`), new l.StaticGenBailoutError;
            if (1 === t) throw console.error(`Route "${e.route}" did not produce a static shell and Next.js was unable to determine a reason. This is a bug in Next.js.`), new l.StaticGenBailoutError
        } else if (!1 === r.hasAllowedDynamic && r.hasDynamicMetadata) throw console.error(`Route "${e.route}" has a \`generateMetadata\` that depends on Request data (\`cookies()\`, etc...) or uncached external data (\`fetch(...)\`, etc...) when the rest of the route does not. See more info here: https://nextjs.org/docs/messages/next-prerender-dynamic-metadata`), new l.StaticGenBailoutError
    }

    function eu(e, t, r, n) {
        if (n || r.hasSuspenseAboveBody) return [];
        if (0 !== t) {
            let n = r.dynamicErrors;
            if (n.length > 0) return n;
            if (1 === t) return [Object.defineProperty(new y.InvariantError(`Route "${e.route}" did not produce a static shell and Next.js was unable to determine a reason.`), "__NEXT_ERROR_CODE", {
                value: "E936",
                enumerable: !1,
                configurable: !0
            })]
        } else if (!1 === r.hasAllowedDynamic && 0 === r.dynamicErrors.length && r.dynamicMetadata) return [r.dynamicMetadata];
        return []
    }

    function ec(e, t, r, n, a) {
        if (n) {
            let {
                missingSampleErrors: e
            } = n;
            if (e.length > 0) return e
        }
        let {
            validationPreventingErrors: i
        } = r;
        if (i.length > 0) return i;
        if (a.renderedIds.size < a.expectedIds.size) {
            let {
                thrownErrorsOutsideBoundary: t,
                createInstantStack: n
            } = r;
            if (0 === t.length) {
                let t = `Route "${e.route}": Could not validate \`unstable_instant\` because the target segment was prevented from rendering for an unknown reason.`,
                    r = null !== n ? n() : Error();
                return r.name = "Error", r.message = t, [r]
            }
            if (1 === t.length) {
                let r = `Route "${e.route}": Could not validate \`unstable_instant\` because the target segment was prevented from rendering, likely due to the following error.`,
                    a = null !== n ? n() : Error();
                return a.name = "Error", a.message = r, [a, t[0]]
            } {
                let r = `Route "${e.route}": Could not validate \`unstable_instant\` because the target segment was prevented from rendering, likely due to one of the following errors.`,
                    a = null !== n ? n() : Error();
                return a.name = "Error", a.message = r, [a, ...t]
            }
        }
        if (0 !== t) {
            let n = r.dynamicErrors;
            if (n.length > 0) return n;
            if (1 === t) return r.hasAllowedClientDynamicAboveBoundary ? [] : [Object.defineProperty(new y.InvariantError(`Route "${e.route}" failed to render during instant validation and Next.js was unable to determine a reason.`), "__NEXT_ERROR_CODE", {
                value: "E1055",
                enumerable: !1,
                configurable: !0
            })]
        } else {
            let e = r.dynamicErrors;
            if (e.length > 0) return e;
            if (!1 === r.hasAllowedDynamic && r.dynamicMetadata) return [r.dynamicMetadata]
        }
        return []
    }
}, 891414, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "unstable_rethrow", {
        enumerable: !0,
        get: function() {
            return function e(t) {
                if ((0, o.isNextRouterError)(t) || (0, i.isBailoutToCSRError)(t) || (0, u.isDynamicServerError)(t) || (0, s.isDynamicPostpone)(t) || (0, a.isPostpone)(t) || (0, n.isHangingPromiseRejectionError)(t) || (0, s.isPrerenderInterruptedError)(t)) throw t;
                t instanceof Error && "cause" in t && e(t.cause)
            }
        }
    });
    let n = e.r(963138),
        a = e.r(367287),
        i = e.r(132061),
        o = e.r(265713),
        s = e.r(67673),
        u = e.r(476353);
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 490508, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "unstable_rethrow", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = "u" < typeof window ? e.r(891414).unstable_rethrow : e.r(115507).unstable_rethrow;
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 592805, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        ReadonlyURLSearchParams: function() {
            return i.ReadonlyURLSearchParams
        },
        RedirectType: function() {
            return f
        },
        forbidden: function() {
            return u.forbidden
        },
        notFound: function() {
            return s.notFound
        },
        permanentRedirect: function() {
            return o.permanentRedirect
        },
        redirect: function() {
            return o.redirect
        },
        unauthorized: function() {
            return c.unauthorized
        },
        unstable_isUnrecognizedActionError: function() {
            return d
        },
        unstable_rethrow: function() {
            return l.unstable_rethrow
        }
    };
    for (var a in n) Object.defineProperty(r, a, {
        enumerable: !0,
        get: n[a]
    });
    let i = e.r(903680),
        o = e.r(124063),
        s = e.r(222783),
        u = e.r(879854),
        c = e.r(122683),
        l = e.r(490508);

    function d() {
        throw Object.defineProperty(Error("`unstable_isUnrecognizedActionError` can only be used on the client."), "__NEXT_ERROR_CODE", {
            value: "E776",
            enumerable: !1,
            configurable: !0
        })
    }
    let f = {
        push: "push",
        replace: "replace"
    };
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 976562, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        ReadonlyURLSearchParams: function() {
            return s.ReadonlyURLSearchParams
        },
        RedirectType: function() {
            return d.RedirectType
        },
        ServerInsertedHTMLContext: function() {
            return c.ServerInsertedHTMLContext
        },
        forbidden: function() {
            return d.forbidden
        },
        notFound: function() {
            return d.notFound
        },
        permanentRedirect: function() {
            return d.permanentRedirect
        },
        redirect: function() {
            return d.redirect
        },
        unauthorized: function() {
            return d.unauthorized
        },
        unstable_isUnrecognizedActionError: function() {
            return l.unstable_isUnrecognizedActionError
        },
        unstable_rethrow: function() {
            return d.unstable_rethrow
        },
        useParams: function() {
            return E
        },
        usePathname: function() {
            return b
        },
        useRouter: function() {
            return _
        },
        useSearchParams: function() {
            return y
        },
        useSelectedLayoutSegment: function() {
            return v
        },
        useSelectedLayoutSegments: function() {
            return R
        },
        useServerInsertedHTML: function() {
            return c.useServerInsertedHTML
        }
    };
    for (var a in n) Object.defineProperty(r, a, {
        enumerable: !0,
        get: n[a]
    });
    let i = e.r(190809)._(e.r(271645)),
        o = e.r(8372),
        s = e.r(261994),
        u = e.r(813258),
        c = e.r(13957),
        l = e.r(292838),
        d = e.r(592805),
        f = "u" < typeof window ? e.r(67673).useDynamicRouteParams : void 0,
        m = "u" < typeof window ? e.r(67673).useDynamicSearchParams : void 0,
        {
            instrumentParamsForClientValidation: h,
            instrumentSearchParamsForClientValidation: p,
            expectCompleteParamsInClientValidation: g
        } = {};

    function y() {
        m ? .("useSearchParams()");
        let e = (0, i.useContext)(s.SearchParamsContext);
        return (0, i.useMemo)(() => e ? new s.ReadonlyURLSearchParams(e) : null, [e])
    }

    function b() {
        return f ? .("usePathname()"), (0, i.useContext)(s.PathnameContext)
    }

    function _() {
        let e = (0, i.useContext)(o.AppRouterContext);
        if (null === e) throw Object.defineProperty(Error("invariant expected app router to be mounted"), "__NEXT_ERROR_CODE", {
            value: "E238",
            enumerable: !1,
            configurable: !0
        });
        return e
    }

    function E() {
        return f ? .("useParams()"), (0, i.useContext)(s.PathParamsContext)
    }

    function R(e = "children") {
        f ? .("useSelectedLayoutSegments()");
        let t = (0, i.useContext)(o.LayoutRouterContext);
        return t ? (0, u.getSelectedLayoutSegmentPath)(t.parentTree, e) : null
    }

    function v(e = "children") {
        f ? .("useSelectedLayoutSegment()"), (0, i.useContext)(s.NavigationPromisesContext);
        let t = R(e);
        return (0, u.computeSelectedLayoutSegment)(t, e)
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}]);